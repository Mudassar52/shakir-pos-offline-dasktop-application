import db from "../db.js";

export function badRequest(msg, status = 400) {
  const err = new Error(msg);
  err.status = status;
  return err;
}

const n = (v) => Number(v) || 0;
const r2 = (v) => Math.round(v * 100) / 100;

// Sale / manual invoice ka common validation. Server client par bharosa nahi karta.
export function validateInvoiceInput(data, { requireItems = true } = {}) {
  const items = Array.isArray(data.items) ? data.items : [];
  if (requireItems && items.length === 0) throw badRequest("Invoice mein kam az kam ek item hona chahiye.");
  const total = Number(data.total);
  if (!Number.isFinite(total) || total < 0) throw badRequest("Total galat hai (negative ya number nahi).");
  const advance = n(data.advance);
  if (advance < 0) throw badRequest("Advance negative nahi ho sakta.");
  for (const it of items) {
    if (!Number.isFinite(Number(it.qty)) || Number(it.qty) <= 0) throw badRequest(`"${it.name || "Item"}" ki quantity galat hai.`);
    if (n(it.salePrice ?? it.unitPrice ?? it.price) < 0) throw badRequest(`"${it.name || "Item"}" ki price negative hai.`);
  }
  // Total = items - discount + tax (1 rupee tak rounding ki ijazat). Server khud hisaab lagata hai.
  if (items.length) {
    const subtotal = items.reduce((sum, it) => {
      const line = Number(it.lineTotal);
      return sum + (Number.isFinite(line) && it.lineTotal !== undefined ? line : n(it.qty) * n(it.salePrice ?? it.unitPrice ?? it.price));
    }, 0);
    const expected = subtotal - n(data.discount) + n(data.tax);
    if (Math.abs(expected - total) > 1) {
      throw badRequest(`Total (${total}) items ke hisaab (${Math.round(expected)}) se match nahi karta. Bill dobara kholein.`);
    }
  }
  if (data.paymentMode === "udaar") {
    if (!data.customerId) throw badRequest("Udaar bill ke liye customer chunna zaroori hai.");
    const exists = db.prepare("SELECT id FROM customers WHERE id = ?").get(data.customerId);
    if (!exists) throw badRequest("Customer nahi mila.", 404);
    if (advance > total + 0.001) throw badRequest("Advance total se zyada nahi ho sakta.");
  }
  return { items, total, advance };
}

// Items ka stock check + kam karna (transaction ke andar bulao).
export function deductStock(items, { strict = true } = {}) {
  const need = new Map();
  for (const it of items) {
    if (!it.productId) continue;
    need.set(it.productId, (need.get(it.productId) || 0) + n(it.qty));
  }
  for (const [pid, qty] of need) {
    const row = db.prepare("SELECT name, current_stock FROM products WHERE id = ?").get(pid);
    if (!row) { if (strict) throw badRequest("Product ab maujood nahi hai (delete ho chuka hai)."); continue; }
    if (strict && n(row.current_stock) < qty) {
      throw badRequest(`"${row.name}" ka stock kam hai (maujood: ${n(row.current_stock)}, chahiye: ${qty}).`);
    }
  }
  const ts = new Date().toISOString();
  for (const [pid, qty] of need) {
    db.prepare("UPDATE products SET current_stock = current_stock - ?, updated_at = ? WHERE id = ?").run(qty, ts, pid);
  }
}

export function restoreStock(items) {
  const ts = new Date().toISOString();
  for (const it of items) {
    if (it.productId) db.prepare("UPDATE products SET current_stock = current_stock + ?, updated_at = ? WHERE id = ?").run(n(it.qty), ts, it.productId);
  }
}

export function validateProduct(f, { excludeId = null } = {}) {
  const name = String(f.name || "").trim();
  if (!name) throw badRequest("Product ka naam zaroori hai.");
  for (const [k, label] of [["salePrice", "Sale price"], ["costPrice", "Cost price"], ["stockPrice", "Stock price"], ["saleShopPrice", "Shop price"], ["currentStock", "Stock"], ["lowStockAlertQty", "Low stock alert"], ["ctn", "Carton"]]) {
    if (f[k] !== undefined && f[k] !== null && f[k] !== "" && (!Number.isFinite(Number(f[k])) || Number(f[k]) < 0)) {
      throw badRequest(`${label} negative ya galat nahi ho sakta.`);
    }
  }
  const batch = String(f.batchNo || "").trim().toLowerCase();
  const dup = db.prepare("SELECT id, batch_no FROM products WHERE lower(name) = lower(?)").all(name)
    .find((p) => p.id !== excludeId && String(p.batch_no || "").trim().toLowerCase() === batch);
  if (dup) throw badRequest(`"${name}" pehle se maujood hai. Naya stock chahiye to Stock In karein.`);
}

export const money = r2;

// ── Double-submit guard ───────────────────────────────────────────────────
// Double click / double Enter se ek hi bill ya payment do baar na ban jaye:
// bilkul wahi cheez (same key) 3 second ke andar dobara aaye to rad kar dete hain.
// Sirf memory mein rehta hai (app band hone par khatam), koi data nahi chheda jata.
const recentSubmits = new Map();
const DOUBLE_SUBMIT_MS = 3000;
export function assertNotDoubleSubmit(key, what = "Yeh entry") {
  const now = Date.now();
  for (const [k, t] of recentSubmits) if (now - t > DOUBLE_SUBMIT_MS) recentSubmits.delete(k);
  if (recentSubmits.has(key)) throw badRequest(`${what} abhi abhi save ho chuki hai — double click ki wajah se dobara nahi banai gayi.`, 409);
}
export function markSubmitted(key) {
  recentSubmits.set(key, Date.now());
}
export function invoiceSubmitKey(kind, data) {
  return JSON.stringify([
    kind, data.customerId || null, Number(data.total) || 0, Number(data.advance) || 0, data.paymentMode || null,
    (data.items || []).map((i) => [i.productId || i.name, Number(i.qty) || 0, Number(i.salePrice ?? i.unitPrice) || 0]),
    data.isOldUdaar ? [data.createdAt || null, data.note || ""] : null,
  ]);
}
