// Customer ke udaar (baqaya) ka EK hi hisaab — Customer Profile, Checkout,
// Invoice Form aur Invoice Print sab yahi use karte hain, taake kisi jagah
// farq na aaye.

const num = (v) => Number(v) || 0;
const digits = (s) => String(s || "").replace(/\D/g, "");

// Ek invoice mein se kitna paisa mil chuka (advance + baad ki payments) aur kitna baqi hai.
// (Customer profile ka invoicesWithBalance wala formula — bilkul wohi.)
export function invoiceBalance(inv) {
  const pays = Array.isArray(inv?.payments) ? inv.payments : [];
  const advInPay = pays
    .filter((p) => p.note && p.note.includes("Advance at sale"))
    .reduce((s, p) => s + num(p.amount), 0);
  const otherPay = pays
    .filter((p) => !p.note || !p.note.includes("Advance at sale"))
    .reduce((s, p) => s + num(p.amount), 0);
  // advance agar payments mein pehle se hai to dobara mat gino
  const advance = advInPay > 0 ? advInPay : num(inv?.advance);
  const paid = advance + otherPay;
  const total = num(inv?.total);
  // credited: bill se zyada wasool hui raqam (double entry) ginti mein nahi — paid ≤ total
  return { advance, otherPay, paid, credited: Math.min(paid, total), excess: Math.max(0, paid - total), due: Math.max(0, total - paid) };
}

// Customer profile ki tarah invoice ko customer se match karo:
// customerId se, warna (purani invoices) naam + phone se.
export function invoiceBelongsToCustomer(inv, customer) {
  if (!inv || !customer) return false;
  if (inv.customerId && customer.id != null && String(inv.customerId) === String(customer.id)) return true;
  if (inv.customerId) return false;
  const invName = (inv.customerName || "").trim().toLowerCase();
  const custName = (customer.name || "").trim().toLowerCase();
  if (!invName || !custName || invName !== custName) return false;
  const a = digits(inv.customerPhone);
  const b = digits(customer.phone);
  // adhoora/ghalat phone (jaise "08") ko match ka sabab na banao — purani invoices par
  // aksar yahi likha hota hai, aur wo isi naam ke customer ki hoti hain.
  return a.length < 7 || b.length < 7 || a === b;
}

// Customer ka kul udaar (jo profile par "Outstanding" dikhta hai).
// excludeId  : is invoice ko hisaab se bahar rakho (edit / print ke waqt)
// beforeDate : sirf is date/time se pehle ki invoices (purani invoice reprint ke liye)
export function customerOutstanding(customer, allInvoices = [], { excludeId = null, beforeDate = null } = {}) {
  if (!customer) return 0;
  const cutoff = beforeDate ? new Date(beforeDate).getTime() : null;
  let total = 0;
  for (const inv of allInvoices) {
    if (excludeId != null && String(inv.id) === String(excludeId)) continue;
    if (!invoiceBelongsToCustomer(inv, customer)) continue;
    if (cutoff != null && inv.createdAt && new Date(inv.createdAt).getTime() > cutoff) continue;
    total += invoiceBalance(inv).due;
  }
  return total;
}
