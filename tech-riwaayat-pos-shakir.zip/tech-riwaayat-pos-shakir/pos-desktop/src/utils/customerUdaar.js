// Customer ke udaar (baqaya) ka EK hi hisaab — Customer Profile, Checkout,
// Invoice Form aur Invoice Print sab yahi use karte hain, taake kisi jagah
// farq na aaye.

const num = (v) => Number(v) || 0;
const digits = (s) => String(s || "").replace(/\D/g, "");

// Ek invoice mein se kitna paisa mil chuka (advance + baad ki payments) aur kitna baqi hai.
// (Customer profile ka invoicesWithBalance wala formula — bilkul wohi.)
export function invoiceBalance(inv) {
  const pays = Array.isArray(inv?.payments) ? inv.payments : [];
  const advInPay = pays
    .filter((p) => p.note && p.note.includes("Advance at sale"))
    .reduce((s, p) => s + num(p.amount), 0);
  const otherPay = pays
    .filter((p) => !p.note || !p.note.includes("Advance at sale"))
    .reduce((s, p) => s + num(p.amount), 0);
  // advance agar payments mein pehle se hai to dobara mat gino
  const advance = advInPay > 0 ? advInPay : num(inv?.advance);
  const paid = advance + otherPay;
  const total = num(inv?.total);
  // credited: bill se zyada wasool hui raqam (double entry) ginti mein nahi — paid ≤ total
  return { advance, otherPay, paid, credited: Math.min(paid, total), excess: Math.max(0, paid - total), due: Math.max(0, total - paid) };
}

// Customer profile ki tarah invoice ko customer se match karo:
// customerId se, warna (purani invoices) naam + phone se.
export function invoiceBelongsToCustomer(inv, customer) {
  if (!inv || !customer) return false;
  if (inv.customerId && customer.id != null && String(inv.customerId) === String(customer.id)) return true;
  if (inv.customerId) return false;
  const invName = (inv.customerName || "").trim().toLowerCase();
  const custName = (customer.name || "").trim().toLowerCase();
  if (!invName || !custName || invName !== custName) return false;
  const a = digits(inv.customerPhone);
  const b = digits(customer.phone);
  // adhoora/ghalat phone (jaise "08") ko match ka sabab na banao — purani invoices par
  // aksar yahi likha hota hai, aur wo isi naam ke customer ki hoti hain.
  return a.length < 7 || b.length < 7 || a === b;
}

// Customer ka kul udaar (jo profile par "Outstanding" dikhta hai).
// excludeId  : is invoice ko hisaab se bahar rakho (edit / print ke waqt)
// beforeDate : sirf is date/time se pehle ki invoices (purani invoice reprint ke liye)
export function customerOutstanding(customer, allInvoices = [], { excludeId = null, beforeDate = null } = {}) {
  if (!customer) return 0;
  const cutoff = beforeDate ? new Date(beforeDate).getTime() : null;
  let total = 0;
  for (const inv of allInvoices) {
    if (excludeId != null && String(inv.id) === String(excludeId)) continue;
    if (!invoiceBelongsToCustomer(inv, customer)) continue;
    if (cutoff != null && inv.createdAt && new Date(inv.createdAt).getTime() > cutoff) continue;
    total += invoiceBalance(inv).due;
  }
  return total;
}

// Ek customer ko invoice se match karne ka safe tareeqa jab customerId na ho
// (purani invoices / print): pehle customerId, phir naam+phone (profile wala rule).
// Sirf phone par match tab karo jab phone poora ho (7+ digits) — warna "08" jaisa
// adhoora number kisi bhi doosre customer se jod deta hai.
export function resolveInvoiceCustomer(inv, customers = []) {
  if (!inv) return null;
  if (inv.customerId) {
    const byId = customers.find((c) => String(c.id) === String(inv.customerId));
    if (byId) return byId;
  }
  const byRule = customers.find((c) => invoiceBelongsToCustomer(inv, c));
  if (byRule) return byRule;
  const ph = digits(inv.customerPhone);
  const invName = (inv.customerName || "").trim();
  if (!inv.customerId && ph.length >= 7 && !invName) {
    return customers.find((c) => digits(c.phone) === ph) || null;
  }
  return null;
}

// Sab customers ka udaar EK saath (Dashboard "Top Customers by Due Amount" ke liye) —
// har customer ka number bilkul wahi jo uske Profile par "Outstanding" dikhta hai
// (invoiceBelongsToCustomer + invoiceBalance), is liye purani invoices bhi gini jati hain.
//   byCustomer     : Map(customerId -> due)
//   list           : [{ id, name, due }] (sirf jin ka udaar > 0, zyada se kam)
//   totalReceivable: sab invoices ka kul baqaya (har invoice sirf ek baar)
//   unassigned     : {due, count} — wo udaar jo kisi customer se juda hi nahi
export function customerDueSummary(customers = [], invoices = []) {
  const byId = new Map(customers.map((c) => [String(c.id), c]));
  const byName = new Map();
  for (const c of customers) {
    const k = (c.name || "").trim().toLowerCase();
    if (!k) continue;
    if (!byName.has(k)) byName.set(k, []);
    byName.get(k).push(c);
  }
  const dueMap = new Map();
  let totalReceivable = 0;
  const unassigned = { due: 0, count: 0 };

  for (const inv of invoices) {
    const due = invoiceBalance(inv).due;
    if (due <= 0.005) continue;
    totalReceivable += due;
    let owners = [];
    if (inv.customerId) {
      const c = byId.get(String(inv.customerId));
      if (c) owners = [c];
    } else {
      const k = (inv.customerName || "").trim().toLowerCase();
      owners = (byName.get(k) || []).filter((c) => invoiceBelongsToCustomer(inv, c));
    }
    if (!owners.length) { unassigned.due += due; unassigned.count += 1; continue; }
    for (const c of owners) dueMap.set(String(c.id), (dueMap.get(String(c.id)) || 0) + due);
  }

  const r2 = (v) => Math.round(v * 100) / 100;
  const list = [];
  for (const [id, due] of dueMap) {
    if (due > 0.005) list.push({ id, name: byId.get(id)?.name || "Unknown", due: r2(due) });
  }
  list.sort((a, b) => b.due - a.due);
  return {
    byCustomer: new Map([...dueMap].map(([k, v]) => [k, r2(v)])),
    list,
    totalReceivable: r2(totalReceivable),
    unassigned: { due: r2(unassigned.due), count: unassigned.count },
  };
}
