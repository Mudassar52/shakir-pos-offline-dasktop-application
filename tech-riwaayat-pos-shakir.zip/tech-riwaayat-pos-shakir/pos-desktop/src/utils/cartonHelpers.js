// Carton (CTN) helpers.
//
// Stock, quantity aur price hamesha PIECES ke hisaab se store hote hain
// (database mein koi badlao nahi). Product ka `ctn` field = "ek carton mein
// kitne pieces". Carton mein sell/buy karne par sirf entry ka tareeqa badalta
// hai: cartons × pieces-per-carton = pieces.
export const perCtnOf = (product) => Math.max(0, Math.floor(Number(product?.ctn) || 0));

// 125 pcs, 12 per carton -> { ctn: 10, pcs: 5 }
export function splitCtn(qty, per) {
  const q = Math.max(0, Number(qty) || 0);
  if (!per || per <= 0) return { ctn: 0, pcs: q };
  return { ctn: Math.floor(q / per), pcs: Math.round((q % per) * 1000) / 1000 };
}

// "10 CTN + 5 pcs" — agar carton size set nahi to khali string
export function formatCtn(qty, per) {
  if (!per || per <= 0) return "";
  const { ctn, pcs } = splitCtn(qty, per);
  if (ctn === 0) return `${pcs} pcs`;
  return pcs > 0 ? `${ctn} CTN + ${pcs} pcs` : `${ctn} CTN`;
}

export const ctnCount = (qty, per) => (per > 0 ? Math.floor((Number(qty) || 0) / per) : 0);
