// ── Ledger helpers (Customer: Billed / Received / Running Balance · Supplier: Purchased / Paid / Running Balance) ──
import { downloadCSV } from "./exportUtils";
import { invoiceBelongsToCustomer } from "./customerUdaar";

export const fmtMoney = (v) => `Rs ${Number(v || 0).toLocaleString("en-PK", { maximumFractionDigits: 2 })}`;
export const fmtDate = (iso) => (iso ? new Date(iso).toLocaleDateString("en-PK", { day: "2-digit", month: "short", year: "numeric" }) : "—");
const dayOf = (iso) => String(iso || "").slice(0, 10);

const TYPE_ORDER = { opening: 0, invoice: 1, old: 1, adj_debit: 1, purchase: 1, return: 2, payment: 3, advance: 3, advance_used: 3, adj_credit: 3 };

// Column names jo user ko dikhte hain. Andar ka hisaab wahi debit/credit hai,
// sirf naam aasan kiye hain:
//   Customer: Billed (bill/udhaar lagaya)  | Received (paise mile)
//   Supplier: Purchased (maal liya)        | Paid (paise diye / maal wapis)
export const ledgerColumns = (side) => side === "debit"
  ? { left: "Billed", right: "Received", leftKey: "debit", rightKey: "credit", leftTotal: "Total Billed", rightTotal: "Total Received" }
  : { left: "Purchased", right: "Paid", leftKey: "credit", rightKey: "debit", leftTotal: "Total Purchased", rightTotal: "Total Paid" };

export function sortLedger(entries) {
  return [...entries].sort((a, b) => {
    const da = dayOf(a.date), db = dayOf(b.date);
    if (da !== db) return da < db ? -1 : 1;
    const o = (TYPE_ORDER[a.type] ?? 9) - (TYPE_ORDER[b.type] ?? 9);
    if (o !== 0) return o;
    return String(a.date).localeCompare(String(b.date));
  });
}

// Customer ka invoice-match — Customer Profile ke Outstanding wala EK hi rule (customerUdaar.js).
export const matchesCustomer = (inv, customer) => invoiceBelongsToCustomer(inv, customer);

/**
 * Customer ledger (receivable): DEBIT = customer par charha (invoice, purana
 * udhaar, charge), CREDIT = customer ne diya / kam hua (payment, advance,
 * discount). Balance = debit − credit → +ve = customer ne dena hai (Dr),
 * −ve = customer ka advance (Cr).
 *
 * "Advance Balance Used" payments ledger mein alag credit nahi bante, kyunke
 * advance ka credit pehle hi us waqt lag chuka hota hai jab advance liya gaya.
 * `cash: true` = wo entries jo usi waqt poori ada ho gayi (cash sale) — UI
 * inhein chhupa sakta hai, balance par koi farq nahi parta.
 */
export function buildCustomerLedger(customer, invoices = []) {
  const entries = [];
  const mine = invoices.filter((inv) => matchesCustomer(inv, customer));

  for (const inv of mine) {
    const num = inv.invoiceNumber ? String(inv.invoiceNumber).padStart(3, "0") : String(inv.id).slice(0, 6);
    const isOld = !!inv.isOldUdaar;
    const total = Number(inv.total) || 0;
    const isCash = !isOld && inv.paymentMode !== "udaar" && inv.paymentStatus === "paid";
    const ref = isOld ? "OLD" : `INV-${num}`;
    const itemsText = (inv.items || []).slice(0, 2).map((i) => `${i.name} ×${i.qty}`).join(", ") + ((inv.items || []).length > 2 ? ` +${inv.items.length - 2} more` : "");

    entries.push({
      id: `inv-${inv.id}`, date: inv.createdAt, type: isOld ? "old" : "invoice",
      typeLabel: isOld ? "Purana Udhaar" : "Invoice", reference: ref,
      description: isOld ? inv.note || "Purana Udhaar" : itemsText || "Sale", debit: total, credit: 0, cash: isCash, invoiceId: inv.id,
    });

    const pays = inv.payments || [];
    const advUsedTotal = pays.filter((p) => p.note === "Advance Balance Used").reduce((sum, p) => sum + (Number(p.amount) || 0), 0);
    // Ek invoice par credit uske total se zyada nahi ho sakta — double entry wali extra raqam
    // balance mein nahi ginti (warna Outstanding se ledger ka balance alag aa jata tha).
    const cap = Math.max(0, total - advUsedTotal);
    let credited = 0;
    const addCredit = (id, date, desc, amt, cashFlag) => {
      const take = Math.max(0, Math.min(amt, cap - credited));
      credited += take;
      if (take > 0.0049) entries.push({ id, date, type: "payment", typeLabel: "Payment", reference: ref, description: desc, debit: 0, credit: take, ...(cashFlag ? { cash: true } : {}), invoiceId: inv.id });
      const extra = amt - take;
      if (extra > 0.009) entries.push({ id: `${id}-extra`, date, type: "payment", typeLabel: "Extra Payment", reference: ref, description: `Rs ${Math.round(extra).toLocaleString("en-PK")} bill se zyada darj hai — balance mein shamil nahi (shayad double entry)`, debit: 0, credit: 0, invoiceId: inv.id });
    };
    const hasAdvAtSale = pays.some((p) => p.note && p.note.includes("Advance at sale") && Number(p.amount) > 0);
    // advance sirf `advance` field mein ho (payments mein "Advance at sale" nahi) — Profile bhi isay gintा hai
    if (!hasAdvAtSale && !isCash && Number(inv.advance) > 0) addCredit(`adv-${inv.id}`, inv.createdAt, "Advance at sale", Number(inv.advance));
    pays.forEach((p, i) => {
      const amt = Number(p.amount) || 0;
      if (amt <= 0) return;
      if (p.note === "Advance Balance Used") {
        // Sirf dikhane ke liye (balance par asar nahi): advance is bill mein adjust hua
        entries.push({ id: `advused-${inv.id}-${i}`, date: p.date || inv.createdAt, type: "advance_used", typeLabel: "Advance Used", reference: ref, description: `Advance mein se Rs ${amt.toLocaleString("en-PK")} is bill mein adjust hua`, debit: 0, credit: 0, invoiceId: inv.id });
        return;
      }
      addCredit(`pay-${inv.id}-${i}`, p.date || inv.createdAt, p.note || "Payment received", amt);
    });
    // Cash/paid-on-the-spot sale: baaqi poori raqam usi waqt wasool
    if (inv.paymentStatus === "paid" && !isOld) {
      const rest = cap - credited;
      if (rest > 0.009) addCredit(`cash-${inv.id}`, inv.createdAt, isCash ? "Paid on the spot" : "Paid in full", rest, isCash);
    }
  }

  // Advance deposits + manual balance adjustments (customer.adjustments JSON)
  (customer.adjustments || []).forEach((a, i) => {
    const amt = Number(a.amount) || 0;
    if (amt <= 0) return;
    if (a.type === "advance") entries.push({ id: `dep-${i}`, date: a.date, type: "advance", typeLabel: a.returnId ? "Return Credit" : "Advance Received", reference: a.returnId ? "RET" : "ADV", description: a.reason || "Customer ne advance diya", debit: 0, credit: amt });
    else if (a.type === "advance_refund") entries.push({ id: `advref-${i}`, date: a.date, type: "advance_refund", typeLabel: "Advance Refund", reference: "REF", description: a.reason || "Advance wapis kiya", debit: amt, credit: 0 });
    else if (a.type === "credit") entries.push({ id: `adjc-${i}`, date: a.date, type: "adj_credit", typeLabel: "Discount / Maafi", reference: "ADJ", description: a.reason || "Balance adjustment", debit: 0, credit: amt });
    else if (a.type === "debit") entries.push({ id: `adjd-${i}`, date: a.date, type: "adj_debit", typeLabel: "Extra Charge", reference: "ADJ", description: a.reason || "Balance adjustment", debit: amt, credit: 0 });
  });

  return sortLedger(entries);
}

/**
 * Entries par range lagao aur running balance nikalo.
 * side: "debit" (customer: balance = debit − credit) ya "credit" (supplier: credit − debit)
 * Range se pehle ka sara hisaab broughtForward (B/F) ban jata hai.
 */
export function computeLedger(entries, { from, to, side = "debit", types = null, search = "", hideCash = false } = {}) {
  const sign = side === "debit" ? 1 : -1; // balance = sign * (debit - credit)
  let bf = 0;
  let running = 0;
  let totalDebit = 0, totalCredit = 0;
  const rows = [];
  const q = search.trim().toLowerCase();

  for (const e of sortLedger(entries)) {
    const day = dayOf(e.date);
    if (from && day < from) { bf += sign * (e.debit - e.credit); running = bf; continue; }
    if (to && day > to) continue;
    running += sign * (e.debit - e.credit);
    totalDebit += e.debit; totalCredit += e.credit;
    const hidden =
      (hideCash && e.cash) ||
      (types && types.size && !types.has(e.type)) ||
      (q && !`${e.description} ${e.reference} ${e.typeLabel}`.toLowerCase().includes(q));
    if (!hidden) rows.push({ ...e, balance: running });
  }
  return { rows, broughtForward: bf, totalDebit, totalCredit, closing: bf + sign * (totalDebit - totalCredit) };
}

// Dr/Cr ki jagah seedhe alfaaz: "Baaqi" = jo dena/lena baaqi hai, "Advance" = pehle se diya hua.
export const balanceLabel = (bal) => {
  const abs = fmtMoney(Math.abs(bal));
  if (Math.abs(bal) < 0.005) return abs;
  return `${abs} ${bal > 0 ? "Baaqi" : "Advance"}`;
};

export function exportLedgerCSV(name, ledger, side, newestFirst = false) {
  const col = ledgerColumns(side);
  const bf = ["", "", "Opening Balance (B/F)", "", "", balanceLabel(ledger.broughtForward)];
  const line = (r) => [fmtDate(r.date), r.reference, `${r.typeLabel}: ${r.description}`, r[col.leftKey] || "", r[col.rightKey] || "", balanceLabel(r.balance)];
  const body = ledger.rows.map(line);
  const rows = newestFirst ? [...body.reverse(), bf] : [bf, ...body];
  rows.push(["", "", "Closing Balance", ledger[side === "debit" ? "totalDebit" : "totalCredit"], ledger[side === "debit" ? "totalCredit" : "totalDebit"], balanceLabel(ledger.closing)]);
  downloadCSV(name, ["Date", "Ref", "Particulars", col.left, col.right, "Running Balance"], rows);
}

const esc = (v) => String(v ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

export function printLedger({ title, partyLabel, party, shopName, ledger, side, range, note, newestFirst = false }) {
  const col = ledgerColumns(side);
  const win = window.open("", "_blank");
  if (!win) return;
  const printRows = newestFirst ? [...ledger.rows].reverse() : ledger.rows;
  const rowsHtml = printRows.map((r) => `<tr><td>${fmtDate(r.date)}</td><td>${esc(r.reference)}</td><td><b>${esc(r.typeLabel)}</b> ${esc(r.description)}</td><td class="n">${r[col.leftKey] ? fmtMoney(r[col.leftKey]) : ""}</td><td class="n">${r[col.rightKey] ? fmtMoney(r[col.rightKey]) : ""}</td><td class="n b">${esc(balanceLabel(r.balance))}</td></tr>`).join("");
  const bfRow = `<tr class="bf"><td colspan="5">Opening Balance (B/F)</td><td class="n">${esc(balanceLabel(ledger.broughtForward))}</td></tr>`;
  const period = range?.from && range?.to ? `${fmtDate(range.from)} — ${fmtDate(range.to)}` : "All transactions";
  win.document.write(`<!DOCTYPE html><html><head><meta charset="utf-8"><title>${esc(title)} — ${esc(party.name)}</title><style>
  *{box-sizing:border-box;margin:0;padding:0}body{font-family:Arial,sans-serif;font-size:11px;color:#1e293b;padding:24px}
  .top{display:flex;justify-content:space-between;border-bottom:2px solid #1e293b;padding-bottom:10px;margin-bottom:12px}
  h1{font-size:18px}h2{font-size:13px;margin-top:2px;color:#475569}.muted{color:#64748b;font-size:10px}
  .box{background:#f8fafc;border:1px solid #e2e8f0;border-radius:6px;padding:8px 12px;margin-bottom:12px;display:flex;justify-content:space-between}
  table{width:100%;border-collapse:collapse}th{background:#1e293b;color:#fff;font-size:10px;text-transform:uppercase;padding:7px 8px;text-align:left}
  th.n,td.n{text-align:right}td{padding:6px 8px;border-bottom:1px solid #e2e8f0;vertical-align:top}.b{font-weight:700}
  tr.bf td,tr.cl td{background:#f1f5f9;font-weight:700}tr.cl td{border-top:2px solid #1e293b}
  .sig{display:flex;justify-content:space-between;margin-top:46px}.sig div{border-top:1px solid #94a3b8;padding-top:4px;width:160px;text-align:center;font-size:10px;color:#64748b}
  </style></head><body>
  <div class="top"><div><h1>${esc(shopName || "Tech Riwaayat POS")}</h1><h2>${esc(title)}</h2></div><div style="text-align:right"><div class="muted">Statement period</div><b>${esc(period)}</b><div class="muted" style="margin-top:3px">Generated ${new Date().toLocaleString("en-PK")}</div></div></div>
  <div class="box"><div><div class="muted">${esc(partyLabel)}</div><b style="font-size:14px">${esc(party.name)}</b><div>${esc(party.phone || "")} ${party.city ? "· " + esc(party.city) : ""}</div></div>
  <div style="text-align:right"><div class="muted">Closing Balance</div><b style="font-size:16px">${esc(balanceLabel(ledger.closing))}</b></div></div>
  <table><thead><tr><th>Date</th><th>Ref</th><th>Particulars</th><th class="n">${col.left}</th><th class="n">${col.right}</th><th class="n">Running Balance</th></tr></thead><tbody>
  ${newestFirst ? "" : bfRow}
  ${rowsHtml}
  ${newestFirst ? bfRow : ""}
  <tr class="cl"><td colspan="3">Total / Closing Balance</td><td class="n">${fmtMoney(side === "debit" ? ledger.totalDebit : ledger.totalCredit)}</td><td class="n">${fmtMoney(side === "debit" ? ledger.totalCredit : ledger.totalDebit)}</td><td class="n">${esc(balanceLabel(ledger.closing))}</td></tr>
  </tbody></table>
  ${note ? `<p class="muted" style="margin-top:10px">${esc(note)}</p>` : ""}
  <div class="sig"><div>Prepared by</div><div>${esc(partyLabel)} signature</div></div></body></html>`);
  win.document.close();
  win.focus();
  setTimeout(() => win.print(), 250);
}
