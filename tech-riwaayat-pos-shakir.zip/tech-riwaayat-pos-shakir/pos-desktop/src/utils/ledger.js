// ── Ledger helpers (Customer: Billed / Received / Running Balance · Supplier: Purchased / Paid / Running Balance) ──
import { downloadCSV } from "./exportUtils";
import { invoiceBelongsToCustomer } from "./customerUdaar";

export const fmtMoney = (v) => `Rs ${Number(v || 0).toLocaleString("en-PK", { maximumFractionDigits: 2 })}`;
export const fmtDate = (iso) => (iso ? new Date(iso).toLocaleDateString("en-PK", { day: "2-digit", month: "short", year: "numeric" }) : "—");
export const fmtTime = (iso) => (iso && hasClockTime(iso) ? new Date(iso).toLocaleTimeString("en-PK", { hour: "2-digit", minute: "2-digit", hour12: true }) : "");
export const fmtDateTime = (iso) => { const t = fmtTime(iso); return t ? `${fmtDate(iso)}, ${t}` : fmtDate(iso); };
const dayOf = (iso) => String(iso || "").slice(0, 10);

const TYPE_ORDER = { opening: 0, invoice: 1, old: 1, adj_debit: 1, purchase: 1, return: 2, payment: 3, advance: 3, advance_used: 3, adj_credit: 3 };

// Column names jo user ko dikhte hain. Andar ka hisaab wahi debit/credit hai,
// sirf naam aasan kiye hain:
//   Customer: Billed (bill/udhaar lagaya)  | Received (paise mile)
//   Supplier: Purchased (maal liya)        | Paid (paise diye / maal wapis)
export const ledgerColumns = (side) => side === "debit"
  ? { left: "Billed", right: "Received", leftKey: "debit", rightKey: "credit", leftTotal: "Total Billed", rightTotal: "Total Received" }
  : { left: "Purchased", right: "Paid", leftKey: "credit", rightKey: "debit", leftTotal: "Total Purchased", rightTotal: "Total Paid" };

// Purani payments sirf date (00:00) ke saath save hoti thi — unka koi asli time nahi hota.
export const hasClockTime = (iso) => !!iso && !/T00:00:00(\.0+)?Z$/.test(String(iso));

// Sort: pehle din, phir us din ke andar asli time. Bina time wali payment din ke aakhir mein
// jaati hai (taake us din ke bills ke baad lage), bina time wala bill/udhaar din ke shuru mein.
const DEBIT_TYPES = new Set(["opening", "invoice", "old", "adj_debit", "purchase"]);
// Advance jama karna bhi din ke shuru mein — wo usi din ke bill se pehle aata hai jisme use hota hai.
const START_TYPES = new Set([...DEBIT_TYPES, "advance"]);
const withinDay = (e) => {
  if (hasClockTime(e.date)) return new Date(e.date).getTime();
  const base = new Date(e.date).getTime();
  return START_TYPES.has(e.type) ? base - 1 : base + 86399999;
};

export function sortLedger(entries) {
  return [...entries].sort((a, b) => {
    const da = dayOf(a.date), db = dayOf(b.date);
    if (da !== db) return da < db ? -1 : 1;
    const t = withinDay(a) - withinDay(b);
    if (t !== 0) return t;
    return (TYPE_ORDER[a.type] ?? 9) - (TYPE_ORDER[b.type] ?? 9);
  });
}

// Customer ka invoice-match — Customer Profile ke Outstanding wala EK hi rule (customerUdaar.js).
export const matchesCustomer = (inv, customer) => invoiceBelongsToCustomer(inv, customer);

/**
 * Customer ledger (receivable): DEBIT = customer par charha (invoice, purana
 * udhaar, charge), CREDIT = customer ne diya / kam hua (payment, advance,
 * discount). Balance = debit − credit → +ve = customer ne dena hai (Dr),
 * −ve = customer ka advance (Cr).
 *
 * "Advance Balance Used" payments ledger mein alag credit nahi bante, kyunke
 * advance ka credit pehle hi us waqt lag chuka hota hai jab advance liya gaya.
 * `cash: true` = wo entries jo usi waqt poori ada ho gayi (cash sale) — UI
 * inhein chhupa sakta hai, balance par koi farq nahi parta.
 */
export function buildCustomerLedger(customer, invoices = []) {
  const entries = [];
  const mine = invoices.filter((inv) => matchesCustomer(inv, customer));
  // One "Receive Payment" action is stored on every invoice it was spread across (same date + note).
  // Group those back into ONE ledger entry; the invoice-wise split goes in `allocations`.
  const groups = new Map();

  for (const inv of mine) {
    const num = inv.invoiceNumber ? String(inv.invoiceNumber).padStart(3, "0") : String(inv.id).slice(0, 6);
    const isOld = !!inv.isOldUdaar;
    const total = Number(inv.total) || 0;
    const isCash = !isOld && inv.paymentMode !== "udaar" && inv.paymentStatus === "paid";
    const ref = isOld ? "OLD" : `INV-${num}`;
    const itemsText = (inv.items || []).slice(0, 2).map((i) => `${i.name} ×${i.qty}`).join(", ") + ((inv.items || []).length > 2 ? ` +${inv.items.length - 2} more` : "");

    entries.push({
      id: `inv-${inv.id}`, date: inv.createdAt, type: isOld ? "old" : "invoice",
      typeLabel: isOld ? "Old Balance" : "Invoice", reference: ref,
      description: isOld ? (!inv.note || inv.note === "Purana Udhaar" ? "Previous balance carried forward" : inv.note) : itemsText || "Sale", debit: total, credit: 0, cash: isCash, invoiceId: inv.id,
    });

    const pays = inv.payments || [];
    const advUsedTotal = pays.filter((p) => p.note === "Advance Balance Used").reduce((sum, p) => sum + (Number(p.amount) || 0), 0);
    // Ek invoice par credit uske total se zyada nahi ho sakta — double entry wali extra raqam
    // balance mein nahi ginti (warna Outstanding se ledger ka balance alag aa jata tha).
    const cap = Math.max(0, total - advUsedTotal);
    let credited = 0;
    const addCredit = (id, date, desc, amt, opts = {}) => {
      const take = Math.max(0, Math.min(amt, cap - credited));
      credited += take;
      if (take > 0.0049) {
        if (opts.group) {
          const g = groups.get(opts.group) || { date, note: desc, credit: 0, allocations: [] };
          if (String(date) > String(g.date)) g.date = date;
          g.credit += take;
          g.allocations.push({ ref, amount: take, invoiceId: inv.id });
          groups.set(opts.group, g);
        } else {
          entries.push({ id, date, type: "payment", typeLabel: opts.typeLabel || "Payment", reference: ref, description: desc, debit: 0, credit: take, ...(opts.cash ? { cash: true } : {}), invoiceId: inv.id });
        }
      }
      const extra = amt - take;
      if (extra > 0.009) entries.push({ id: `${id}-extra`, date, type: "payment", typeLabel: "Extra Payment", reference: ref, description: `Rs ${Math.round(extra).toLocaleString("en-PK")} recorded above the bill amount — not included in balance (possible duplicate entry)`, debit: 0, credit: 0, invoiceId: inv.id });
    };
    const hasAdvAtSale = pays.some((p) => p.note && p.note.includes("Advance at sale") && Number(p.amount) > 0);
    // advance sirf `advance` field mein ho (payments mein "Advance at sale" nahi) — Profile bhi isay gintा hai
    if (!hasAdvAtSale && !isCash && Number(inv.advance) > 0) addCredit(`adv-${inv.id}`, inv.createdAt, "Advance paid at sale", Number(inv.advance), { typeLabel: "Advance at Sale" });
    pays.forEach((p, i) => {
      const amt = Number(p.amount) || 0;
      if (amt <= 0) return;
      if (p.note === "Advance Balance Used") {
        // Sirf dikhane ke liye (balance par asar nahi): advance is bill mein adjust hua
        entries.push({ id: `advused-${inv.id}-${i}`, date: p.date || inv.createdAt, type: "advance_used", typeLabel: "Advance Used", reference: ref, description: `Rs ${amt.toLocaleString("en-PK")} adjusted from advance balance against this bill`, debit: 0, credit: 0, infoOnly: true, applied: amt, invoiceId: inv.id });
        return;
      }
      // Purani payment par sirf date hoti hai — agar usi din invoice update hua to wohi asli time hai
      const rawWhen = p.date || inv.createdAt;
      const when = !hasClockTime(rawWhen) && inv.updatedAt && dayOf(inv.updatedAt) === dayOf(rawWhen) ? inv.updatedAt : rawWhen;
      if (isCash) addCredit(`pay-${inv.id}-${i}`, when, p.note || "Paid on the spot", amt, { cash: true });
      else if (p.note && p.note.includes("Advance at sale")) addCredit(`pay-${inv.id}-${i}`, when, "Advance paid at sale", amt, { typeLabel: "Advance at Sale" });
      else addCredit(`pay-${inv.id}-${i}`, when, p.note || "Payment received", amt, { group: `${rawWhen}|${p.note || ""}` });
    });
    // Cash/paid-on-the-spot sale: baaqi poori raqam usi waqt wasool
    if (inv.paymentStatus === "paid" && !isOld) {
      const rest = cap - credited;
      if (rest > 0.009) addCredit(`cash-${inv.id}`, inv.createdAt, isCash ? "Paid on the spot" : "Paid in full", rest, { cash: isCash });
    }
  }

  for (const [key, g] of groups) {
    const refs = [...new Set(g.allocations.map((a) => a.ref))];
    const plain = !g.note || g.note === "Payment received";
    entries.push({
      id: `grp-${key}`, date: g.date, type: "payment", typeLabel: "Payment Received",
      reference: refs.length === 1 ? refs[0] : "",
      description: refs.length === 1 ? (plain ? "" : g.note) : `${plain ? "" : g.note + " — "}spread across ${refs.length} invoices`,
      debit: 0, credit: g.credit, allocations: g.allocations,
    });
  }

  // Advance deposits + manual balance adjustments (customer.adjustments JSON)
  (customer.adjustments || []).forEach((a, i) => {
    const amt = Number(a.amount) || 0;
    if (amt <= 0) return;
    if (a.type === "advance") entries.push({ id: `dep-${i}`, date: a.date, type: "advance", typeLabel: a.returnId ? "Return Credit" : "Advance Received", reference: a.returnId ? "RET" : "ADV", description: a.reason || "Advance received from customer", debit: 0, credit: amt });
    else if (a.type === "advance_refund") entries.push({ id: `advref-${i}`, date: a.date, type: "advance_refund", typeLabel: "Advance Refund", reference: "REF", description: a.reason || "Advance refunded to customer", debit: amt, credit: 0 });
    else if (a.type === "credit") entries.push({ id: `adjc-${i}`, date: a.date, type: "adj_credit", typeLabel: "Discount / Waiver", reference: "ADJ", description: a.reason || "Balance adjustment", debit: 0, credit: amt });
    else if (a.type === "debit") entries.push({ id: `adjd-${i}`, date: a.date, type: "adj_debit", typeLabel: "Extra Charge", reference: "ADJ", description: a.reason || "Balance adjustment", debit: amt, credit: 0 });
  });

  return sortLedger(entries);
}

/**
 * Entries par range lagao aur running balance nikalo.
 * side: "debit" (customer: balance = debit − credit) ya "credit" (supplier: credit − debit)
 * Range se pehle ka sara hisaab broughtForward (B/F) ban jata hai.
 */
export function computeLedger(entries, { from, to, side = "debit", types = null, search = "", hideCash = false } = {}) {
  const sign = side === "debit" ? 1 : -1; // balance = sign * (debit - credit)
  let bf = 0;
  let running = 0;
  let totalDebit = 0, totalCredit = 0;
  const rows = [];
  const q = search.trim().toLowerCase();

  for (const e of sortLedger(entries)) {
    const day = dayOf(e.date);
    if (from && day < from) { bf += sign * (e.debit - e.credit); running = bf; continue; }
    if (to && day > to) continue;
    running += sign * (e.debit - e.credit);
    totalDebit += e.debit; totalCredit += e.credit;
    const hidden =
      (hideCash && e.cash) ||
      (types && types.size && !types.has(e.type)) ||
      (q && !`${e.description} ${e.reference} ${e.typeLabel}`.toLowerCase().includes(q));
    if (!hidden) rows.push({ ...e, balance: running });
  }
  return { rows, broughtForward: bf, totalDebit, totalCredit, closing: bf + sign * (totalDebit - totalCredit) };
}

// Customer ledger ke aakhir mein: invoices ka baqaya, advance jo abhi baqi hai, aur dono ka net.
export function advanceSummary(entries = []) {
  let adv = 0;
  for (const e of entries) {
    if (e.type === "advance") adv += e.credit;
    else if (e.type === "advance_refund") adv -= e.debit;
    else if (e.type === "advance_used") adv -= e.applied || 0;
  }
  return Math.max(0, Math.round(adv * 100) / 100);
}

// Plain-English balance: "Due" = amount still to be paid/received, "Advance" = paid ahead of time.
export const balanceLabel = (bal) => {
  const abs = fmtMoney(Math.abs(bal));
  if (Math.abs(bal) < 0.005) return abs;
  return `${abs} ${bal > 0 ? "Due" : "Advance"}`;
};

// On-screen / printed running balance: positive shows just the amount, advance is tagged.
export const balanceText = (bal) => (bal < -0.005 ? `${fmtMoney(Math.abs(bal))} Advance` : fmtMoney(bal < 0.005 ? 0 : bal));

// Rows for the "Payment ledger" (money received / paid, newest handled by the caller).
// Customer: payments, advances, advance applied to bills. Supplier: payments made.
export const isPaymentRow = (r, side) => (side === "debit" ? ["payment", "advance", "advance_used"].includes(r.type) : r.type === "payment");
export const paymentAmount = (r, side) => (r.infoOnly ? r.applied || 0 : side === "debit" ? r.credit : r.debit);
export const paymentAppliedTo = (r) => (r.allocations && r.allocations.length ? r.allocations.map((a) => ({ ref: a.ref, amount: a.amount })) : r.reference ? [{ ref: r.reference }] : []);

// Single "Entry" text used by the ledger table, CSV and PDF.
export const entryTitle = (r) => `${r.typeLabel}${r.reference ? ` · ${r.reference}` : ""}`;

export function exportLedgerCSV(name, ledger, side, newestFirst = false) {
  const col = ledgerColumns(side);
  const bf = ["", "Opening Balance (B/F)", "", "", balanceText(ledger.broughtForward)];
  const line = (r) => [fmtDateTime(r.date), `${entryTitle(r)}${r.description ? ` — ${r.description}` : ""}`, r[col.leftKey] || "", r[col.rightKey] || "", balanceText(r.balance)];
  const body = ledger.rows.map(line);
  const hasBf = Math.abs(ledger.broughtForward) > 0.005;
  const rows = newestFirst ? [...body.reverse(), ...(hasBf ? [bf] : [])] : [...(hasBf ? [bf] : []), ...body];
  rows.push(["", "Total", ledger[side === "debit" ? "totalDebit" : "totalCredit"], ledger[side === "debit" ? "totalCredit" : "totalDebit"], balanceText(ledger.closing)]);
  downloadCSV(name, ["Date", "Entry", col.left, col.right, "Running Balance"], rows);
}

const esc = (v) => String(v ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

export function printLedger({ title, partyLabel, party, shopName, ledger, side, range, note, newestFirst = false, paymentRows = [] }) {
  const col = ledgerColumns(side);
  const win = window.open("", "_blank");
  if (!win) return;
  const printRows = newestFirst ? [...ledger.rows].reverse() : ledger.rows;
  const rowsHtml = printRows.map((r) => `<tr><td class="nw">${fmtDateTime(r.date)}</td><td><b>${esc(entryTitle(r))}</b>${r.description ? `<div class="muted">${esc(r.description)}</div>` : ""}</td><td class="n">${r[col.leftKey] ? fmtMoney(r[col.leftKey]) : "—"}</td><td class="n g">${r[col.rightKey] ? fmtMoney(r[col.rightKey]) : "—"}</td><td class="n b a">${esc(balanceText(r.balance))}</td></tr>`).join("");
  const payHtml = paymentRows.length ? `<h3 style="margin:18px 0 6px;font-size:13px">Payment ledger</h3><table><thead><tr><th>Date</th><th>Payment</th><th>Applied to</th><th class="n">Amount</th></tr></thead><tbody>${paymentRows.map((r) => `<tr><td class="nw">${fmtDateTime(r.date)}</td><td><b>${esc(r.typeLabel)}</b>${r.description ? `<div class="muted">${esc(r.description)}</div>` : ""}</td><td>${paymentAppliedTo(r).map((a) => `${esc(a.ref)}${a.amount != null ? ` — ${fmtMoney(a.amount)}` : ""}`).join("<br>") || "—"}</td><td class="n g">${fmtMoney(paymentAmount(r, side))}</td></tr>`).join("")}<tr class="cl"><td colspan="3">Total ${side === "debit" ? "received" : "paid"}</td><td class="n">${fmtMoney(paymentRows.filter((r) => !r.infoOnly).reduce((a, r) => a + paymentAmount(r, side), 0))}</td></tr></tbody></table>` : "";
  const hasBf = Math.abs(ledger.broughtForward) > 0.005;
  const bfRow = hasBf ? `<tr class="bf"><td colspan="4">Opening Balance (B/F)</td><td class="n">${esc(balanceText(ledger.broughtForward))}</td></tr>` : "";
  const period = range?.from && range?.to ? `${fmtDate(range.from)} — ${fmtDate(range.to)}` : "All transactions";
  const balCaption = side === "debit" ? "Balance due" : "Balance payable";
  win.document.write(`<!DOCTYPE html><html><head><meta charset="utf-8"><title>${esc(title)} — ${esc(party.name)}</title><style>
  *{box-sizing:border-box;margin:0;padding:0}body{font-family:Arial,sans-serif;font-size:11px;color:#1e293b;padding:24px}
  .top{display:flex;justify-content:space-between;border-bottom:2px solid #1e293b;padding-bottom:10px;margin-bottom:12px}
  h1{font-size:18px}h2{font-size:13px;margin-top:2px;color:#475569}.muted{color:#64748b;font-size:10px}
  .box{background:#f8fafc;border:1px solid #e2e8f0;border-radius:6px;padding:8px 12px;margin-bottom:12px;display:flex;justify-content:space-between}
  table{width:100%;border-collapse:collapse}th{background:#1e293b;color:#fff;font-size:10px;text-transform:uppercase;padding:7px 8px;text-align:left}
  th.n,td.n{text-align:right}td{padding:6px 8px;border-bottom:1px solid #e2e8f0;vertical-align:top}td.nw{white-space:nowrap}.b{font-weight:700}.g{color:#047857;font-weight:700}.a{color:#b45309}
  tr.bf td{background:#f1f5f9;font-weight:700}tr.cl td{background:#f1f5f9;font-weight:700;border-top:2px solid #1e293b}
  .sig{display:flex;justify-content:space-between;margin-top:46px}.sig div{border-top:1px solid #94a3b8;padding-top:4px;width:160px;text-align:center;font-size:10px;color:#64748b}
  </style></head><body>
  <div class="top"><div><h1>${esc(shopName || "Tech Riwaayat POS")}</h1><h2>${esc(title)}</h2></div><div style="text-align:right"><div class="muted">Statement period</div><b>${esc(period)}</b><div class="muted" style="margin-top:3px">Generated ${new Date().toLocaleString("en-PK")}</div></div></div>
  <div class="box"><div><div class="muted">${esc(partyLabel)}</div><b style="font-size:14px">${esc(party.name)}</b><div>${esc(party.phone || "")} ${party.city ? "· " + esc(party.city) : ""}</div></div>
  <div style="text-align:right"><div class="muted">${balCaption}</div><b style="font-size:16px">${esc(balanceText(ledger.closing))}</b></div></div>
  <table><thead><tr><th>Date</th><th>Entry</th><th class="n">${col.left}</th><th class="n">${col.right}</th><th class="n">Running Balance</th></tr></thead><tbody>
  ${newestFirst ? "" : bfRow}
  ${rowsHtml}
  ${newestFirst ? bfRow : ""}
  <tr class="cl"><td colspan="2">Total</td><td class="n">${fmtMoney(side === "debit" ? ledger.totalDebit : ledger.totalCredit)}</td><td class="n">${fmtMoney(side === "debit" ? ledger.totalCredit : ledger.totalDebit)}</td><td class="n">${esc(balanceText(ledger.closing))}</td></tr>
  </tbody></table>
  ${payHtml}
  ${note ? `<p class="muted" style="margin-top:10px">${esc(note)}</p>` : ""}
  <p class="muted" style="margin-top:10px">Running balance shown after each entry.</p>
  <div class="sig"><div>Prepared by</div><div>${esc(partyLabel)} signature</div></div></body></html>`);
  win.document.close();
  win.focus();
  setTimeout(() => win.print(), 250);
}
