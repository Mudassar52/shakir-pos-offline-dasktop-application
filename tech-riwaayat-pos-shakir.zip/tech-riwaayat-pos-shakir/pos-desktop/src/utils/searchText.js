// Urdu/Arabic-safe search helpers.
//
// Problem: Urdu text alag keyboards se type karo to same dikhne wale naam
// asal mein alag Unicode characters hote hain (ي vs ی, ك vs ک, ه vs ہ/ھ,
// ؤ/ئ/أ forms, zabar-zer jaise diacritics, tatweel, hidden ZWNJ/ZWJ
// characters, NBSP, double spaces). Is wajah se `includes()` search kabhi
// match karta tha kabhi nahi. Yahan dono taraf (data aur query) ko ek
// standard shakal mein badal kar compare karte hain.

const CHAR_MAP = {
  "\u064A": "\u06CC", // ي  -> ی
  "\u0649": "\u06CC", // ى  -> ی
  "\u06D2": "\u06CC", // ے  -> ی
  "\u06D3": "\u06CC", // ۓ  -> ی
  "\u0626": "\u06CC", // ئ  -> ی
  "\u0643": "\u06A9", // ك  -> ک
  "\u06AA": "\u06A9", // ڪ  -> ک
  "\u0647": "\u06C1", // ه  -> ہ
  "\u06BE": "\u06C1", // ھ  -> ہ
  "\u06D5": "\u06C1", // ە  -> ہ
  "\u06C2": "\u06C1", // ۂ  -> ہ
  "\u06C3": "\u06C1", // ۃ  -> ہ
  "\u0629": "\u06C1", // ة  -> ہ
  "\u0623": "\u0627", // أ  -> ا
  "\u0625": "\u0627", // إ  -> ا
  "\u0622": "\u0627", // آ  -> ا
  "\u0671": "\u0627", // ٱ  -> ا
  "\u0624": "\u0648", // ؤ  -> و
  "\u06C0": "\u06C1", // ۀ  -> ہ
};
const CHAR_RE = new RegExp(`[${Object.keys(CHAR_MAP).join("")}]`, "g");
// diacritics (harakat), tatweel, ZWNJ/ZWJ/LRM/RLM/BOM jaise hidden characters
const STRIP_RE = /[\u064B-\u065F\u0670\u06D6-\u06ED\u0640\u200B-\u200F\u202A-\u202E\u2060\uFEFF]/g;
// Arabic-Indic / Persian digits -> 0-9
const DIGIT_RE = /[\u0660-\u0669\u06F0-\u06F9]/g;

export function normalizeText(value) {
  if (value === null || value === undefined) return "";
  return String(value)
    .normalize("NFKC")
    .replace(STRIP_RE, "")
    .replace(CHAR_RE, (ch) => CHAR_MAP[ch])
    .replace(DIGIT_RE, (d) => String(d.charCodeAt(0) & 0xf))
    .replace(/\s+/g, " ")
    .trim()
    .toLowerCase();
}

// Kisi bhi fields mein se query mil jaye to true. Query ke har lafz ko alag
// check karta hai (word order se farq nahi parta).
export function matchesSearch(query, ...fields) {
  const q = normalizeText(query);
  if (!q) return true;
  const hay = fields.map(normalizeText).join(" ");
  return q.split(" ").every((word) => hay.includes(word));
}

// Name compare/map-key ke liye
export const nameKey = normalizeText;
