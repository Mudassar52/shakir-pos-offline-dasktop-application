// ── Shared report calculations ──────────────────────────────────────────
// Dashboard aur Reports dono isi file se calculations lete hain, aur dono
// hi already-loaded `allInvoices` (jo App.jsx mein state mein hai) use
// karte hain — koi separate backend fetch nahi. Isse:
//   Invoice create → setSales() → allInvoices update → Dashboard update
//                                                     → Reports update
// dono jagah HAMESHA same number turant show hote hain, koi network
// race-condition ya server/browser timezone mismatch nahi ho sakta.

// Graphs ke liye Urdu labels (mahine aur hafte ke din) — Dashboard aur
// Reports dono yahin se lete hain taake har graph par ek jaisa Urdu dikhe.
export const URDU_MONTHS = ["جنوری", "فروری", "مارچ", "اپریل", "مئی", "جون", "جولائی", "اگست", "ستمبر", "اکتوبر", "نومبر", "دسمبر"];
export const URDU_WEEKDAYS = ["اتوار", "پیر", "منگل", "بدھ", "جمعرات", "جمعہ", "ہفتہ"];

// Kisi bhi date/ISO string ki LOCAL din (YYYY-MM-DD). Pehle UTC date li jati thi,
// is liye Pakistan mein raat 12 se subah 5 baje ki sale pichle din mein chali jati thi.
export function localDay(v) {
  const s = String(v || "");
  if (/^\d{4}-\d{2}-\d{2}$/.test(s)) return s;
  const t = new Date(s);
  if (isNaN(t)) return s.slice(0, 10);
  return `${t.getFullYear()}-${String(t.getMonth() + 1).padStart(2, "0")}-${String(t.getDate()).padStart(2, "0")}`;
}

export const REPORT_PERIODS = [
  { key: "day", label: "آج" },
  { key: "week", label: "اس ہفتے" },
  { key: "month", label: "اس مہینے" },
  { key: "year", label: "اس سال" },
];

// Invoice/payment ki date diye gaye period ke andar aati hai ya nahi.
// Browser ka local time use hota hai — jo business owner ke device par
// hamesha unki apni (Pakistan) local time hoti hai, is liye server
// timezone ka koi masla nahi aata.
export function isInPeriod(dateStr, period, now, customRange) {
  if (!dateStr) return false;
  const d = new Date(dateStr);
  if (period === "custom") {
    if (!customRange?.from || !customRange?.to) return false;
    const iso = localDay(dateStr);
    return iso >= customRange.from && iso <= customRange.to;
  }
  if (period === "day") {
    return d.toDateString() === now.toDateString();
  }
  if (period === "week") {
    const start = new Date(now);
    start.setDate(now.getDate() - now.getDay());
    start.setHours(0, 0, 0, 0);
    return d >= start && d <= now;
  }
  if (period === "month") {
    return d.getFullYear() === now.getFullYear() && d.getMonth() === now.getMonth();
  }
  // year
  return d.getFullYear() === now.getFullYear();
}

// Invoice par ab tak kitne paise wasool huay hain (advance + baqi payments).
export function getPaidAmount(inv) {
  const advInPmts = (inv.payments || []).filter(p => p.note && p.note.includes("Advance at sale")).reduce((s, p) => s + (p.amount || 0), 0);
  const otherPmts = (inv.payments || []).filter(p => !p.note || !p.note.includes("Advance at sale")).reduce((s, p) => s + (p.amount || 0), 0);
  const standAloneAdv = advInPmts > 0 ? 0 : (inv.advance || 0);
  return advInPmts + otherPmts + standAloneAdv;
}

// Invoice ka wasool hone wala hissa (0..1). Cash/paid invoice = 1.
export function paidRatioOf(inv) {
  if (inv.paymentStatus === "udaar" || inv.paymentStatus === "partial") {
    const total = inv.total || 0;
    if (total <= 0) return 0;
    return Math.max(0, Math.min(1, getPaidAmount(inv) / total));
  }
  return 1;
}

// Invoice ka POORA (billed) munafa, wasooli se pehle:
//   munafa = (total − tax) − items ki cost
// Tax dukaan ka munafa nahi hota (government ka hai), aur cost discount ke
// saath kam nahi hoti — isliye dono sahi tareeqe se handle hotay hain.
// Nuqsan wali invoice ka profit minus (negative) hi dikhta hai.
export function calcFullProfit(inv, productById, productByName) {
  if (inv.isOldUdaar) return 0;
  const tax = inv.tax || 0;
  const items = inv.items || [];

  // Cost hamesha items se (item ki apni cost → warna product catalog se). Pehle kuch items ki
  // cost na milti thi to poori invoice ka PURANA saved grossProfit use hota tha, jis se
  // "Profit by Invoice" aur "Profit by Product" ke total Rs 4,506 se alag aa rahe the.
  // Ab dono jagah ek hi formula hai: total − tax − cost.
  const cost = items.reduce((s, item) => {
    let cp = item.costPrice;
    if (cp === undefined || cp === null || cp === 0) {
      const prod = (item.productId && productById?.get(String(item.productId))) || productByName?.get(item.name);
      if (prod) cp = prod.costPrice || prod.stockPrice || 0;
    }
    return s + ((cp || 0) * (item.qty || 0));
  }, 0);

  // Sirf tab saved grossProfit jab invoice mein koi item hi na ho.
  if (items.length === 0 && inv.grossProfit !== undefined && inv.grossProfit !== null && inv.grossProfit !== 0) return inv.grossProfit - tax;
  return (inv.total || 0) - tax - cost;
}

// Invoice ka profit — udaar/partial invoices ka jitna hissa abhi tak
// wasool nahi hua, us hisse ka profit count nahi hota.
export function calcProfit(inv, productById, productByName) {
  if (inv.isOldUdaar) return 0;
  return calcFullProfit(inv, productById, productByName) * paidRatioOf(inv);
}

// ── Supplier se maal khareedna (Purchases) ───────────────────────────────
// supplierTransactions (jo App state mein pehle se loaded hain) se: type "purchase" = maal
// khareeda, type "return" = supplier ko wapis kiya. "opening" (purana baaqi) khareedari nahi
// hai, is liye shamil nahi. Dashboard aur Reports dono isi function se lete hain.
export function computePurchaseStats(supplierTransactions = [], period = "month", now = new Date(), customRange = null) {
  let purchased = 0, returned = 0, count = 0;
  supplierTransactions.forEach((t) => {
    if (t.type !== "purchase" && t.type !== "return") return;
    if (!(period === "all" || isInPeriod(t.date, period, now, customRange))) return;
    if (t.type === "purchase") { purchased += Number(t.amount) || 0; count += 1; }
    else returned += Number(t.amount) || 0;
  });
  return { purchased, returned, net: purchased - returned, count };
}

function localDateKey(d) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function emptyBucket(label) {
  return { label, revenue: 0, sales: 0, profit: 0, udaar: 0, udaarReceive: 0 };
}

function daysBetween(fromISO, toISO) {
  const start = new Date(fromISO + "T00:00:00");
  const end = new Date(toISO + "T00:00:00");
  const days = [];
  for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
    days.push(new Date(d));
  }
  return days;
}

// Period ke andar aane wali invoices ko chart ke liye hour/day/date/month
// buckets mein group karta hai (Report page ke graphs ke liye).
function groupByPeriod(periodInvoices, period, now, productById, productByName, paymentEvents, customRange) {
  let buckets, bucketIndex;

  if (period === "custom" && customRange?.from && customRange?.to) {
    const days = daysBetween(customRange.from, customRange.to).slice(0, 92); // sanity cap ~3 months
    buckets = days.map((d) => emptyBucket(`${String(d.getDate()).padStart(2, "0")} ${URDU_MONTHS[d.getMonth()]}`));
    const dayKeys = days.map(localDateKey);
    bucketIndex = (d) => dayKeys.indexOf(localDateKey(d));
  } else if (period === "day") {
    buckets = Array.from({ length: now.getHours() + 1 }, (_, h) => emptyBucket(`${h}:00`));
    bucketIndex = (d) => d.getHours();
  } else if (period === "week") {
    buckets = URDU_WEEKDAYS.map((d) => emptyBucket(d));
    bucketIndex = (d) => d.getDay();
  } else if (period === "month") {
    const daysInMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();
    buckets = Array.from({ length: daysInMonth }, (_, i) => emptyBucket(`${i + 1}`));
    bucketIndex = (d) => d.getDate() - 1;
  } else {
    buckets = URDU_MONTHS.map((m) => emptyBucket(m));
    bucketIndex = (d) => d.getMonth();
  }

  periodInvoices.forEach((inv) => {
    const idx = bucketIndex(new Date(inv.createdAt));
    const b = buckets[idx];
    if (!b) return;
    // Purana udhaar sale nahi hai — revenue/sales count mein nahi, sirf udaar mein.
    if (!inv.isOldUdaar) {
      b.revenue += inv.total || 0;
      b.sales += 1;
      b.profit += calcProfit(inv, productById, productByName);
    }
    if (inv.paymentStatus === "udaar" || inv.paymentStatus === "partial") {
      const paid = getPaidAmount(inv);
      b.udaar += Math.max(0, (inv.total || 0) - paid);
    }
  });

  paymentEvents.forEach((ev) => {
    const idx = bucketIndex(new Date(ev.date));
    const b = buckets[idx];
    if (b) b.udaarReceive += ev.amount;
  });

  return buckets;
}

// Poora Report page ka data ek hi jagah se — allInvoices (jo already app
// state mein load ho chuki hain) aur products se, koi backend call nahi.
export function computeReportStats({ allInvoices = [], products = [], period = "month", customRange = null, expenses = [], losses = [], supplierTransactions = [] }) {
  const now = new Date();

  const productById = new Map(products.map((p) => [String(p.id), p]));
  const productByName = new Map(products.map((p) => [p.name, p]));

  const periodInvoices = allInvoices.filter((inv) => isInPeriod(inv.createdAt, period, now, customRange));

  // Purana udhaar entries sale nahi hain (48 reports ki tarah) — revenue aur sales
  // count mein shamil nahi, sirf udaar (due) mein aati hain.
  const realInvoices = periodInvoices.filter((i) => !i.isOldUdaar);
  const totalRevenue = realInvoices.reduce((s, inv) => s + (inv.total || 0), 0);
  const totalSales = realInvoices.length;
  const posSales = realInvoices.filter((i) => i.source !== "manual").length;
  const manualSales = realInvoices.filter((i) => i.source === "manual").length;
  const estimatedProfit = periodInvoices.reduce((s, inv) => s + calcProfit(inv, productById, productByName), 0);

  // Expenses aur losses is period ke — Net Profit = Estimated Profit − Expenses − Losses.
  const totalExpenses = expenses
    .filter((e) => isInPeriod(e.date, period, now, customRange))
    .reduce((s, e) => s + e.amount, 0);
  const totalLosses = losses
    .filter((l) => isInPeriod(l.date, period, now, customRange))
    .reduce((s, l) => s + l.value, 0);
  const netProfit = estimatedProfit - totalExpenses - totalLosses;

  // Top products
  const topProductsMap = {};
  realInvoices.forEach((inv) => {
    (inv.items || []).forEach((item) => {
      const key = item.name || "Unknown";
      if (!topProductsMap[key]) topProductsMap[key] = { name: key, qty: 0, revenue: 0 };
      topProductsMap[key].qty += item.qty || 0;
      topProductsMap[key].revenue += item.lineTotal || 0;
    });
  });
  const topProducts = Object.values(topProductsMap).sort((a, b) => b.revenue - a.revenue).slice(0, 5);

  // Category breakdown
  const categoryMap = {};
  realInvoices.forEach((inv) => {
    (inv.items || []).forEach((item) => {
      const prod = (item.productId && productById.get(String(item.productId))) || productByName.get(item.name);
      const cat = prod?.category || "دیگر";
      if (!categoryMap[cat]) categoryMap[cat] = { name: cat, value: 0 };
      categoryMap[cat].value += item.lineTotal || 0;
    });
  });
  const categoryData = Object.values(categoryMap).sort((a, b) => b.value - a.value);

  // Udaar Receive — SAARI invoices (chahe kisi bhi purani date ki hon) ke
  // payments scan karte hain aur jis payment ki apni date is period ke
  // andar aati hai, sirf wahi count hoti hai. Isse purani udhaar invoice
  // ki aaj wasool hui payment bhi "Today" mein sahi show hoti hai.
  const paymentEvents = [];
  allInvoices.forEach((inv) => {
    (inv.payments || []).forEach((p) => {
      if (p.note && p.note.includes("Advance at sale")) return;
      if (p.note === "Advance Balance Used") return; // pehle se diya hua advance — nayi wasooli nahi
      if (!p.date) return;
      if (isInPeriod(p.date, period, now, customRange)) {
        paymentEvents.push({ date: p.date, amount: p.amount || 0 });
      }
    });
  });
  const totalUdaarReceived = paymentEvents.reduce((s, ev) => s + ev.amount, 0);

  // Udaar (abhi bhi due) — is period mein bani invoices ka, jo abhi tak
  // wasool nahi hua (current due, payment date se independent).
  const totalUdaarDue = periodInvoices
    .filter((inv) => inv.paymentStatus === "udaar" || inv.paymentStatus === "partial")
    .reduce((s, inv) => s + Math.max(0, (inv.total || 0) - getPaidAmount(inv)), 0);

  const chartData = groupByPeriod(periodInvoices, period, now, productById, productByName, paymentEvents, customRange);
  const purchaseStats = computePurchaseStats(supplierTransactions, period, now, customRange);

  return {
    purchaseStats,
    totalRevenue,
    estimatedProfit,
    totalExpenses,
    totalLosses,
    netProfit,
    totalSales,
    posSales,
    manualSales,
    totalUdaarReceived,
    totalUdaarDue,
    topProducts,
    categoryData,
    chartData,
  };
}
