import { useMemo, useState } from "react";
import Pagination, { paginate } from "../common/Pagination";
import { Skeleton } from "./Skeleton";
import EmptyState from "./EmptyState";
import { computeLedger, balanceText, entryTitle, ledgerColumns, fmtMoney, fmtDateTime, printLedger, isPaymentRow, advanceSummary, paymentAmount, paymentAppliedTo, buildAdvanceRows, advanceIn, advanceOut, splitSupplierAdvance } from "../../utils/ledger";

const PAGE = 25;
const PAY_PAGE = 15;

// Shared table look (light grey header, centred columns, soft row dividers)
const TH = "px-4 py-3 text-center text-[11px] font-bold uppercase tracking-[0.07em] text-slate-500 bg-slate-100 whitespace-nowrap";
const TD = "px-4 py-3.5 text-center text-[13.5px] border-t border-slate-200 align-middle";

/**
 * Ledger statement — one chronological table, newest first:
 *   Customer (side="debit")  → Date | Entry | Billed    | Received | Running balance
 *   Supplier (side="credit") → Date | Entry | Purchased | Paid     | Running balance
 * Totals row at the bottom, PDF statement in the header, and a Payment ledger underneath.
 */
export default function LedgerView({ entries: rawEntries = [], side = "debit", party, partyLabel = "Customer", title = "Account Statement", shopName, loading = false, allowHideCash = false }) {
  const [page, setPage] = useState(1);
  const [payPage, setPayPage] = useState(1);
  const [advPage, setAdvPage] = useState(1);
  // Cash sales paid on the spot (customer ledger) never touch the balance, so they are left out.
  const hideCash = allowHideCash;
  // Supplier ka advance bhi customer ki tarah alag entry banta hai (Running balance mein minus nahi)
  const entries = useMemo(() => (side === "credit" ? splitSupplierAdvance(rawEntries) : rawEntries), [rawEntries, side]);

  const ledger = useMemo(() => computeLedger(entries, { side, hideCash }), [entries, side, hideCash]);

  // Info-only lines (advance applied to a bill) don't change the balance — they show in the Payment ledger only.
  const mainRows = useMemo(() => ledger.rows.filter((r) => !r.infoOnly), [ledger.rows]);
  const ordered = useMemo(() => [...mainRows].reverse(), [mainRows]);
  const { pageItems, currentPage } = paginate(ordered, page, PAGE);

  // Payment ledger hamesha SAARI payments dikhata hai (cash-on-the-spot bhi) — "hide cash" sirf upar wali statement par lagta hai.
  const fullLedger = useMemo(() => computeLedger(entries, { side }), [entries, side]);
  const payRows = useMemo(() => fullLedger.rows.filter((r) => isPaymentRow(r, side)).reverse(), [fullLedger.rows, side]);
  const payTotal = useMemo(() => payRows.reduce((a, r) => a + paymentAmount(r, side), 0), [payRows, side]);
  const { pageItems: payItems, currentPage: payCurrent } = paginate(payRows, payPage, PAY_PAGE);

  // Advance ledger (sirf customer) — Running balance se bilkul alag
  const advRowsAsc = useMemo(() => (side === "debit" ? buildAdvanceRows(fullLedger.rows) : buildAdvanceRows(fullLedger.rows)), [fullLedger.rows, side]);
  const advRows = useMemo(() => [...advRowsAsc].reverse(), [advRowsAsc]);
  const { pageItems: advItems, currentPage: advCurrent } = paginate(advRows, advPage, PAY_PAGE);

  const col = ledgerColumns(side);
  const totals = side === "debit" ? { left: ledger.totalDebit, right: ledger.totalCredit } : { left: ledger.totalCredit, right: ledger.totalDebit };
  const isCustomer = side === "debit";
  const heading = isCustomer ? "Sales & payment ledger" : "Purchase & payment ledger";
  const subheading = isCustomer
    ? `Every sale and payment for ${party.name}, in one chronological statement — download it as a PDF anytime.`
    : `Every purchase and payment to ${party.name}, in one chronological statement — download it as a PDF anytime.`;
  const balTone = (b) => (b < -0.005 ? "text-teal-700" : b > 0.005 ? "text-amber-700" : "text-emerald-700");
  const hasRows = entries.length > 0;
  const advLeft = isCustomer ? advanceSummary(entries) : (advRowsAsc.length ? Math.max(0, advRowsAsc[advRowsAsc.length - 1].advBalance) : 0);

  const doPrint = () => printLedger({
    title, partyLabel, party, shopName, ledger: { ...ledger, rows: mainRows }, side, range: null, newestFirst: true, paymentRows: payRows, advanceRows: advRowsAsc,
    note: hideCash ? "Cash sales paid on the spot are not listed (they do not affect the balance)." : "",
  });

  return (
    <div className="space-y-4">
      {/* ── Ledger ── */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 p-5">
          <div>
            <h3 className="font-bold text-slate-800">{heading}</h3>
            <p className="text-xs text-slate-500">{subheading}</p>
          </div>
          {hasRows && (
            <button onClick={doPrint} className="px-3.5 py-2.5 rounded-lg bg-violet-600 hover:bg-violet-700 text-white text-[13px] font-bold">Download PDF</button>
          )}
        </div>

        {!loading && !hasRows ? (
          <EmptyState title="No ledger activity yet" hint={isCustomer ? "Sales and payments for this customer will appear together here." : "Purchases and payments for this supplier will appear together here."} />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[680px] border-collapse">
              <thead>
                <tr>
                  <th className={TH}>Date</th>
                  <th className={TH}>Entry</th>
                  <th className={TH}>{col.left}</th>
                  <th className={TH}>{col.right}</th>
                  <th className={TH}>Running balance</th>
                </tr>
              </thead>
              <tbody>
                {loading ? Array.from({ length: 6 }).map((_, i) => <tr key={i}><td colSpan={5} className={TD}><Skeleton className="h-4 w-full" /></td></tr>) : pageItems.map((r) => (
                  <tr key={r.id} className="hover:bg-slate-50">
                    <td className={`${TD} whitespace-nowrap`}>{fmtDateTime(r.date)}</td>
                    <td className={TD}>
                      <span className="text-slate-800">{entryTitle(r)}</span>
                      {r.description && <span className="text-slate-400"> — {r.description}</span>}
                    </td>
                    <td className={`${TD} font-bold text-slate-700`}>{r[col.leftKey] ? fmtMoney(r[col.leftKey]) : "—"}</td>
                    <td className={`${TD} font-bold text-emerald-700`}>{r[col.rightKey] ? fmtMoney(r[col.rightKey]) : "—"}</td>
                    <td className={`${TD} font-bold whitespace-nowrap ${balTone(r.balance)}`}>{balanceText(r.balance)}</td>
                  </tr>
                ))}
              </tbody>
              {!loading && (
                <tfoot>
                  <tr className="border-t-2 border-slate-200 bg-slate-50 font-bold">
                    <td colSpan={2} className={`${TD} border-t-0`}>Total</td>
                    <td className={`${TD} border-t-0 text-slate-800`}>{fmtMoney(totals.left)}</td>
                    <td className={`${TD} border-t-0 text-emerald-700`}>{fmtMoney(totals.right)}</td>
                    <td className={`${TD} border-t-0 ${balTone(ledger.closing)}`}>{balanceText(ledger.closing)}</td>
                  </tr>
                </tfoot>
              )}
            </table>
          </div>
        )}
        {!loading && advLeft > 0.005 && (
          <div className="mx-5 mb-3 mt-3 rounded-xl bg-amber-50 border border-amber-200 px-4 py-2.5 text-[12.5px] text-amber-800">
            Advance Balance <b>{fmtMoney(advLeft)}</b> alag se rakha gaya hai (neeche Advance ledger mein) — ye Running balance / Outstanding mein minus nahi hota.
          </div>
        )}
        <div className="px-5 pb-3"><Pagination total={ordered.length} page={currentPage} pageSize={PAGE} onPageChange={setPage} /></div>
      </div>

      {/* ── Payment ledger ── */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="border-b border-slate-200 p-5">
          <h3 className="font-bold text-slate-800">Payment ledger</h3>
          <p className="text-xs text-slate-500">{isCustomer ? `Every payment received from ${party.name}, with the invoices it was applied to.` : `Every payment made to ${party.name}, with the invoice it was applied to.`}</p>
        </div>
        {!loading && payRows.length === 0 ? (
          <EmptyState title="No payments yet" hint="Payments will appear here as soon as they are recorded." />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[680px] border-collapse">
              <thead>
                <tr>
                  <th className={TH}>Date</th>
                  <th className={TH}>Payment</th>
                  <th className={TH}>Applied to</th>
                  <th className={TH}>Amount</th>
                </tr>
              </thead>
              <tbody>
                {loading ? Array.from({ length: 3 }).map((_, i) => <tr key={i}><td colSpan={4} className={TD}><Skeleton className="h-4 w-full" /></td></tr>) : payItems.map((r) => {
                  const applied = paymentAppliedTo(r);
                  return (
                    <tr key={r.id} className="hover:bg-slate-50">
                      <td className={`${TD} whitespace-nowrap`}>{fmtDateTime(r.date)}</td>
                      <td className={TD}>
                        <span className="text-slate-800">{r.typeLabel}</span>
                        {r.description && <span className="text-slate-400"> — {r.description}</span>}
                      </td>
                      <td className={TD}>
                        {applied.length === 0 ? <span className="text-slate-400">General</span> : applied.map((a, i) => (
                          <div key={i}>
                            <span className="font-semibold text-slate-700">{a.ref}</span>
                            {a.amount != null && <span className="text-slate-500"> · {fmtMoney(a.amount)}</span>}
                          </div>
                        ))}
                      </td>
                      <td className={`${TD} font-bold whitespace-nowrap ${r.fromAdvance ? "text-slate-500" : "text-emerald-700"}`}>
                        {fmtMoney(paymentAmount(r, side))}
                        {r.fromAdvance && <div className="text-[10px] font-semibold text-slate-400">from advance</div>}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
              {!loading && (
                <tfoot>
                  <tr className="border-t-2 border-slate-200 bg-slate-50 font-bold">
                    <td colSpan={3} className={`${TD} border-t-0`}>Total {isCustomer ? "received" : "paid"}</td>
                    <td className={`${TD} border-t-0 text-emerald-700`}>{fmtMoney(payTotal)}</td>
                  </tr>
                </tfoot>
              )}
            </table>
          </div>
        )}
        <div className="px-5 pb-3"><Pagination total={payRows.length} page={payCurrent} pageSize={PAY_PAGE} onPageChange={setPayPage} /></div>
      </div>
      {/* ── Advance ledger (sirf customer) — Running balance mein shamil nahi ── */}
      {!loading && advRows.length > 0 && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="border-b border-slate-200 p-5">
            <h3 className="font-bold text-slate-800">Advance ledger</h3>
            <p className="text-xs text-slate-500">Advance jama, wapis, aur bill mein istemal — ye Running balance / Outstanding se alag hai.</p>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full min-w-[680px] border-collapse">
              <thead>
                <tr>
                  <th className={TH}>Date</th>
                  <th className={TH}>Entry</th>
                  <th className={TH}>Advance In</th>
                  <th className={TH}>Advance Out</th>
                  <th className={TH}>Advance balance</th>
                </tr>
              </thead>
              <tbody>
                {advItems.map((r) => (
                  <tr key={r.id} className="hover:bg-slate-50">
                    <td className={`${TD} whitespace-nowrap`}>{fmtDateTime(r.date)}</td>
                    <td className={TD}>
                      <span className="text-slate-800">{entryTitle(r)}</span>
                      {r.description && <span className="text-slate-400"> — {r.description}</span>}
                    </td>
                    <td className={`${TD} font-bold text-emerald-700`}>{advanceIn(r) ? fmtMoney(advanceIn(r)) : "—"}</td>
                    <td className={`${TD} font-bold text-slate-700`}>{advanceOut(r) ? fmtMoney(advanceOut(r)) : "—"}</td>
                    <td className={`${TD} font-bold whitespace-nowrap text-amber-700`}>{fmtMoney(r.advBalance)}</td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr className="border-t-2 border-slate-200 bg-slate-50 font-bold">
                  <td colSpan={4} className={`${TD} border-t-0`}>Advance balance abhi baqi</td>
                  <td className={`${TD} border-t-0 text-amber-700`}>{fmtMoney(advRowsAsc[advRowsAsc.length - 1].advBalance)}</td>
                </tr>
              </tfoot>
            </table>
          </div>
          <div className="px-5 pb-3"><Pagination total={advRows.length} page={advCurrent} pageSize={PAY_PAGE} onPageChange={setAdvPage} /></div>
        </div>
      )}
    </div>
  );
}
