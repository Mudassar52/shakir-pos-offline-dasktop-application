import { useState } from "react";
import ProductIcon from "../common/ProductIcon";
import { perCtnOf, formatCtn } from "../../utils/cartonHelpers";

export default function StockModal({ open, onClose, product, type, onConfirm }) {
  const [qty, setQty] = useState("");
  const [error, setError] = useState("");
  const [unit, setUnit] = useState("pcs"); // "pcs" | "ctn"

  if (!open || !product) return null;

  const isIn = type === "in";
  const title = isIn ? "Stock In" : "Stock Out";

  const handleSubmit = (e) => {
    e.preventDefault();
    const per = perCtnOf(product);
    const amount = unit === "ctn" && per > 0 ? Number(qty) * per : Number(qty);
    if (!amount || amount <= 0) {
      setError("Enter a valid quantity.");
      return;
    }
    if (!isIn && product.currentStock < amount) {
      setError(`Only ${product.currentStock} units available.`);
      return;
    }
    const ok = onConfirm(product.id, amount);
    if (ok) {
      setQty("");
      setError("");
      setUnit("pcs");
      onClose();
    }
  };

  const handleClose = () => {
    setUnit("pcs");
    setQty("");
    setError("");
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40">
      <div className="bg-white rounded-2xl w-full max-w-md shadow-xl">
        <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
          <h2 className="font-bold text-slate-800">{title}</h2>
          <button onClick={handleClose} className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-400">✕</button>
        </div>
        <form onSubmit={handleSubmit} className="p-5 space-y-4">
          <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl">
            <ProductIcon size={20} />
            <div>
              <p className="text-sm font-semibold text-slate-800">{product.name}</p>
              <p className="text-xs text-slate-400">
                Current stock: {product.currentStock} units
                {perCtnOf(product) > 0 && <span className="text-purple-500 font-semibold"> ({formatCtn(product.currentStock, perCtnOf(product))})</span>}
              </p>
            </div>
          </div>

          {error && <p className="text-sm text-red-600 bg-red-50 px-3 py-2 rounded-lg">{error}</p>}

          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs font-medium text-slate-500 block">{unit === "ctn" ? "Cartons" : "Quantity (pieces)"}</label>
              {perCtnOf(product) > 0 && (
                <div className="flex items-center gap-1 bg-slate-100 rounded-lg p-0.5">
                  {[["pcs", "Piece"], ["ctn", "Carton"]].map(([k, label]) => (
                    <button key={k} type="button" onClick={() => { setUnit(k); setError(""); }}
                      className={`px-2.5 py-0.5 rounded-md text-[11px] font-bold ${unit === k ? (k === "ctn" ? "bg-purple-600 text-white" : "bg-blue-600 text-white") : "text-slate-500"}`}>{label}</button>
                  ))}
                </div>
              )}
            </div>
            <input
              type="number"
              min="1"
              value={qty}
              onChange={(e) => setQty(e.target.value)}
              className="w-full border border-slate-200 rounded-xl px-3 py-2.5 text-sm outline-none focus:border-blue-400"
              placeholder={unit === "ctn" ? "Kitne carton" : "Enter quantity"}
              autoFocus
            />
            {unit === "ctn" && perCtnOf(product) > 0 && Number(qty) > 0 && (
              <p className="text-[11px] text-purple-600 mt-1">= {Number(qty) * perCtnOf(product)} pieces (1 carton = {perCtnOf(product)} pcs)</p>
            )}
          </div>

          <div className="flex gap-3">
            <button type="button" onClick={handleClose} className="flex-1 py-2.5 rounded-xl border border-slate-200 text-sm font-medium text-slate-600 hover:bg-slate-50">
              Cancel
            </button>
            <button
              type="submit"
              className={`flex-1 py-2.5 rounded-xl text-white text-sm font-medium shadow-md ${
                isIn ? "bg-emerald-600 hover:bg-emerald-700 shadow-emerald-200" : "bg-amber-600 hover:bg-amber-700 shadow-amber-200"
              }`}
            >
              Confirm {title}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
