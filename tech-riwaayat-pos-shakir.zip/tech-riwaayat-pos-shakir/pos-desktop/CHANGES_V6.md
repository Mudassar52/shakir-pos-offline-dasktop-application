# v6 — Reports / Dashboard fixes

1. **Profit ek jaisa**: `calcFullProfit` ab hamesha items ki cost se (total − tax − cost) nikalta hai. Pehle 15 invoices
   (jin ke kuch items ki cost nahi thi) purana saved grossProfit use karti thin, is liye Profit by Invoice (9,46,131) aur
   Profit by Product (9,41,625) mein Rs 4,506 ka farq tha. Ab Dashboard, Reports aur 48 reports sab mein 9,41,625.07.
2. **Monthly Cash Flow**: cash-sale invoices ki payments[] dobara "Collections" mein ginti thin (double count) — band.
   Purani udaar/partial invoices ka sale ke waqt ka advance (sirf `advance` field mein) gina hi nahi jata tha — ab shamil.
3. **Invoices page**: "Total Invoices" ke neeche "sales + purana udhaar" ka breakup; Total Revenue / Today / Custom ab
   purana udhaar ke baghair (Dashboard/Reports ki tarah).
4. **Naya card (sab se pehle)**: "سپلائر سے مال خریدا" — Dashboard aur Reports dono par, period ke hisaab se
   (purchase − purchase return, opening balance shamil nahi).
5. **Invoices page**: har invoice se "Type" (POS Sale / Custom) ka label hata diya (table aur mobile card dono se).
   Us ki jagah naya **Profit** column: us invoice mein bika hua maal (total − tax − cost), hara = munafa, laal = nuqsan,
   purana udhaar entries par "—". Wahi formula jo Dashboard/Reports mein hai.

# v7 — Supplier Opening Balance invoice, payment bug, Urdu search
1. Opening Balance ab alag invoice hai (Purchases tab mein), us par Payment lag sakti hai (specific ya overall FIFO).
2. Stats: "Total Purchased" sirf maal ki khareedari; "Opening Balance (Baaki)" card pay karte hi kam hota hai.
3. Bug fix: purchase return wali invoice pay karne ke baad bhi "Baaki" dikhti thi (payment `returned` minus nahi karti thi). Purani galat values start par khud theek hoti hain.
4. Purchase list mein product ka naam nahi, sirf #invoice, date aur product count.
5. Urdu-safe search (ي/ی, ك/ک, ه/ہ, zabar-zer, hidden characters) — customers, suppliers, products, invoices, global search.

# v8 — Customer Outstanding vs Ledger Running Balance (ek hisaab)
1. Ledger ab Profile ke Outstanding wale formula par chalta hai: `advance` field + payments[] dono ho to advance ledger mein chhoot jata tha (5 invoices, Rs 7,000 tak ka farq).
2. Bill se zyada (double-entry) payment ledger mein ab balance nahi badlati; "Extra Payment" ka note dikhta hai.
3. (Wapis) Phone match ka rule pehle jaisa — "08" wali purani invoices apne customer ki hi rehti hain.
4. Customer Profile ab `invoiceBalance()` use karta hai (Checkout/Print ke saath ek jaisa).
5. Payment lene par float rounding se bill "partial" reh jata tha — theek.
Ab: Ledger Closing = Outstanding − Advance Balance (har customer par).
