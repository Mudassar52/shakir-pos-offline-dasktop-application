// HTML escaping — print/PDF templates mein user ka likha hua text (naam, address,
// notes) seedha HTML mein jata hai; isko escape kiye bina script chal sakti hai.
export function esc(v) {
  return String(v ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

// Object/array ke saare string fields escape karta hai (numbers/booleans jaise hain).
export function escDeep(v) {
  if (typeof v === "string") return esc(v);
  if (Array.isArray(v)) return v.map(escDeep);
  if (v && typeof v === "object") {
    const out = {};
    for (const k of Object.keys(v)) out[k] = escDeep(v[k]);
    return out;
  }
  return v;
}

// Logo sirf data:image/... ya https hi ho sakta hai.
export function safeImgSrc(src) {
  const s = String(src || "");
  return /^data:image\/(png|jpe?g|gif|webp|svg\+xml);base64,[A-Za-z0-9+/=]+$/.test(s) ? s : "";
}

// Thermal print window: CSP (script-src 'self') popup ke andar inline <script> chalne nahi deti,
// isliye print yahan (parent window se) trigger hota hai — popup ke andar script ki zaroorat nahi.
export function printWhenReady(win) {
  let done = false;
  const go = () => {
    if (done || win.closed) return;
    done = true;
    try {
      win.focus();
      win.onafterprint = () => { try { win.close(); } catch { /* ignore */ } };
      win.print();
    } catch { /* ignore */ }
  };
  const fontsReady = win.document.fonts && win.document.fonts.ready;
  if (fontsReady) fontsReady.then(() => setTimeout(go, 300), () => setTimeout(go, 300));
  setTimeout(go, 3000); // fonts (offline) atak jaye to bhi print ho
}
