import { app, BrowserWindow, ipcMain, dialog } from "electron";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

import { initDb, save, scheduleSave, flushSave, disableSaves } from "./db.js";
import * as license from "./license.js";
import * as cloud from "./cloudBackup.js";
import handleApiRequest from "./apiRouter.js";
import * as auth from "./routes/auth.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
// Only treat this as "dev" (load the Vite dev server) when explicitly asked
// via NODE_ENV=development (see the "dev" npm script). Running the built
// app — packaged or via `npx electron .` after `npm run build` — always
// loads the compiled dist/index.html.
const isDev = !app.isPackaged && process.env.NODE_ENV === "development";

function createWindow() {
  const win = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 1024,
    minHeight: 640,
    autoHideMenuBar: true,
    icon: path.join(__dirname, "..", "build", "icon.png"),
    webPreferences: {
      preload: path.join(__dirname, "preload.cjs"),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });

  if (isDev) {
    win.loadURL("http://localhost:5173");
    win.webContents.openDevTools({ mode: "detach" });
  } else {
    win.loadFile(path.join(__dirname, "..", "dist", "index.html"));
  }

  // If the preload script ever fails to load (wrong path, syntax error,
  // etc.), window.electronAPI would be missing in the renderer and every
  // login/data call would throw "Cannot read properties of undefined".
  // Logging it here makes that failure visible instead of silent.
  win.webContents.on("preload-error", (_event, preloadPath, error) => {
    console.error("Preload script failed to load:", preloadPath, error);
  });
}

// The app was renamed from "Shakir POS". Keep using the old data folder so
// existing databases / license files are found after the rename.
app.setPath("userData", path.join(app.getPath("appData"), "Shakir POS"));

app.whenReady().then(async () => {
  // sql.js is pure WebAssembly (no native compilation needed on any OS),
  // which is why it replaced better-sqlite3 — but it must finish loading
  // and reading pos-data.db from disk before anything else touches it.
  await initDb(app.getPath("userData"));

  // ── License (Supabase) ─────────────────────────────────────────────────
  // Dev mode mein (npm run dev) license bypass karne ke liye: POS_SKIP_LICENSE=1
  license.initLicense({
    userDataPath: app.getPath("userData"),
    version: app.getVersion(),
    skip: !app.isPackaged && process.env.POS_SKIP_LICENSE === "1",
    hasUser: (username) => auth.userExists(username),
    applyCredentials: (creds) => {
      auth.applyLicenseCredentials(creds);
      save();
    },
    onChange: (state) => {
      for (const w of BrowserWindow.getAllWindows()) w.webContents.send("license-changed", state);
    },
  });
  save();

  // ── Cloud backup ───────────────────────────────────────────────────────
  const userData = app.getPath("userData");
  const dbFile = path.join(userData, "pos-data.db");
  cloud.initCloudBackup({
    userDataPath: userData,
    dbPath: dbFile,
    version: app.getVersion(),
    flush: () => flushSave(),
    onChange: (status) => {
      for (const w of BrowserWindow.getAllWindows()) w.webContents.send("cloud-backup-changed", status);
    },
    // Replace the database with restored data, then restart the app.
    applyRestore: (bytes) => {
      flushSave(); // save the current data first...
      const stamp = new Date().toISOString().replace(/[:.]/g, "-");
      try { fs.copyFileSync(dbFile, path.join(userData, `pos-data.before-restore-${stamp}.db`)); } catch { /* safety copy is best-effort */ }
      disableSaves(); // ...then make sure nothing can overwrite the restored file
      const tmp = dbFile + ".restore.tmp";
      fs.writeFileSync(tmp, bytes);
      fs.renameSync(tmp, dbFile);
      app.relaunch();
      app.exit(0);
    },
  });

  const LOCKED = { ok: false, status: 403, code: "license/locked", error: "License is not active." };

  // ── Generic data API (mirrors the old REST routes 1:1) ─────────────────
  ipcMain.handle("api-request", (_event, { method, path: reqPath, body }) => {
    if (!license.isActive()) return LOCKED; // license lock = data API bhi band
    try {
      const result = handleApiRequest({ method, path: reqPath, body });
      // Only writes (POST/PUT/DELETE) need to touch disk — GET requests
      // never change data, so skipping the save there is a big speed win.
      if (method !== "GET") scheduleSave();
      return { ok: true, data: result === undefined ? null : result };
    } catch (err) {
      return { ok: false, status: err.status || 500, error: err.message || "Internal error" };
    }
  });

  // ── Local auth (register / forgot-password hata diye gaye hain) ───────
  ipcMain.handle("auth-login", (_e, creds) => {
    if (!license.isActive()) return LOCKED;
    try {
      return { ok: true, data: auth.login(creds) };
    } catch (err) {
      return { ok: false, code: err.code, error: err.message };
    }
  });
  // ── Cloud backup IPC ───────────────────────────────────────────────────
  const wrap = (fn) => async (_e, arg) => {
    if (!license.isActive()) return LOCKED;
    try {
      return { ok: true, data: await fn(arg) };
    } catch (err) {
      return { ok: false, error: err.message || "Cloud backup failed." };
    }
  };
  ipcMain.handle("cloud-backup-status", () => cloud.getStatus());
  ipcMain.handle("cloud-backup-set-auto", (_e, v) => cloud.setAuto(v));
  ipcMain.handle("cloud-backup-now", wrap(async () => { await cloud.backupNow("manual"); return cloud.getStatus(); }));
  ipcMain.handle("cloud-backup-list", wrap(() => cloud.listBackups()));
  ipcMain.handle("cloud-backup-restore", wrap((id) => cloud.restoreBackup(id)));
  ipcMain.handle("cloud-backup-restore-file", wrap(async () => {
    const { canceled, filePaths } = await dialog.showOpenDialog({
      title: "Choose a POS database backup (.db)",
      properties: ["openFile"],
      filters: [{ name: "POS Database", extensions: ["db"] }],
    });
    if (canceled || !filePaths?.[0]) return { canceled: true };
    cloud.restoreFromBytes(fs.readFileSync(filePaths[0])); // restarts the app
    return { restored: true };
  }));

  // ── License IPC ────────────────────────────────────────────────────────
  ipcMain.handle("license-status", () => license.getState());
  ipcMain.handle("license-refresh", () => license.refresh());
  ipcMain.handle("license-activate", async (_e, key) => {
    try {
      return { ok: true, data: await license.activate(key) };
    } catch (err) {
      return { ok: false, error: license.friendlyError(err) };
    }
  });
  // Lock hone par bhi client apna data safe kar sake (data yarghmal nahi):
  // poori database file ek jagah save kar do.
  ipcMain.handle("license-backup-db", async () => {
    const src = path.join(app.getPath("userData"), "pos-data.db");
    const stamp = new Date().toISOString().slice(0, 10);
    const { canceled, filePath } = await dialog.showSaveDialog({
      title: "Save data backup",
      defaultPath: `tech-riwaayat-pos-backup-${stamp}.db`,
      filters: [{ name: "POS Database", extensions: ["db"] }],
    });
    if (canceled || !filePath) return { ok: false, canceled: true };
    try {
      save();
      fs.copyFileSync(src, filePath);
      return { ok: true, path: filePath };
    } catch (err) {
      return { ok: false, error: err.message };
    }
  });

  createWindow();
  license.startBackground();
  cloud.startCloudBackupScheduler();

  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on("window-all-closed", () => {
  flushSave();
  if (process.platform !== "darwin") app.quit();
});

app.on("before-quit", () => {
  flushSave();
});

