import db, { uuid, nowIso } from "../db.js";
import { mapReturn } from "../utils/mappers.js";
import products from "./products.js";
import { update as updateInvoiceRecord } from "./invoices.js";
import { bumpCustomerStats } from "./customers.js";

// ── Order Returns (customer se wapis aaya hua maal) ───────────────────────
// Jab customer koi cheez wapis karta hai, hum yahan entry banate hain aur
// (agar catalog product select kiya gaya ho) us product ka stock wapis
// charha dete hain — taake wo dobara becha ja sake.
//
// Return do tareeqon se ban sakti hai:
//   1. General return — sirf product select karke (invoice se link nahi).
//   2. Invoice se return — customer ki kisi invoice ke andar se ek item
//      select karke. Is surat mein invoice ka total aur woh item khud kam
//      ho jate hain — chahe invoice pehle pura paid ho ya udhaar/partial
//      par ho. Advance/payments ko kabhi nahi chheda jata (na cash refund
//      banta hai, na koi nayi ledger entry) — bas total kam hone se
//      udhaar khud-b-khud kam ho jata hai (due = total - advance).

function tableFor(source) {
  return source === "manual" ? "manual_invoices" : "sales";
}

export function list() {
  return db.prepare("SELECT * FROM product_returns ORDER BY date DESC, created_at DESC").all().map(mapReturn);
}

// Kisi invoice ke ek line-item ki ab tak kitni qty return ho chuki hai.
export function getReturnedQtyForItem(invoiceId, itemIndex) {
  const row = db
    .prepare("SELECT COALESCE(SUM(qty), 0) as s FROM product_returns WHERE invoice_id = ? AND item_index = ?")
    .get(invoiceId, itemIndex);
  return Number(row?.s) || 0;
}

export const create = db.transaction((f) => {
  const qty = Number(f.qty);
  if (!qty || qty <= 0) {
    const err = new Error("Quantity must be greater than zero");
    err.status = 400;
    throw err;
  }

  let productId = f.productId || null;
  let productName = String(f.productName || "").trim();
  let price = Math.max(0, Number(f.price) || 0);
  let unitCost = Math.max(0, Number(f.unitCost) || 0);

  let invoiceId = null;
  let invoiceSource = null;
  let invoiceNumber = null;
  let customerId = null;
  let customerName = "";
  let itemIndex = null;
  let deductedFromInvoice = false;

  // ── Invoice se return ──────────────────────────────────────────────
  if (f.invoiceId && f.invoiceSource && f.itemIndex !== undefined && f.itemIndex !== null) {
    const table = tableFor(f.invoiceSource);
    const row = db.prepare(`SELECT * FROM ${table} WHERE id = ?`).get(f.invoiceId);
    if (!row) {
      const err = new Error("Invoice not found");
      err.status = 404;
      throw err;
    }
    const items = JSON.parse(row.items || "[]");
    const idx = Number(f.itemIndex);
    const item = items[idx];
    if (!item) {
      const err = new Error("Invoice item not found");
      err.status = 400;
      throw err;
    }

    const alreadyReturned = getReturnedQtyForItem(f.invoiceId, idx);
    const available = Number(item.qty || 0) - alreadyReturned;
    if (qty > available + 0.0001) {
      const err = new Error(`Sirf ${available} unit hi is item ki return ke liye bachi hai`);
      err.status = 400;
      throw err;
    }

    productId = item.productId || null;
    productName = item.name || productName;
    price = Number(item.unitPrice ?? item.salePrice ?? 0);
    unitCost = Number(item.costPrice ?? 0);
    invoiceId = f.invoiceId;
    invoiceSource = f.invoiceSource === "manual" ? "manual" : "pos";
    invoiceNumber = row.invoice_number ?? null;
    customerId = row.customer_id || null;
    itemIndex = idx;
    const invExtra = JSON.parse(row.extra || "{}");
    customerName = invExtra.customerName || "";

    // Invoice se return hone par uska total/item hamesha kam hote hain —
    // chahe invoice pehle paid ho ya udhaar/partial par ho. Advance ya
    // payments ko kabhi nahi chheda jata (na cash refund, na koi nayi
    // ledger entry) — bas invoice ka total kam hone se udhaar khud-b-khud
    // kam ho jata hai (due = total - advance).
    {
      // Item ko array se hataya nahi jata (sirf qty 0 tak kam hoti hai)
      // taake dobara return/undo hamesha isi item_index se sahi se link rahe.
      const newQty = Math.max(0, Number(item.qty || 0) - qty);
      const updatedItem = { ...item, qty: newQty, lineTotal: price * newQty, lineCost: unitCost * newQty };
      const newItems = items.map((it, i) => (i === idx ? updatedItem : it));

      const reduceBy = price * qty;
      const reduceCostBy = unitCost * qty;
      const newTotal = Math.max(0, (Number(row.total) || 0) - reduceBy);
      const newSubtotal = Math.max(0, (Number(invExtra.subtotal) || 0) - reduceBy);
      const newTotalCost = Math.max(0, (Number(invExtra.totalCost) || 0) - reduceCostBy);
      const newGrossProfit = (Number(invExtra.grossProfit) || 0) - (reduceBy - reduceCostBy);

      updateInvoiceRecord(f.invoiceId, invoiceSource, {
        items: newItems,
        total: newTotal,
        subtotal: newSubtotal,
        totalCost: newTotalCost,
        grossProfit: newGrossProfit,
      });

      if (customerId) {
        // Customer ka "Total Purchased" stat bhi utna hi kam ho jaye.
        bumpCustomerStats(customerId, 0, -reduceBy, null);
      }
      deductedFromInvoice = true;
    }
  }

  if (!productName) {
    const err = new Error("Product name is required");
    err.status = 400;
    throw err;
  }

  const id = uuid();
  const ts = nowIso();
  db.prepare(
    `INSERT INTO product_returns
      (id, product_id, product_name, qty, price, unit_cost, reason, note,
       invoice_id, invoice_source, invoice_number, customer_id, customer_name, item_index, deducted_from_invoice,
       date, created_at)
     VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`
  ).run(
    id, productId, productName, qty, price, unitCost, f.reason || "", f.note || "",
    invoiceId, invoiceSource, invoiceNumber, customerId, customerName, itemIndex, deductedFromInvoice ? 1 : 0,
    f.date || ts, ts
  );

  // Return karne se stock wapis shop mein aa jata hai.
  if (productId) {
    try {
      products.stockIn(productId, qty);
    } catch {
      /* product deleted/missing — return record still stands */
    }
  }

  return mapReturn(db.prepare("SELECT * FROM product_returns WHERE id = ?").get(id));
});

export const remove = db.transaction((id) => {
  const row = db.prepare("SELECT * FROM product_returns WHERE id = ?").get(id);
  if (!row) return;

  // Return delete karne se wapis wo stock hata dena chahiye jo return add
  // karte waqt product mein wapis charha diya gaya tha.
  if (row.product_id) {
    try {
      products.stockOut(row.product_id, row.qty);
    } catch {
      /* product deleted/missing, or stock already used elsewhere — ignore */
    }
  }

  // Agar is return ne kisi invoice ka total khud kam kiya tha, to delete
  // karte waqt wahi qty/total wapis us invoice mein jama karo.
  if (row.deducted_from_invoice && row.invoice_id && row.invoice_source && row.item_index !== null && row.item_index !== undefined) {
    const table = tableFor(row.invoice_source);
    const invRow = db.prepare(`SELECT * FROM ${table} WHERE id = ?`).get(row.invoice_id);
    if (invRow) {
      const items = JSON.parse(invRow.items || "[]");
      const idx = row.item_index;
      const item = items[idx];
      if (item) {
        const addBackQty = Number(row.qty) || 0;
        const price = Number(row.price) || 0;
        const unitCost = Number(row.unit_cost) || 0;
        const newQty = Number(item.qty || 0) + addBackQty;
        const updatedItem = { ...item, qty: newQty, lineTotal: price * newQty, lineCost: unitCost * newQty };
        const newItems = items.map((it, i) => (i === idx ? updatedItem : it));

        const addBy = price * addBackQty;
        const addCostBy = unitCost * addBackQty;
        const invExtra = JSON.parse(invRow.extra || "{}");

        updateInvoiceRecord(row.invoice_id, row.invoice_source, {
          items: newItems,
          total: (Number(invRow.total) || 0) + addBy,
          subtotal: (Number(invExtra.subtotal) || 0) + addBy,
          totalCost: (Number(invExtra.totalCost) || 0) + addCostBy,
          grossProfit: (Number(invExtra.grossProfit) || 0) + (addBy - addCostBy),
        });

        if (invRow.customer_id) {
          bumpCustomerStats(invRow.customer_id, 0, addBy, null);
        }
      }
    }
  }

  db.prepare("DELETE FROM product_returns WHERE id = ?").run(id);
});

export default { list, create, remove, getReturnedQtyForItem };
