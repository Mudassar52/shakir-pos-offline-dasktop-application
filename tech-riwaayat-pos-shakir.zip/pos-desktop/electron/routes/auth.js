import bcrypt from "bcryptjs";
import db, { uuid } from "../db.js";

// ── Local login ──────────────────────────────────────────────────────────
// Ab yahan koi default/hardcoded account nahi, koi "naya account" ya
// "password bhool gaye" flow nahi. Shop ka admin account license se aata hai:
// super admin license banate waqt username + password set karta hai, aur
// activation par yeh account is computer par bann jata hai. Password bhool
// jaye to super admin app se "New Password" set hota hai, jo agli license
// check par yahan apply ho jata hai (applyLicenseCredentials).
const LEGACY_DEFAULT_USERNAME = "shakirmahmood6566@gmail.com";

function mapUser(row) {
  if (!row) return null;
  return { id: row.id, username: row.username, name: row.full_name || row.username, role: row.role };
}

export function login({ username, password }) {
  const row = db.prepare("SELECT * FROM users WHERE username = ?").get(String(username || "").trim());
  const ok = row && bcrypt.compareSync(String(password || ""), row.password_hash);
  if (!ok) {
    const err = new Error("Invalid username or password");
    err.code = "auth/invalid-credential";
    throw err;
  }
  return mapUser(row);
}

export function userExists(username) {
  return !!db.prepare("SELECT id FROM users WHERE username = ?").get(String(username || "").trim());
}

// License se aaya hua admin account banata/update karta hai.
export function applyLicenseCredentials({ username, password, name }) {
  const clean = String(username || "").trim();
  if (!clean || !password) return;
  const hash = bcrypt.hashSync(String(password), 10);
  const existing = db.prepare("SELECT id FROM users WHERE username = ?").get(clean);
  if (existing) {
    db.prepare("UPDATE users SET password_hash = ? WHERE id = ?").run(hash, existing.id);
  } else {
    db.prepare(
      "INSERT INTO users (id, username, password_hash, full_name, role) VALUES (?,?,?,?,?)"
    ).run(uuid(), clean, hash, name || clean, "admin");
  }
  // Purane build ka hardcoded default account (agar is database mein bacha
  // hua ho) hata do — warna uska public password ek backdoor rehta.
  if (clean !== LEGACY_DEFAULT_USERNAME) {
    db.prepare("DELETE FROM users WHERE username = ?").run(LEGACY_DEFAULT_USERNAME);
  }
}

export default { login, userExists, applyLicenseCredentials };
