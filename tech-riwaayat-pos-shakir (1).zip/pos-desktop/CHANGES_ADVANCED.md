# Tech Riwaayat POS — Advanced Update

## 1. Supplier Ledger (proper accounting table)
- Naya **Ledger** tab (supplier profile ka default tab): `Date | Ref | Particulars | Debit | Credit | Running Balance`.
- Credit = Purchase / Opening Balance, Debit = Payment / Purchase Return. Balance `Cr` = hum ne dena hai.
- Date-range filter (pehle ka hisaab "Opening B/F" ban jata hai), type filter, search, newest-first, CSV, Print/PDF.
- **Opening Balance** entry (software se pehle ka purana baaqi).
- Backend: `GET /api/suppliers/:id/ledger?from=&to=`, `GET /api/supplier-ledger-summary`.
- Bug fix: supplier payment delete karne par ab invoice ka advance/remaining wapis theek hota hai.

## 2. Purchase Returns (maal supplier ko wapis)
- Supplier profile → **Purchase Return** + **Returns** tab.
- Invoice se (sirf bacha hua qty wapis ho sakta hai) ya general return.
- Save par: stock kam, ledger mein Debit, invoice ka remaining kam; delete par sab reverse.
- Naye tables: `supplier_returns`, `supplier_return_items`; backup/restore mein shamil.

## 3. Expiry Tracking
- Product form mein **Expiry Date** + **Batch No**.
- Products list par `EXPIRED` / `EXP 12d` badge; Stock filter mein *Expiring Soon* / *Expired*.
- Notification bell mein expiry alerts. Reports: Expired Stock, Expiring Soon.

## 4. Customer Ledger / Statement
- Customer profile → **Ledger / Statement** tab (purana dead `CustomerStatementModal` hata diya).
- Invoice/Purana udhaar = Debit; Payment/Advance/Discount = Credit; running Dr/Cr balance.
- Date range, type filters, "Cash sales chhupao", CSV, printable statement (signature lines ke saath).

## 5. Reports — 48 reports
Report Center (Reports → *All Reports*): 7 groups — Sales, Profit, Customers & Udaar, Inventory & Expiry,
Purchases & Suppliers, Returns & Losses, Expenses & Cash. Filters: date presets/custom, customer, supplier,
category, status, source, expense type, days/threshold. Har report: sort, column show/hide, search, totals,
CSV/Print, selected rows export.

## 6. Design system (`src/components/ui/`)
`Modal`, `Badge`/`StatusBadge`, `Button`, `Skeleton*`, `EmptyState`, `DataTable` (sorting, column visibility
saved per table, global-in-table search, bulk actions, pagination, totals, CSV/Print), `LedgerView`.
- **Global Search** (Ctrl+K ya `/`): pages, products, customers, suppliers, invoices, expenses; arrow keys + Enter.
- Page-load spinner ki jagah skeleton loaders. Suppliers list DataTable par (bulk delete samet).

## Migration
Purani database apne aap migrate hoti hai (supplier ledger table rebuild, naye columns) — data safe rehta hai.
