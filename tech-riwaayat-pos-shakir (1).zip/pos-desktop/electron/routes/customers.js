import db, { uuid, nowIso } from "../db.js";
import { mapCustomer } from "../utils/mappers.js";
import { badRequest } from "../utils/validate.js";

function checkCustomer(f, excludeId = null) {
  if (!String(f.name || "").trim()) throw badRequest("Customer ka naam zaroori hai.");
  const phone = String(f.phone || "").trim();
  if (phone) {
    const dup = db.prepare("SELECT id, name FROM customers WHERE phone = ?").all(phone).find((c) => c.id !== excludeId);
    if (dup) throw badRequest(`Yeh phone number pehle se \"${dup.name}\" ke naam par hai.`);
  }
}

export function list() {
  const rows = db.prepare("SELECT * FROM customers ORDER BY created_at ASC").all();
  return rows.map(mapCustomer);
}

export function create(f) {
  checkCustomer(f);
  const id = uuid();
  const ts = nowIso();
  db.prepare(
    `INSERT INTO customers (id, name, phone, email, city, total_orders, total_spent, last_order, adjustments, created_at, updated_at)
     VALUES (?,?,?,?,?,0,0,?,'[]',?,?)`
  ).run(id, String(f.name || "").trim(), String(f.phone || "").trim(), f.email || "", f.city || "", ts, ts, ts);
  return mapCustomer(db.prepare("SELECT * FROM customers WHERE id = ?").get(id));
}

export function update(id, f) {
  checkCustomer(f, id);
  const info = db
    .prepare(`UPDATE customers SET name=?, phone=?, email=?, city=?, updated_at=? WHERE id=?`)
    .run(String(f.name || "").trim(), String(f.phone || "").trim(), f.email || "", f.city || "", nowIso(), id);
  if (info.changes === 0) {
    const err = new Error("Customer not found");
    err.status = 404;
    throw err;
  }
  return mapCustomer(db.prepare("SELECT * FROM customers WHERE id = ?").get(id));
}

export function remove(id) {
  // Jis customer ka udaar baaki ho use delete karne se hisaab kho jata hai.
  const unpaid = db.prepare(
    `SELECT COUNT(*) AS c FROM (
       SELECT id FROM sales WHERE customer_id = ? AND payment_status IN ('udaar','partial')
       UNION ALL
       SELECT id FROM manual_invoices WHERE customer_id = ? AND payment_status IN ('udaar','partial'))`
  ).get(id, id);
  if (unpaid && unpaid.c > 0) throw badRequest(`Is customer ke ${unpaid.c} invoice ka udaar baaki hai. Pehle payment lein, phir delete karein.`);
  db.prepare("DELETE FROM customers WHERE id = ?").run(id);
}

export function addAdjustment(id, { type, amount, reason, date }) {
  if (type !== "credit" && type !== "debit") throw badRequest("Adjustment type galat hai (credit ya debit hona chahiye).");
  const adjAmt = Number(amount);
  if (!Number.isFinite(adjAmt) || adjAmt <= 0) throw badRequest("Amount 0 se zyada hona chahiye.");
  amount = adjAmt;
  const row = db.prepare("SELECT * FROM customers WHERE id = ?").get(id);
  if (!row) {
    const err = new Error("Customer not found");
    err.status = 404;
    throw err;
  }
  const current = JSON.parse(row.adjustments || "[]");
  current.push({ type, amount, reason, date });
  db.prepare("UPDATE customers SET adjustments = ?, updated_at = ? WHERE id = ?").run(
    JSON.stringify(current),
    nowIso(),
    id
  );
  return mapCustomer(db.prepare("SELECT * FROM customers WHERE id = ?").get(id));
}

// ── Advance Balance (customer ne pehle se diye hue paise) ─────────────────
// Alag column nahi rakha — "adjustments" JSON mein hi { type: 'advance' }
// entries ki tarah save hota hai. Available balance = ab tak jitna advance
// diya gaya, us mein se jitna kisi invoice par "Advance Balance Used" ho
// chuka hai wo minus karo.
export function addAdvance(id, { amount, note, date }) {
  const amt = Number(amount);
  if (!amt || amt <= 0) {
    const err = new Error("Amount 0 se zyada hona chahiye");
    err.status = 400;
    throw err;
  }
  const row = db.prepare("SELECT * FROM customers WHERE id = ?").get(id);
  if (!row) {
    const err = new Error("Customer not found");
    err.status = 404;
    throw err;
  }
  const current = JSON.parse(row.adjustments || "[]");
  current.push({ type: "advance", amount: amt, reason: note || "Advance Payment", date: date || nowIso() });
  db.prepare("UPDATE customers SET adjustments = ?, updated_at = ? WHERE id = ?").run(
    JSON.stringify(current),
    nowIso(),
    id
  );
  return mapCustomer(db.prepare("SELECT * FROM customers WHERE id = ?").get(id));
}

// Kitna advance balance abhi available hai (future udaar sale par khud
// istemal hone ke liye) — pos.js / invoices.js is se hi pata karte hain.
export function getAdvanceBalance(id) {
  return Math.max(0, getAdvanceRaw(id));
}

// Clamp ke bina (negative bhi) — return undo jaisi jagah galat hisaab pakadne ke liye.
export function getAdvanceRaw(id) {
  const row = db.prepare("SELECT adjustments FROM customers WHERE id = ?").get(id);
  if (!row) return 0;
  const adjustments = JSON.parse(row.adjustments || "[]");
  const given = adjustments
    .filter((a) => a.type === "advance")
    .reduce((s, a) => s + (Number(a.amount) || 0), 0);

  const usedRows = db
    .prepare(
      `SELECT payments, total, advance FROM sales WHERE customer_id = ?
       UNION ALL
       SELECT payments, total, advance FROM manual_invoices WHERE customer_id = ?`
    )
    .all(id, id);
  let used = 0;
  for (const r of usedRows) {
    // Bill baad mein kam hua (return/edit) to bill se zyada kata hua advance wapis mil jata hai.
    const pays = JSON.parse(r.payments || "[]");
    let adv = 0, other = 0;
    for (const p of pays) {
      if (p.note === "Advance Balance Used") adv += Number(p.amount) || 0;
      else other += Number(p.amount) || 0;
    }
    if (adv <= 0) continue;
    const legacy = pays.length === 0 ? Number(r.advance) || 0 : 0;
    used += Math.min(adv, Math.max(0, (Number(r.total) || 0) - other - legacy));
  }
  const refunded = adjustments
    .filter((a) => a.type === "advance_refund")
    .reduce((s, a) => s + (Number(a.amount) || 0), 0);
  return Math.round((given - refunded - used) * 100) / 100;
}

// ── Advance Refund (customer ko uska advance cash wapis dena) ─────────────
// adjustments mein { type: 'advance_refund' } entry banti hai. Ledger mein yeh DEBIT hai
// (paisa dukaan se bahar gaya), is liye advance balance utna kam ho jata hai.
export function refundAdvance(id, { amount, note, date }) {
  const amt = Number(amount);
  if (!Number.isFinite(amt) || amt <= 0) throw badRequest("Amount 0 se zyada hona chahiye.");
  const row = db.prepare("SELECT * FROM customers WHERE id = ?").get(id);
  if (!row) throw badRequest("Customer not found", 404);
  const available = getAdvanceBalance(id);
  if (amt > available + 0.001) throw badRequest(`Refund sirf ${available} tak ho sakta hai (itna hi advance balance baaki hai).`);
  const current = JSON.parse(row.adjustments || "[]");
  current.push({ type: "advance_refund", amount: amt, reason: note || "Advance wapis kiya", date: date || nowIso() });
  db.prepare("UPDATE customers SET adjustments = ?, updated_at = ? WHERE id = ?").run(JSON.stringify(current), nowIso(), id);
  return mapCustomer(db.prepare("SELECT * FROM customers WHERE id = ?").get(id));
}

// Galti se likhi hui advance entry (ya refund) hatana. Jo advance kisi bill mein
// istemal ho chuka ho (balance kam padta ho) use nahi hata sakte.
export function removeAdvanceEntry(id, index) {
  const row = db.prepare("SELECT * FROM customers WHERE id = ?").get(id);
  if (!row) throw badRequest("Customer not found", 404);
  const current = JSON.parse(row.adjustments || "[]");
  const i = Number(index);
  const entry = Number.isInteger(i) ? current[i] : null;
  if (!entry || (entry.type !== "advance" && entry.type !== "advance_refund")) throw badRequest("Yeh entry nahi mili.", 404);
  if (entry.type === "advance") {
    const available = getAdvanceBalance(id);
    if (Number(entry.amount) > available + 0.001) {
      throw badRequest(`Yeh advance hata nahi sakte: iska ${Math.round((Number(entry.amount) - available) * 100) / 100} kisi bill mein istemal ya wapis ho chuka hai. Pehle woh bill/refund hatayein.`);
    }
  }
  current.splice(i, 1);
  db.prepare("UPDATE customers SET adjustments = ?, updated_at = ? WHERE id = ?").run(JSON.stringify(current), nowIso(), id);
  return mapCustomer(db.prepare("SELECT * FROM customers WHERE id = ?").get(id));
}

// Internal helper used by sale/invoice creation & deletion to keep customer totals in sync.
export function bumpCustomerStats(customerId, deltaOrders, deltaSpent, lastOrder) {
  if (!customerId) return;
  const row = db.prepare("SELECT * FROM customers WHERE id = ?").get(customerId);
  if (!row) return;
  const newOrders = Math.max(0, (row.total_orders || 0) + deltaOrders);
  const newSpent = Math.max(0, (row.total_spent || 0) + deltaSpent);
  const newLastOrder = lastOrder || row.last_order;
  db.prepare("UPDATE customers SET total_orders=?, total_spent=?, last_order=?, updated_at=? WHERE id=?").run(
    newOrders,
    newSpent,
    newLastOrder,
    nowIso(),
    customerId
  );
}

export default { list, create, update, remove, addAdjustment, addAdvance, refundAdvance, removeAdvanceEntry, getAdvanceBalance, bumpCustomerStats };
