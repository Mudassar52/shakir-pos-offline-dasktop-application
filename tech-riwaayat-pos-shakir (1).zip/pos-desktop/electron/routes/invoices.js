import db, { uuid, nowIso } from "../db.js";
import { mapInvoice, num } from "../utils/mappers.js";
import { getNextInvoiceNumber } from "./settings.js";
import { bumpCustomerStats, getAdvanceBalance } from "./customers.js";
import { validateInvoiceInput, deductStock, restoreStock, badRequest } from "../utils/validate.js";

function tableFor(source) {
  return source === "manual" ? "manual_invoices" : "sales";
}

export function list() {
  const rows = db.prepare("SELECT * FROM manual_invoices ORDER BY created_at DESC").all();
  return rows.map((r) => mapInvoice(r, "manual"));
}

// POST /api/invoices/manual - create a manual invoice
export const createManual = db.transaction((data) => {
  validateInvoiceInput(data);
  deductStock(data.items || []);
  const counter = getNextInvoiceNumber();

  // Agar yeh udaar invoice hai aur customer ka pehle se diya hua advance
  // balance maujood hai, to wo yahan khud-ba-khud is bill par lag jata
  // hai — jitni zaroorat ho utna hi (jo bache wo udaar hi rehta hai).
  let advanceBalanceUsed = 0;
  if (data.paymentMode === "udaar" && data.customerId) {
    const available = getAdvanceBalance(data.customerId);
    const manualAdvance = Number(data.advance) || 0;
    const stillOwed = Math.max(0, (Number(data.total) || 0) - manualAdvance);
    advanceBalanceUsed = Math.min(available, stillOwed);
  }

  const totalPaidNow = (Number(data.advance) || 0) + advanceBalanceUsed;
  const paymentStatus = data.paymentMode === "udaar"
    ? (totalPaidNow >= Number(data.total) ? "paid" : totalPaidNow > 0 ? "partial" : "udaar")
    : "paid";
  const payments = [];
  if (data.paymentMode === "udaar" && Number(data.advance) > 0) {
    payments.push({ amount: Number(data.advance), date: nowIso(), note: "Advance at sale" });
  }
  if (advanceBalanceUsed > 0) {
    payments.push({ amount: advanceBalanceUsed, date: nowIso(), note: "Advance Balance Used" });
  }

  const extra = {
    customerName: data.customerName || "",
    customerPhone: data.customerPhone || "",
    customerAddress: data.customerAddress || "",
    notes: data.notes || "",
    subtotal: Number(data.subtotal) || 0,
    discount: Number(data.discount) || 0,
    tax: Number(data.tax) || 0,
    discountPercent: Number(data.discountPercent) || 0,
    taxPercent: Number(data.taxPercent) || 0,
    totalCost: Number(data.totalCost) || 0,
    grossProfit: Number(data.grossProfit) || 0,
    profitMargin: Number(data.profitMargin) || 0,
  };

  const id = uuid();
  const createdAt = data.createdAt || nowIso();
  db.prepare(
    `INSERT INTO manual_invoices
      (id, invoice_number, customer_id, items, total, advance, payment_mode, payment_status, payments,
       previous_udaar, show_previous_udaar_on_invoice, extra, created_at, updated_at)
     VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`
  ).run(
    id,
    counter,
    data.customerId || null,
    JSON.stringify(data.items || []),
    Number(data.total) || 0,
    Number(data.advance) || 0,
    data.paymentMode || null,
    paymentStatus,
    JSON.stringify(payments),
    Number(data.previousUdaar) || 0,
    data.showPreviousUdaarOnInvoice ? 1 : 0,
    JSON.stringify(extra),
    createdAt,
    createdAt
  );

  if (data.customerId) {
    bumpCustomerStats(data.customerId, 1, Number(data.total) || 0, nowIso());
  }

  return mapInvoice(db.prepare("SELECT * FROM manual_invoices WHERE id = ?").get(id), "manual");
});

// PUT /api/invoices/:id?source=pos|manual
// opts.skipSync: jab koi aur route (jaise Returns) stock/customer total khud sambhal raha ho.
export const update = db.transaction((id, source, data, opts = {}) => {
  const table = tableFor(source);
  const row = db.prepare(`SELECT * FROM ${table} WHERE id = ?`).get(id);
  if (!row) {
    const err = new Error("Invoice not found");
    err.status = 404;
    throw err;
  }
  if (data.total !== undefined && (!Number.isFinite(Number(data.total)) || Number(data.total) < 0)) throw badRequest("Total galat hai.");
  if (data.advance !== undefined && Number(data.advance) < 0) throw badRequest("Advance negative nahi ho sakta.");

  // Items badle to stock ka farq (naya - purana) lagao; customer ka total_spent bhi theek karo.
  if (Array.isArray(data.items) && !opts.skipSync) {
    const sum = (arr) => { const m = new Map(); for (const it of arr) if (it.productId) m.set(it.productId, (m.get(it.productId) || 0) + (Number(it.qty) || 0)); return m; };
    const oldM = sum(JSON.parse(row.items || "[]"));
    const newM = sum(data.items);
    for (const [pid, q] of newM) {
      const diff = q - (oldM.get(pid) || 0);
      if (diff > 0) {
        const pr = db.prepare("SELECT name, current_stock FROM products WHERE id = ?").get(pid);
        if (pr && Number(pr.current_stock) < diff) throw badRequest(`"${pr.name}" ka stock kam hai (maujood: ${Number(pr.current_stock)}).`);
      }
    }
    const ids = new Set([...oldM.keys(), ...newM.keys()]);
    for (const pid of ids) {
      const diff = (newM.get(pid) || 0) - (oldM.get(pid) || 0);
      if (diff !== 0) db.prepare("UPDATE products SET current_stock = current_stock - ?, updated_at = ? WHERE id = ?").run(diff, nowIso(), pid);
    }
  }
  if (data.total !== undefined && row.customer_id && !opts.skipSync) {
    bumpCustomerStats(row.customer_id, 0, Number(data.total) - num(row.total), null);
  }

  const prevExtra = JSON.parse(row.extra || "{}");
  const extra = {
    ...prevExtra,
    customerName: data.customerName ?? prevExtra.customerName ?? "",
    customerPhone: data.customerPhone ?? prevExtra.customerPhone ?? "",
    customerAddress: data.customerAddress ?? prevExtra.customerAddress ?? "",
    notes: data.notes ?? prevExtra.notes ?? "",
    subtotal: data.subtotal !== undefined ? Number(data.subtotal) : prevExtra.subtotal ?? 0,
    discount: data.discount !== undefined ? Number(data.discount) : prevExtra.discount ?? 0,
    tax: data.tax !== undefined ? Number(data.tax) : prevExtra.tax ?? 0,
    discountPercent: data.discountPercent !== undefined ? Number(data.discountPercent) : prevExtra.discountPercent ?? 0,
    taxPercent: data.taxPercent !== undefined ? Number(data.taxPercent) : prevExtra.taxPercent ?? 0,
    totalCost: data.totalCost !== undefined ? Number(data.totalCost) : prevExtra.totalCost ?? 0,
    grossProfit: data.grossProfit !== undefined ? Number(data.grossProfit) : prevExtra.grossProfit ?? 0,
    profitMargin: data.profitMargin !== undefined ? Number(data.profitMargin) : prevExtra.profitMargin ?? 0,
  };

  db.prepare(
    `UPDATE ${table} SET
       items = ?, total = ?, advance = ?, payment_mode = ?, payment_status = ?,
       customer_id = ?, invoice_number = ?, extra = ?, updated_at = ?
     WHERE id = ?`
  ).run(
    data.items ? JSON.stringify(data.items) : row.items,
    data.total !== undefined ? Number(data.total) : row.total,
    data.advance !== undefined ? Number(data.advance) : row.advance,
    data.paymentMode || row.payment_mode,
    data.paymentStatus || row.payment_status,
    data.customerId || row.customer_id,
    data.invoiceNumber !== undefined ? data.invoiceNumber : row.invoice_number,
    JSON.stringify(extra),
    nowIso(),
    id
  );

  return mapInvoice(db.prepare(`SELECT * FROM ${table} WHERE id = ?`).get(id), source);
});

// DELETE /api/invoices/:id?source=pos|manual - delete and restore stock/stats
export const remove = db.transaction((id, source) => {
  const table = tableFor(source);
  const inv = db.prepare(`SELECT * FROM ${table} WHERE id = ?`).get(id);
  if (!inv) {
    const err = new Error("Invoice not found");
    err.status = 404;
    throw err;
  }
  db.prepare(`DELETE FROM ${table} WHERE id = ?`).run(id);

  restoreStock(JSON.parse(inv.items || "[]"));

  if (inv.customer_id) {
    bumpCustomerStats(inv.customer_id, -1, -num(inv.total), null);
  }
});

// POST /api/invoices/receive-payment
export const receivePayment = db.transaction(({ allocations = [], date, note }) => {
  for (const alloc of allocations) {
    const payAmt = Number(alloc.amount);
    if (!payAmt || payAmt <= 0 || alloc.invoiceId === "bulk") continue;
    const table = tableFor(alloc.source);
    const inv = db.prepare(`SELECT * FROM ${table} WHERE id = ?`).get(alloc.invoiceId);
    if (!inv) continue;

    const existing = JSON.parse(inv.payments || "[]");
    const newPayments = [...existing, { amount: payAmt, date, note: note || "" }];
    const advInPayments = newPayments
      .filter((p) => p.note && p.note.includes("Advance at sale"))
      .reduce((s, p) => s + p.amount, 0);
    const otherPmts = newPayments
      .filter((p) => !p.note || !p.note.includes("Advance at sale"))
      .reduce((s, p) => s + p.amount, 0);
    const standAloneAdv = advInPayments > 0 ? 0 : num(inv.advance);
    const totalPaidAmt = advInPayments + otherPmts + standAloneAdv;
    const prevPaid = (inv.payments ? JSON.parse(inv.payments) : []).reduce((a, p) => a + (Number(p.amount) || 0), 0) + (JSON.parse(inv.payments || "[]").some((p) => p.note && p.note.includes("Advance at sale")) ? 0 : num(inv.advance));
    if (prevPaid + payAmt > num(inv.total) + 0.01) {
      throw badRequest(`Invoice #${inv.invoice_number} ka baaki sirf ${Math.max(0, num(inv.total) - prevPaid)} hai; is se zyada payment nahi li ja sakti.`);
    }
    const newStatus = totalPaidAmt >= num(inv.total) ? "paid" : totalPaidAmt > 0 ? "partial" : "udaar";

    const clearsPreviousUdaar = newStatus === "paid" && inv.show_previous_udaar_on_invoice && num(inv.previous_udaar) > 0;

    db.prepare(
      `UPDATE ${table} SET
          payments = ?,
          payment_status = ?,
          previous_udaar_cleared = ?,
          previous_udaar_cleared_at = ?,
          updated_at = ?
       WHERE id = ?`
    ).run(
      JSON.stringify(newPayments),
      newStatus,
      clearsPreviousUdaar ? 1 : inv.previous_udaar_cleared,
      clearsPreviousUdaar ? nowIso() : inv.previous_udaar_cleared_at,
      nowIso(),
      alloc.invoiceId
    );
  }
  return { success: true };
});

export default { list, createManual, update, remove, receivePayment };
