// Return ke baad invoice ke paise bill ke barabar karna.
//
// Misal: 2 item ka 200 ka bill poora ada ho chuka, 1 item (100) return hua.
// Ab bill 100 ka hai magar 200 wasool dikhte the. Yahan:
//   1) "Advance Balance Used" wala hissa pehle wapis customer ke advance mein jata hai
//   2) baaqi zyada raqam (asli paise) ya to cash wapis (mode "cash") ya customer ke
//      advance mein jama (mode "advance") hoti hai
//   3) invoice ka status (paid / partial / udaar) dobara theek hota hai
// Undo karne par yeh sab wapis pehle jaisa ho jata hai.
import db, { nowIso } from "../db.js";
import { badRequest } from "./validate.js";
import { getAdvanceRaw } from "../routes/customers.js";

const num = (v) => Number(v) || 0;
const r2 = (v) => Math.round(v * 100) / 100;
const isAdvUsed = (p) => p.note === "Advance Balance Used";

function statusFor(row, pays, advanceField, total) {
  if (row.payment_mode !== "udaar") return row.payment_status;
  const paid = pays.reduce((s, p) => s + num(p.amount), 0) + (pays.length === 0 ? num(advanceField) : 0);
  return paid >= total - 0.009 ? "paid" : paid > 0.009 ? "partial" : "udaar";
}

export function settleOnReturn({ table, invoiceId, newTotal, returnId, refundMode }) {
  const row = db.prepare(`SELECT * FROM ${table} WHERE id = ?`).get(invoiceId);
  const pays = JSON.parse(row.payments || "[]");
  const hadNoPayments = pays.length === 0;
  const paid = pays.reduce((s, p) => s + num(p.amount), 0) + (hadNoPayments ? num(row.advance) : 0);
  let left = r2(paid - newTotal);
  let advance = num(row.advance);
  const trace = { date: nowIso(), trimmed: [], advanceFieldBefore: null, real: 0, mode: null, advanceEntry: false };

  if (left > 0.009) {
    // 1) advance-used pehle: yeh automatically customer ke advance balance mein wapis aa jata hai
    for (let i = pays.length - 1; i >= 0 && left > 0.009; i--) {
      if (!isAdvUsed(pays[i])) continue;
      const cut = Math.min(left, num(pays[i].amount));
      if (cut > 0) { pays[i] = { ...pays[i], amount: r2(num(pays[i].amount) - cut) }; trace.trimmed.push({ idx: i, amount: cut }); left = r2(left - cut); }
    }
    // 2) asli paise
    for (let i = pays.length - 1; i >= 0 && left > 0.009; i--) {
      if (isAdvUsed(pays[i])) continue;
      const cut = Math.min(left, num(pays[i].amount));
      if (cut > 0) { pays[i] = { ...pays[i], amount: r2(num(pays[i].amount) - cut) }; trace.trimmed.push({ idx: i, amount: cut }); trace.real = r2(trace.real + cut); left = r2(left - cut); }
    }
    if (hadNoPayments && left > 0.009) {
      // cash sale: paise sirf `advance` field mein hote hain
      trace.advanceFieldBefore = advance;
      const cut = Math.min(left, advance);
      advance = r2(advance - cut);
      trace.real = r2(trace.real + cut);
    }
  }

  if (trace.real > 0.009) {
    const hasCustomer = !!row.customer_id;
    trace.mode = refundMode === "advance" && hasCustomer ? "advance"
      : refundMode === "cash" ? "cash"
      : (!hadNoPayments && hasCustomer ? "advance" : "cash");
    if (trace.mode === "advance") {
      const cust = db.prepare("SELECT adjustments FROM customers WHERE id = ?").get(row.customer_id);
      const adj = JSON.parse(cust.adjustments || "[]");
      const ref = row.invoice_number ? `INV-${String(row.invoice_number).padStart(3, "0")}` : "invoice";
      adj.push({ type: "advance", amount: trace.real, reason: `Return credit — ${ref}`, date: trace.date, returnId, invoiceId });
      db.prepare("UPDATE customers SET adjustments = ?, updated_at = ? WHERE id = ?").run(JSON.stringify(adj), nowIso(), row.customer_id);
      trace.advanceEntry = true;
    }
  }

  const extra = JSON.parse(row.extra || "{}");
  extra.returnTrace = { ...(extra.returnTrace || {}), [returnId]: trace };
  db.prepare(`UPDATE ${table} SET payments = ?, advance = ?, payment_status = ?, extra = ?, updated_at = ? WHERE id = ?`)
    .run(JSON.stringify(pays), advance, statusFor(row, pays, advance, newTotal), JSON.stringify(extra), nowIso(), invoiceId);
  return trace;
}

// Return delete (undo) hone par settle ka asar wapas karo. Total pehle hi wapis barh chuka hona chahiye.
export function unsettleOnReturn({ table, invoiceId, returnId }) {
  const row = db.prepare(`SELECT * FROM ${table} WHERE id = ?`).get(invoiceId);
  if (!row) return;
  const extra = JSON.parse(row.extra || "{}");
  const trace = extra.returnTrace?.[returnId];
  if (!trace) {
    // Purane returns (is fix se pehle) — sirf status dobara theek karo
    const pays0 = JSON.parse(row.payments || "[]");
    db.prepare(`UPDATE ${table} SET payment_status = ? WHERE id = ?`).run(statusFor(row, pays0, row.advance, num(row.total)), invoiceId);
    return;
  }
  const pays = JSON.parse(row.payments || "[]");
  for (const t of trace.trimmed) if (pays[t.idx]) pays[t.idx] = { ...pays[t.idx], amount: r2(num(pays[t.idx].amount) + t.amount) };
  const advance = trace.advanceFieldBefore !== null && trace.advanceFieldBefore !== undefined ? trace.advanceFieldBefore : num(row.advance);

  if (trace.advanceEntry && row.customer_id) {
    const cust = db.prepare("SELECT adjustments FROM customers WHERE id = ?").get(row.customer_id);
    const adj = JSON.parse(cust.adjustments || "[]");
    const at = adj.findIndex((a) => a.returnId === returnId);
    if (at >= 0) { adj.splice(at, 1); db.prepare("UPDATE customers SET adjustments = ?, updated_at = ? WHERE id = ?").run(JSON.stringify(adj), nowIso(), row.customer_id); }
  }
  delete extra.returnTrace[returnId];
  db.prepare(`UPDATE ${table} SET payments = ?, advance = ?, payment_status = ?, extra = ?, updated_at = ? WHERE id = ?`)
    .run(JSON.stringify(pays), advance, statusFor(row, pays, advance, num(row.total)), JSON.stringify(extra), nowIso(), invoiceId);

  // Agar is return ka advance credit pehle hi kharch/wapis ho chuka ho to undo na ho (hisaab ghalat ho jata)
  if (row.customer_id && getAdvanceRaw(row.customer_id) < -0.009) {
    throw badRequest("Is return ka advance credit kisi bill mein istemal ya wapis ho chuka hai, is liye return undo nahi ho sakta. Pehle woh advance wala bill/refund hatayein.");
  }
}
