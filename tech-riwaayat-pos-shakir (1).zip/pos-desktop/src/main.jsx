import "@fontsource-variable/inter";
import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "./index.css";
import App from "./App";

// Server ne koi request wajah ke saath reject ki (jaise "stock kam hai", "phone pehle se
// maujood hai") aur screen ne wo handle nahi ki — to user ko wajah dikhao, chup mat raho.
window.addEventListener("unhandledrejection", (e) => {
  const err = e.reason;
  if (err && typeof err.status === "number" && err.status >= 400 && err.status < 500 && err.message) {
    e.preventDefault();
    window.alert(err.message);
  }
});

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <App />
  </StrictMode>
);
