import { useState, useMemo, useEffect, useRef } from "react";
import Pagination, { paginate } from "../common/Pagination";
import { SkeletonRows } from "./Skeleton";
import EmptyState from "./EmptyState";
import { downloadCSV, printTable } from "../../utils/exportUtils";

/**
 * Reusable DataTable — Sorting, Column visibility, Search, Bulk actions
 * (checkbox selection), Pagination, Skeleton loading, Totals footer,
 * CSV export aur Print. Sab pages isi ko use karein.
 *
 * columns: [{
 *   key, label,
 *   accessor?: (row) => value      // sort / search / export ke liye
 *   render?: (row, value) => node  // custom cell
 *   align?: "left"|"right"|"center"
 *   sortable?: boolean (default true)
 *   defaultHidden?: boolean
 *   total?: "sum"                  // footer mein jama
 *   format?: (value) => string     // total/export format
 *   locked?: boolean               // column hide nahi ho sakta
 * }]
 * bulkActions: [{ label, onClick(selectedRows), tone: "danger"|"primary" }]
 */
const cmp = (a, b) => {
  const an = a === null || a === undefined || a === "";
  const bn = b === null || b === undefined || b === "";
  if (an && bn) return 0;
  if (an) return 1;
  if (bn) return -1;
  if (typeof a === "number" && typeof b === "number") return a - b;
  return String(a).localeCompare(String(b), undefined, { numeric: true, sensitivity: "base" });
};

function loadHidden(persistKey, columns) {
  try {
    const saved = persistKey && JSON.parse(localStorage.getItem(`dt_hidden_${persistKey}`) || "null");
    if (Array.isArray(saved)) return new Set(saved);
  } catch { /* ignore */ }
  return new Set(columns.filter((c) => c.defaultHidden).map((c) => c.key));
}

export default function DataTable({
  columns,
  rows = [],
  rowKey = (r) => r.id,
  loading = false,
  searchable = true,
  searchPlaceholder = "Search...",
  pageSize = 15,
  selectable = false,
  bulkActions = [],
  exportName,
  title,
  subtitle,
  onRowClick,
  initialSort = null, // { key, dir }
  persistKey,
  toolbar = null,
  emptyTitle,
  emptyHint,
  rowClassName,
  showTotals = true,
  dense = false,
}) {
  const [query, setQuery] = useState("");
  const [sort, setSort] = useState(initialSort);
  const [page, setPage] = useState(1);
  const [hidden, setHidden] = useState(() => loadHidden(persistKey, columns));
  const [selected, setSelected] = useState(new Set());
  const [colMenu, setColMenu] = useState(false);
  const menuRef = useRef(null);

  useEffect(() => {
    if (!colMenu) return;
    const h = (e) => { if (menuRef.current && !menuRef.current.contains(e.target)) setColMenu(false); };
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, [colMenu]);

  useEffect(() => { setPage(1); }, [query, sort, rows.length]);

  const toggleHidden = (key) => {
    setHidden((prev) => {
      const next = new Set(prev);
      next.has(key) ? next.delete(key) : next.add(key);
      try { if (persistKey) localStorage.setItem(`dt_hidden_${persistKey}`, JSON.stringify([...next])); } catch { /* ignore */ }
      return next;
    });
  };

  const visibleCols = useMemo(() => columns.filter((c) => !hidden.has(c.key)), [columns, hidden]);
  const getVal = (col, row) => (col.accessor ? col.accessor(row) : row[col.key]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return rows;
    return rows.filter((row) =>
      columns.some((c) => {
        const v = getVal(c, row);
        return v !== null && v !== undefined && String(c.format ? c.format(v) : v).toLowerCase().includes(q);
      })
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [rows, query, columns]);

  const sorted = useMemo(() => {
    if (!sort) return filtered;
    const col = columns.find((c) => c.key === sort.key);
    if (!col) return filtered;
    const dir = sort.dir === "desc" ? -1 : 1;
    return [...filtered].sort((a, b) => dir * cmp(getVal(col, a), getVal(col, b)));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filtered, sort, columns]);

  const { pageItems, currentPage } = useMemo(() => paginate(sorted, page, pageSize), [sorted, page, pageSize]);

  const onSort = (col) => {
    if (col.sortable === false) return;
    setSort((prev) => {
      if (!prev || prev.key !== col.key) return { key: col.key, dir: "asc" };
      if (prev.dir === "asc") return { key: col.key, dir: "desc" };
      return null;
    });
  };

  // ── selection ──
  const allKeys = useMemo(() => sorted.map(rowKey), [sorted]); // eslint-disable-line react-hooks/exhaustive-deps
  const allSelected = allKeys.length > 0 && allKeys.every((k) => selected.has(k));
  const someSelected = selected.size > 0 && !allSelected;
  const toggleAll = () => setSelected(allSelected ? new Set() : new Set(allKeys));
  const toggleOne = (k) => setSelected((prev) => { const n = new Set(prev); n.has(k) ? n.delete(k) : n.add(k); return n; });
  const selectedRows = useMemo(() => rows.filter((r) => selected.has(rowKey(r))), [rows, selected]); // eslint-disable-line react-hooks/exhaustive-deps

  // ── totals (filtered rows par) ──
  const totals = useMemo(() => {
    const t = {};
    visibleCols.forEach((c) => {
      if (c.total === "sum") t[c.key] = sorted.reduce((s, r) => s + (Number(getVal(c, r)) || 0), 0);
    });
    return t;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sorted, visibleCols]);
  const hasTotals = showTotals && Object.keys(totals).length > 0;

  const fmt = (c, v) => (c.format ? c.format(v) : v ?? "");
  const exportRows = () => sorted.map((r) => visibleCols.map((c) => fmt(c, getVal(c, r))));
  const handleExport = () => downloadCSV(`${exportName || title || "export"}-${new Date().toISOString().slice(0, 10)}`, visibleCols.map((c) => c.label), exportRows());
  const handlePrint = () =>
    printTable({
      title: title || exportName || "Report",
      subtitle: subtitle || `${sorted.length} rows`,
      headers: visibleCols.map((c) => c.label),
      rows: exportRows(),
      aligns: visibleCols.map((c) => c.align || "left"),
      footer: hasTotals ? visibleCols.map((c, i) => (c.total === "sum" ? fmt(c, totals[c.key]) : i === 0 ? "Total" : "")) : null,
    });

  const pad = dense ? "px-3 py-2" : "px-4 py-3";
  const colCount = visibleCols.length + (selectable ? 1 : 0);

  return (
    <div className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
      {/* Toolbar */}
      <div className="flex flex-wrap items-center gap-2 px-4 py-3 border-b border-slate-100">
        {searchable && (
          <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 focus-within:border-blue-300 focus-within:bg-white flex-1 min-w-[160px] max-w-xs">
            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#94A3B8" strokeWidth="2" strokeLinecap="round"><circle cx="11" cy="11" r="8" /><path d="m21 21-4.35-4.35" /></svg>
            <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder={searchPlaceholder} className="bg-transparent text-sm outline-none w-full placeholder:text-slate-400" />
            {query && <button onClick={() => setQuery("")} className="text-slate-400 hover:text-slate-600 text-xs">✕</button>}
          </div>
        )}
        <span className="text-xs text-slate-400 font-medium">{sorted.length} {sorted.length === 1 ? "row" : "rows"}</span>
        <div className="flex-1" />
        {toolbar}
        <div className="relative" ref={menuRef}>
          <button onClick={() => setColMenu((v) => !v)} className="flex items-center gap-1.5 px-3 py-2 rounded-xl border border-slate-200 bg-white text-xs font-bold text-slate-600 hover:bg-slate-50">
            <svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M12 3v18M3 6h6M3 12h6M3 18h6M15 6h6M15 12h6M15 18h6" /></svg>
            Columns
          </button>
          {colMenu && (
            <div className="absolute right-0 top-full mt-1.5 w-52 bg-white border border-slate-100 rounded-xl shadow-xl z-30 py-1.5 max-h-72 overflow-y-auto">
              {columns.map((c) => (
                <label key={c.key} className={`flex items-center gap-2.5 px-3.5 py-2 text-xs font-semibold ${c.locked ? "opacity-50" : "cursor-pointer hover:bg-slate-50"}`}>
                  <input type="checkbox" checked={!hidden.has(c.key)} disabled={c.locked} onChange={() => toggleHidden(c.key)} className="accent-blue-600" />
                  <span className="text-slate-700 truncate">{c.label}</span>
                </label>
              ))}
            </div>
          )}
        </div>
        {(exportName || title) && (
          <>
            <button onClick={handleExport} disabled={!sorted.length} className="px-3 py-2 rounded-xl border border-slate-200 bg-white text-xs font-bold text-slate-600 hover:bg-slate-50 disabled:opacity-40">CSV</button>
            <button onClick={handlePrint} disabled={!sorted.length} className="px-3 py-2 rounded-xl border border-slate-200 bg-white text-xs font-bold text-slate-600 hover:bg-slate-50 disabled:opacity-40">Print</button>
          </>
        )}
      </div>

      {/* Bulk action bar */}
      {selectable && selected.size > 0 && (
        <div className="flex flex-wrap items-center gap-2 px-4 py-2.5 bg-blue-50 border-b border-blue-100">
          <span className="text-xs font-bold text-blue-700">{selected.size} selected</span>
          <button onClick={() => setSelected(new Set())} className="text-xs font-semibold text-blue-500 hover:underline">Clear</button>
          <div className="flex-1" />
          {bulkActions.map((a) => (
            <button key={a.label} onClick={() => a.onClick(selectedRows, () => setSelected(new Set()))}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold ${a.tone === "danger" ? "bg-red-600 hover:bg-red-700 text-white" : "bg-blue-600 hover:bg-blue-700 text-white"}`}>
              {a.label}
            </button>
          ))}
        </div>
      )}

      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="bg-slate-50/80 border-b border-slate-100">
              {selectable && (
                <th className="w-10 px-4 py-3">
                  <input type="checkbox" checked={allSelected} ref={(el) => { if (el) el.indeterminate = someSelected; }} onChange={toggleAll} className="accent-blue-600" />
                </th>
              )}
              {visibleCols.map((c) => {
                const active = sort?.key === c.key;
                return (
                  <th key={c.key} onClick={() => onSort(c)}
                    className={`${pad} text-[10px] font-bold uppercase tracking-wider text-slate-400 whitespace-nowrap select-none ${c.align === "right" ? "text-right" : c.align === "center" ? "text-center" : "text-left"} ${c.sortable === false ? "" : "cursor-pointer hover:text-slate-600"}`}>
                    <span className="inline-flex items-center gap-1">
                      {c.label}
                      {c.sortable !== false && (
                        <span className={`text-[9px] ${active ? "text-blue-600" : "text-slate-300"}`}>{active ? (sort.dir === "asc" ? "▲" : "▼") : "⇅"}</span>
                      )}
                    </span>
                  </th>
                );
              })}
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <SkeletonRows rows={Math.min(pageSize, 7)} cols={colCount} />
            ) : pageItems.length === 0 ? (
              <tr><td colSpan={colCount}><EmptyState title={emptyTitle} hint={emptyHint} /></td></tr>
            ) : (
              pageItems.map((row) => {
                const k = rowKey(row);
                return (
                  <tr key={k} onClick={onRowClick ? () => onRowClick(row) : undefined}
                    className={`border-b border-slate-50 last:border-0 hover:bg-slate-50/60 ${onRowClick ? "cursor-pointer" : ""} ${selected.has(k) ? "bg-blue-50/40" : ""} ${rowClassName ? rowClassName(row) : ""}`}>
                    {selectable && (
                      <td className="w-10 px-4 py-3" onClick={(e) => e.stopPropagation()}>
                        <input type="checkbox" checked={selected.has(k)} onChange={() => toggleOne(k)} className="accent-blue-600" />
                      </td>
                    )}
                    {visibleCols.map((c) => {
                      const v = getVal(c, row);
                      return (
                        <td key={c.key} className={`${pad} text-slate-700 ${c.align === "right" ? "text-right" : c.align === "center" ? "text-center" : ""} ${c.className || ""}`}>
                          {c.render ? c.render(row, v) : c.format ? c.format(v) : v ?? "—"}
                        </td>
                      );
                    })}
                  </tr>
                );
              })
            )}
          </tbody>
          {!loading && hasTotals && sorted.length > 0 && (
            <tfoot>
              <tr className="bg-slate-100/80 border-t-2 border-slate-200">
                {selectable && <td />}
                {visibleCols.map((c, i) => (
                  <td key={c.key} className={`${pad} text-xs font-black text-slate-800 ${c.align === "right" ? "text-right" : ""}`}>
                    {c.total === "sum" ? fmt(c, totals[c.key]) : i === 0 ? "Total" : ""}
                  </td>
                ))}
              </tr>
            </tfoot>
          )}
        </table>
      </div>
      <div className="px-4 pb-3"><Pagination total={sorted.length} page={currentPage} pageSize={pageSize} onPageChange={setPage} /></div>
    </div>
  );
}
