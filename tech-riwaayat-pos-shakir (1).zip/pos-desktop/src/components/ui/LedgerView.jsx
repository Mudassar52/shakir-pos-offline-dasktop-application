import { useMemo, useState } from "react";
import DateRangePicker from "../common/DateRangePicker";
import Pagination, { paginate } from "../common/Pagination";
import Badge from "./Badge";
import { Skeleton } from "./Skeleton";
import EmptyState from "./EmptyState";
import { computeLedger, balanceLabel, ledgerColumns, fmtMoney, fmtDate, exportLedgerCSV, printLedger } from "../../utils/ledger";

const TYPE_TONE = { invoice: "blue", purchase: "blue", old: "slate", opening: "slate", payment: "green", advance: "amber", return: "violet", adj_credit: "green", adj_debit: "red", advance_refund: "red", advance_used: "amber" };
const PAGE = 25;

/**
 * Ledger: Date | Ref | Particulars | Billed/Purchased | Received/Paid | Running Balance.
 * Customer (side="debit")  → Billed | Received  — Baaqi = customer ne dena hai, Advance = customer ka jama paisa.
 * Supplier (side="credit") → Purchased | Paid   — Baaqi = hum ne dena hai, Advance = supplier ke paas hamara paisa.
 * Naye entries upar (newest first) — default.
 */
export default function LedgerView({ entries = [], side = "debit", party, partyLabel = "Customer", title = "Account Statement", shopName, loading = false, allowHideCash = false, summaryLabels }) {
  const [range, setRange] = useState({ from: null, to: null });
  const [types, setTypes] = useState(new Set());
  const [search, setSearch] = useState("");
  const [hideCash, setHideCash] = useState(allowHideCash);
  const [newestFirst, setNewestFirst] = useState(true);
  const [page, setPage] = useState(1);

  const hasRange = range.from && range.to;
  const ledger = useMemo(
    () => computeLedger(entries, { from: hasRange ? range.from : null, to: hasRange ? range.to : null, side, types, search, hideCash }),
    [entries, range, side, types, search, hideCash, hasRange]
  );
  const presentTypes = useMemo(() => {
    const m = new Map();
    entries.forEach((e) => m.set(e.type, e.typeLabel));
    return [...m.entries()];
  }, [entries]);

  const ordered = useMemo(() => (newestFirst ? [...ledger.rows].reverse() : ledger.rows), [ledger.rows, newestFirst]);
  const { pageItems, currentPage } = paginate(ordered, page, PAGE);

  const toggleType = (t) => { setTypes((p) => { const n = new Set(p); n.has(t) ? n.delete(t) : n.add(t); return n; }); setPage(1); };
  const col = ledgerColumns(side);
  const totals = side === "debit" ? { left: ledger.totalDebit, right: ledger.totalCredit } : { left: ledger.totalCredit, right: ledger.totalDebit };
  const labels = summaryLabels || (side === "debit"
    ? { debit: "Total Billed (Bill / Udhaar)", credit: "Total Received (Mila)", closing: "Running Balance", pos: "Customer ne dena hai", neg: "Customer ka advance jama hai" }
    : { debit: "Total Purchased (Maal liya)", credit: "Total Paid (Diye)", closing: "Running Balance", pos: "Hum ne dena hai", neg: "Supplier ke paas hamara advance" });
  const closingTone = ledger.closing > 0.005 ? (side === "debit" ? "text-red-600" : "text-red-600") : ledger.closing < -0.005 ? "text-amber-600" : "text-emerald-600";

  const bfRow = (
    <tr className="bg-slate-100/80 font-bold">
                        <td className="px-4 py-2.5 text-xs" colSpan={5}>Opening Balance (B/F){hasRange ? ` — ${fmtDate(range.from)} se pehle ka` : ""}</td>
                        <td className="px-4 py-2.5 text-right text-xs">{balanceLabel(ledger.broughtForward)}</td>
                      </tr>
  );

  const doPrint = () => printLedger({ title, partyLabel, party, shopName, ledger: { ...ledger, rows: ledger.rows }, side, range: hasRange ? range : null, newestFirst, note: hideCash ? "Cash sales jo usi waqt ada hui, is statement se chhupayi gayi hain (balance par koi asar nahi)." : "" });

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="bg-white rounded-2xl border border-slate-100 p-4"><p className="text-[11px] text-slate-400">Opening (B/F)</p><p className="text-base font-black text-slate-800 mt-1">{loading ? <Skeleton className="h-5 w-24" /> : balanceLabel(ledger.broughtForward)}</p></div>
        <div className="bg-white rounded-2xl border border-slate-100 p-4"><p className="text-[11px] text-slate-400">{labels.debit}</p><p className="text-base font-black text-slate-800 mt-1">{loading ? <Skeleton className="h-5 w-24" /> : fmtMoney(totals.left)}</p></div>
        <div className="bg-white rounded-2xl border border-slate-100 p-4"><p className="text-[11px] text-slate-400">{labels.credit}</p><p className="text-base font-black text-emerald-600 mt-1">{loading ? <Skeleton className="h-5 w-24" /> : fmtMoney(totals.right)}</p></div>
        <div className="bg-white rounded-2xl border border-slate-100 p-4"><p className="text-[11px] text-slate-400">{labels.closing}</p><p className={`text-base font-black mt-1 ${closingTone}`}>{loading ? <Skeleton className="h-5 w-24" /> : balanceLabel(ledger.closing)}</p>
          <p className="text-[10px] text-slate-400 mt-0.5">{Math.abs(ledger.closing) < 0.005 ? "Hisaab barabar" : ledger.closing > 0 ? labels.pos : labels.neg}</p></div>
      </div>

      {!loading && ledger.closing < -0.005 && (
        <div className="rounded-2xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-800">
          <b>Advance jama hai: {fmtMoney(Math.abs(ledger.closing))}</b> — {side === "debit" ? "is customer ka paisa pehle se hamare paas hai, agle bill mein khud adjust ho jayega." : "is supplier ke paas hamara paisa pehle se jama hai, agli purchase mein adjust hoga."}
        </div>
      )}
      <p className="text-[11px] text-slate-400 px-1">
        <b className="text-slate-500">Running Balance</b>: <b className="text-red-600">Baaqi</b> = {side === "debit" ? "customer ne abhi dena hai" : "humne supplier ko dena hai"} · <b className="text-amber-600">Advance</b> = {side === "debit" ? "customer ne pehle se zyada de diya" : "humne supplier ko pehle se zyada de diya"}. Naye entries sab se upar hain.
      </p>
      <div className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
        <div className="flex flex-wrap items-center gap-2 px-4 py-3 border-b border-slate-100">
          <input value={search} onChange={(e) => { setSearch(e.target.value); setPage(1); }} placeholder="Search particulars / ref..." className="px-3 py-2 rounded-xl border border-slate-200 bg-slate-50 text-sm outline-none focus:border-blue-300 focus:bg-white w-52" />
          <DateRangePicker value={range} onChange={(r) => { setRange(r); setPage(1); }} />
          {range.from && <button onClick={() => setRange({ from: null, to: null })} className="text-xs font-semibold text-slate-500 hover:text-slate-800">Clear dates</button>}
          <div className="flex-1" />
          {allowHideCash && (
            <label className="flex items-center gap-1.5 text-xs font-semibold text-slate-600 cursor-pointer">
              <input type="checkbox" checked={hideCash} onChange={(e) => setHideCash(e.target.checked)} className="accent-blue-600" /> Cash sales chhupao
            </label>
          )}
          <label className="flex items-center gap-1.5 text-xs font-semibold text-slate-600 cursor-pointer">
            <input type="checkbox" checked={newestFirst} onChange={(e) => setNewestFirst(e.target.checked)} className="accent-blue-600" /> Newest first
          </label>
          <button onClick={() => exportLedgerCSV(`${title}-${party.name}`, ledger, side, newestFirst)} className="px-3 py-2 rounded-xl border border-slate-200 bg-white text-xs font-bold text-slate-600 hover:bg-slate-50">CSV</button>
          <button onClick={doPrint} className="px-3 py-2 rounded-xl bg-violet-600 hover:bg-violet-700 text-white text-xs font-bold">Print / PDF</button>
        </div>

        {presentTypes.length > 1 && (
          <div className="flex flex-wrap items-center gap-1.5 px-4 py-2 border-b border-slate-100 bg-slate-50/50">
            <span className="text-[10px] font-bold uppercase text-slate-400 mr-1">Type</span>
            {presentTypes.map(([t, label]) => (
              <button key={t} onClick={() => toggleType(t)} className={`px-2.5 py-1 rounded-full text-[11px] font-bold border transition-colors ${types.has(t) ? "bg-blue-600 text-white border-blue-600" : "bg-white text-slate-500 border-slate-200 hover:border-slate-300"}`}>{label}</button>
            ))}
            {types.size > 0 && <button onClick={() => setTypes(new Set())} className="text-[11px] font-semibold text-slate-400 hover:text-slate-700 ml-1">reset</button>}
          </div>
        )}

        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-slate-800 text-white">
                {["Date", "Ref", "Particulars"].map((h) => <th key={h} className="px-4 py-2.5 text-left text-[10px] font-bold uppercase tracking-wider">{h}</th>)}
                {[col.left, col.right, "Running Balance"].map((h) => <th key={h} className="px-4 py-2.5 text-right text-[10px] font-bold uppercase tracking-wider">{h}</th>)}
              </tr>
            </thead>
            <tbody>
              {loading ? Array.from({ length: 6 }).map((_, i) => <tr key={i}><td colSpan={6} className="px-4 py-3"><Skeleton className="h-4 w-full" /></td></tr>) : (
                <>
                  {!newestFirst && bfRow}
                  {pageItems.length === 0 ? (
                    <tr><td colSpan={6}><EmptyState title="Is filter mein koi entry nahi" hint="Date range ya type filter badal kar dekhein." /></td></tr>
                  ) : pageItems.map((r) => (
                    <tr key={r.id} className="border-b border-slate-50 hover:bg-slate-50/60">
                      <td className="px-4 py-2.5 text-xs text-slate-500 whitespace-nowrap">{fmtDate(r.date)}</td>
                      <td className="px-4 py-2.5 text-xs font-bold text-blue-600 whitespace-nowrap">{r.reference || "—"}</td>
                      <td className="px-4 py-2.5"><div className="flex items-center gap-2"><Badge tone={TYPE_TONE[r.type] || "slate"}>{r.typeLabel}</Badge><span className="text-slate-600 text-xs">{r.description}</span></div></td>
                      <td className="px-4 py-2.5 text-right font-semibold text-slate-800">{r[col.leftKey] ? fmtMoney(r[col.leftKey]) : ""}</td>
                      <td className="px-4 py-2.5 text-right font-semibold text-emerald-600">{r[col.rightKey] ? fmtMoney(r[col.rightKey]) : ""}</td>
                      <td className={`px-4 py-2.5 text-right font-black whitespace-nowrap ${r.balance > 0.005 ? "text-red-600" : r.balance < -0.005 ? "text-amber-600" : "text-emerald-600"}`}>{balanceLabel(r.balance)}</td>
                    </tr>
                  ))}
                  {newestFirst && bfRow}
                </>
              )}
            </tbody>
            {!loading && (
              <tfoot>
                <tr className="bg-slate-100 border-t-2 border-slate-300">
                  <td colSpan={3} className="px-4 py-3 text-xs font-black text-slate-700">Total / Closing Balance</td>
                  <td className="px-4 py-3 text-right text-xs font-black">{fmtMoney(totals.left)}</td>
                  <td className="px-4 py-3 text-right text-xs font-black text-emerald-700">{fmtMoney(totals.right)}</td>
                  <td className={`px-4 py-3 text-right text-sm font-black ${closingTone}`}>{balanceLabel(ledger.closing)}</td>
                </tr>
              </tfoot>
            )}
          </table>
        </div>
        <div className="px-4 pb-3"><Pagination total={ordered.length} page={currentPage} pageSize={PAGE} onPageChange={setPage} /></div>
      </div>
    </div>
  );
}
