const VARIANTS = {
  primary: "bg-blue-600 hover:bg-blue-700 text-white shadow-sm shadow-blue-200",
  success: "bg-emerald-600 hover:bg-emerald-700 text-white shadow-sm shadow-emerald-200",
  danger: "bg-red-600 hover:bg-red-700 text-white",
  secondary: "bg-white hover:bg-slate-50 text-slate-700 border border-slate-200",
  ghost: "bg-slate-100 hover:bg-slate-200 text-slate-600",
  soft: "bg-blue-50 hover:bg-blue-100 text-blue-600",
};
const SIZES = { sm: "px-3 py-1.5 text-xs", md: "px-4 py-2.5 text-sm", lg: "px-5 py-3 text-sm" };

export default function Button({ variant = "primary", size = "md", loading = false, disabled = false, icon, children, className = "", ...rest }) {
  return (
    <button
      disabled={disabled || loading}
      className={`inline-flex items-center justify-center gap-2 font-bold rounded-xl transition-colors disabled:opacity-50 disabled:cursor-not-allowed ${VARIANTS[variant]} ${SIZES[size]} ${className}`}
      {...rest}
    >
      {loading ? <span className="w-3.5 h-3.5 border-2 border-current border-t-transparent rounded-full animate-spin" /> : icon}
      {children}
    </button>
  );
}
