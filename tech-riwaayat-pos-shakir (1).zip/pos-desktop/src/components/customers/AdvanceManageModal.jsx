import { useState } from "react";
import Modal from "../ui/Modal";
import { formatCurrency } from "../../utils/productHelpers";

// Advance ka hisaab: balance, cash wapis (refund) karna, aur galat entry hatana.
export default function AdvanceManageModal({ customer, balance, onRefund, onRemove, onClose }) {
  const [amount, setAmount] = useState("");
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  const entries = (customer.adjustments || [])
    .map((a, index) => ({ ...a, index }))
    .filter((a) => a.type === "advance" || a.type === "advance_refund")
    .reverse();

  const amt = parseFloat(amount) || 0;

  const doRefund = async () => {
    setError("");
    if (amt <= 0) return setError("Amount likhein");
    if (amt > balance + 0.001) return setError(`Refund sirf ${formatCurrency(balance)} tak ho sakta hai`);
    if (!window.confirm(`${customer.name} ko ${formatCurrency(amt)} cash wapis dena confirm karein?`)) return;
    setBusy(true);
    try {
      await onRefund({ amount: amt, note: note.trim(), date: new Date().toISOString() });
      setAmount(""); setNote("");
    } catch (e) {
      setError(e.message || "Refund nahi ho saka");
    } finally {
      setBusy(false);
    }
  };

  const doRemove = async (e) => {
    const what = e.type === "advance" ? "advance entry" : "refund entry";
    if (!window.confirm(`Yeh ${what} (${formatCurrency(e.amount)}) hata dein? Hisaab usi hisaab se badal jayega.`)) return;
    setError("");
    setBusy(true);
    try {
      await onRemove(e.index);
    } catch (err) {
      setError(err.message || "Hata nahi saki");
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal open onClose={onClose} title="Advance Balance" subtitle={customer.name} size="md">
      <div className="space-y-5">
        <div className="flex items-center justify-between bg-amber-50 border border-amber-100 rounded-xl px-4 py-3">
          <span className="text-sm text-amber-800 font-semibold">Abhi Advance Balance</span>
          <span className="text-lg font-black text-amber-600">{formatCurrency(balance)}</span>
        </div>

        <div className="space-y-2">
          <p className="text-xs font-bold text-slate-500 uppercase tracking-wider">Advance wapis karein (cash refund)</p>
          <div className="flex gap-2">
            <input type="number" min="0" step="any" value={amount} onChange={(e) => setAmount(e.target.value)}
              placeholder="Amount" disabled={balance <= 0 || busy}
              className="w-32 px-3 py-2 text-sm border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-amber-300 disabled:bg-slate-50" />
            <input type="text" value={note} onChange={(e) => setNote(e.target.value)} placeholder="Note (optional)" disabled={balance <= 0 || busy}
              className="flex-1 px-3 py-2 text-sm border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-amber-300 disabled:bg-slate-50" />
            <button onClick={doRefund} disabled={balance <= 0 || busy}
              className="px-4 py-2 text-sm font-bold text-white bg-amber-500 hover:bg-amber-600 rounded-xl disabled:opacity-40">Refund</button>
          </div>
          {balance <= 0 && <p className="text-xs text-slate-400">Is customer ka koi advance balance baaki nahi.</p>}
        </div>

        {error && <p className="text-sm text-red-600 bg-red-50 border border-red-100 rounded-xl px-3 py-2">{error}</p>}

        <div>
          <p className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Advance History</p>
          {entries.length === 0 ? (
            <p className="text-sm text-slate-400">Koi entry nahi.</p>
          ) : (
            <ul className="divide-y divide-slate-100 border border-slate-100 rounded-xl">
              {entries.map((e) => (
                <li key={e.index} className="flex items-center justify-between gap-3 px-3 py-2.5">
                  <div className="min-w-0">
                    <p className="text-sm font-semibold text-slate-700">
                      <span className={e.type === "advance" ? "text-emerald-600" : "text-red-600"}>
                        {e.type === "advance" ? "+" : "−"}{formatCurrency(e.amount)}
                      </span>{" "}
                      <span className="text-xs font-medium text-slate-400">{e.type === "advance" ? (e.returnId ? "Return credit" : "Advance liya") : "Wapis kiya"}</span>
                    </p>
                    <p className="text-xs text-slate-400 truncate">
                      {e.date ? new Date(e.date).toLocaleDateString("en-PK") : ""}{e.reason ? ` · ${e.reason}` : ""}
                    </p>
                  </div>
                  <button onClick={() => doRemove(e)} disabled={busy}
                    className="text-xs font-bold text-red-500 hover:text-red-700 px-2 py-1 rounded-lg hover:bg-red-50 disabled:opacity-40">Delete</button>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </Modal>
  );
}
