import { useState, useMemo } from "react";
import StatsGrid from "../common/StatsGrid";
import DateRangePicker from "../common/DateRangePicker";
import ProductSelector from "../common/ProductSelector";
import { getInvoiceDue, formatCurrency } from "../../utils/productHelpers";
import { returnExcess } from "../../utils/advance";

function formatDate(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString("en-PK", { day: "2-digit", month: "short", year: "numeric" });
}

const RETURN_REASONS = ["Customer Changed Mind", "Wrong Item", "Damaged/Defective", "Size/Quality Issue", "Other"];

let rowIdCounter = 0;
function newRowId() {
  rowIdCounter += 1;
  return `ret_row_${rowIdCounter}`;
}
function emptyRow() {
  return { rowId: newRowId(), product: null, qty: "", price: "", reason: RETURN_REASONS[0], note: "" };
}

// Kisi customer ki saari invoices (POS + Manual dono) dhoondo — bilkul
// wahi matching logic jo Customer Profile mein use hoti hai (purani
// invoices jin mein customerId save nahi tha, unke liye naam/phone se
// bhi match ho jata hai).
function findCustomerInvoices(customer, allInvoices) {
  if (!customer) return [];
  return allInvoices
    .filter((inv) => {
      if (inv.customerId === customer.id) return true;
      if (!inv.customerId && inv.customerName &&
        inv.customerName.trim().toLowerCase() === customer.name.trim().toLowerCase() &&
        (!inv.customerPhone || !customer.phone || inv.customerPhone.replace(/\D/g, "") === customer.phone.replace(/\D/g, ""))
      ) return true;
      return false;
    })
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
}

// ── Naya Return Add Karein ─────────────────────────────────────────────
// Do tareeqe: "Alag Se" (sirf product select karke, invoice se link nahi)
// ya "Invoice Se" (customer ki invoice ke andar se item select karke —
// paid invoice ka total khud kam ho jata hai, udhaar wali ko chheda nahi
// jata).
function AddReturnModal({ products, customers, allInvoices, returns, onClose, onSave }) {
  const [mode, setMode] = useState("general"); // "general" | "invoice"
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  // ── General mode state ──
  const [rows, setRows] = useState([emptyRow()]);
  const updateRow = (rowId, patch) => {
    setRows((prev) => prev.map((r) => (r.rowId === rowId ? { ...r, ...patch } : r)));
    setError("");
  };
  const addRow = () => setRows((prev) => [...prev, emptyRow()]);
  const removeRow = (rowId) => setRows((prev) => (prev.length > 1 ? prev.filter((r) => r.rowId !== rowId) : prev));

  // ── Invoice mode state ──
  const [customerQuery, setCustomerQuery] = useState("");
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [selectedInvoice, setSelectedInvoice] = useState(null);
  const [selectedItems, setSelectedItems] = useState({}); // itemIndex -> { checked, qty }
  const [invoiceReason, setInvoiceReason] = useState(RETURN_REASONS[0]);
  const [invoiceNote, setInvoiceNote] = useState("");

  const matchingCustomers = useMemo(() => {
    if (!customerQuery.trim()) return [];
    const q = customerQuery.trim().toLowerCase();
    return customers.filter((c) => c.name.toLowerCase().includes(q) || (c.phone || "").includes(q)).slice(0, 8);
  }, [customerQuery, customers]);

  const customerInvoices = useMemo(() => findCustomerInvoices(selectedCustomer, allInvoices).slice(0, 30), [selectedCustomer, allInvoices]);

  const invoiceDue = selectedInvoice ? getInvoiceDue(selectedInvoice) : 0;

  // Return ke baad agar bill se zyada paise wasool dikhein to user se poochna hai kya karna hai
  const [refundChoice, setRefundChoice] = useState("");
  const excessInfo = useMemo(() => {
    if (!selectedInvoice) return null;
    const amount = Object.entries(selectedItems).reduce((sum, [idx, v]) => {
      const item = selectedInvoice.items?.[idx];
      return v?.checked && item ? sum + Number(item.unitPrice ?? item.salePrice ?? 0) * (Number(v.qty) || 0) : sum;
    }, 0);
    const info = returnExcess(selectedInvoice, amount);
    const canAdvance = !!selectedInvoice.customerId;
    const defaultMode = info.isCashSale || !canAdvance ? "cash" : "advance";
    return { ...info, amount, canAdvance, mode: refundChoice === "advance" && !canAdvance ? "cash" : (refundChoice || defaultMode) };
  }, [selectedInvoice, selectedItems, refundChoice]);

  // Har item ki ab tak kitni qty return ho chuki hai (isi invoice ke returns records se)
  const alreadyReturnedByIndex = useMemo(() => {
    if (!selectedInvoice) return {};
    const map = {};
    returns.forEach((r) => {
      if (r.invoiceId === selectedInvoice.id && r.itemIndex !== null && r.itemIndex !== undefined) {
        map[r.itemIndex] = (map[r.itemIndex] || 0) + r.qty;
      }
    });
    return map;
  }, [selectedInvoice, returns]);

  const pickCustomer = (c) => {
    setSelectedCustomer(c);
    setCustomerQuery(c.name);
    setSelectedInvoice(null);
    setSelectedItems({});
  };

  const pickInvoice = (inv) => {
    setSelectedInvoice(inv);
    setSelectedItems({});
  };

  const toggleItem = (idx, available) => {
    setSelectedItems((prev) => {
      const cur = prev[idx];
      if (cur?.checked) {
        const next = { ...prev };
        delete next[idx];
        return next;
      }
      return { ...prev, [idx]: { checked: true, qty: available } };
    });
    setError("");
  };

  const updateItemQty = (idx, qty) => {
    setSelectedItems((prev) => ({ ...prev, [idx]: { ...prev[idx], qty } }));
  };

  const handleGeneralSubmit = async () => {
    for (const r of rows) {
      if (!r.product) { setError("Har row mein product select karein"); return; }
      if (!Number(r.qty) || Number(r.qty) <= 0) { setError("Har product ki quantity 0 se zyada honi chahiye"); return; }
    }
    try {
      setSaving(true);
      for (const r of rows) {
        await onSave({
          productId: r.product.id,
          productName: r.product.name,
          qty: Number(r.qty),
          price: Number(r.price) || 0,
          reason: r.reason,
          note: r.note,
        });
      }
      onClose();
    } catch (err) {
      setError(err.message || "Save nahi ho saka");
    } finally {
      setSaving(false);
    }
  };

  const handleInvoiceSubmit = async () => {
    const picks = Object.entries(selectedItems).filter(([, v]) => v.checked);
    if (picks.length === 0) { setError("Kam az kam ek item select karein"); return; }
    for (const [idx, v] of picks) {
      const item = selectedInvoice.items[idx];
      const available = Number(item.qty || 0) - (alreadyReturnedByIndex[idx] || 0);
      if (!Number(v.qty) || Number(v.qty) <= 0) { setError(`"${item.name}" ki quantity 0 se zyada honi chahiye`); return; }
      if (Number(v.qty) > available) { setError(`"${item.name}" ki sirf ${available} unit hi return ke liye bachi hai`); return; }
    }
    try {
      setSaving(true);
      for (const [idx, v] of picks) {
        await onSave({
          invoiceId: selectedInvoice.id,
          invoiceSource: selectedInvoice.source,
          itemIndex: Number(idx),
          qty: Number(v.qty),
          reason: invoiceReason,
          note: invoiceNote,
          refundMode: excessInfo?.realExcess > 0.009 ? excessInfo.mode : undefined,
        });
      }
      onClose();
    } catch (err) {
      setError(err.message || "Save nahi ho saka");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <div className="bg-white rounded-2xl w-full max-w-2xl shadow-2xl max-h-[92vh] flex flex-col">
        <div className="flex items-center justify-between px-6 pt-5 pb-4 border-b border-slate-100 flex-shrink-0">
          <h2 className="font-bold text-slate-800 text-lg">Naya Return Add Karein</h2>
          <button onClick={onClose} className="w-8 h-8 flex items-center justify-center rounded-xl hover:bg-slate-100 text-slate-400">
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M18 6 6 18M6 6l12 12" /></svg>
          </button>
        </div>

        {/* Mode toggle */}
        <div className="px-6 pt-4 flex-shrink-0">
          <div className="flex gap-2 bg-slate-100 rounded-xl p-1">
            <button
              onClick={() => { setMode("general"); setError(""); }}
              className={`flex-1 py-2 rounded-lg text-sm font-bold transition-colors ${mode === "general" ? "bg-white text-blue-600 shadow-sm" : "text-slate-500"}`}
            >
              Alag Se Return
            </button>
            <button
              onClick={() => { setMode("invoice"); setError(""); }}
              className={`flex-1 py-2 rounded-lg text-sm font-bold transition-colors ${mode === "invoice" ? "bg-white text-blue-600 shadow-sm" : "text-slate-500"}`}
            >
              Invoice Se Return
            </button>
          </div>
        </div>

        <div className="px-6 py-5 space-y-3 overflow-y-auto scrollbar-hide flex-1">
          {mode === "general" ? (
            <>
              {rows.map((r, idx) => (
                <div key={r.rowId} className="bg-slate-50 rounded-xl p-3.5 border border-slate-100">
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-xs font-bold text-slate-500">Product #{idx + 1}</p>
                    {rows.length > 1 && (
                      <button onClick={() => removeRow(r.rowId)} title="Row hataein"
                        className="w-6 h-6 flex items-center justify-center bg-red-50 hover:bg-red-100 text-red-500 rounded-lg transition-colors">
                        <svg xmlns="http://www.w3.org/2000/svg" width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M18 6 6 18M6 6l12 12" /></svg>
                      </button>
                    )}
                  </div>
                  <div className="space-y-2.5">
                    <ProductSelector
                      products={products}
                      selectedProduct={r.product}
                      onSelect={(p) => updateRow(r.rowId, { product: p, price: r.price === "" ? (p?.salePrice ?? "") : r.price })}
                      placeholder="Product search karein..."
                    />
                    <div className="grid grid-cols-2 gap-2.5">
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-500 mb-1">Quantity Returned</label>
                        <input type="number" value={r.qty} onChange={(e) => updateRow(r.rowId, { qty: e.target.value })} placeholder="0"
                          className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm outline-none focus:border-blue-400 bg-white" />
                      </div>
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-500 mb-1">Price (per unit)</label>
                        <input type="number" value={r.price} onChange={(e) => updateRow(r.rowId, { price: e.target.value })} placeholder="0"
                          className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm outline-none focus:border-blue-400 bg-white" />
                      </div>
                    </div>
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-500 mb-1">Reason</label>
                      <select value={r.reason} onChange={(e) => updateRow(r.rowId, { reason: e.target.value })}
                        className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm outline-none focus:border-blue-400 bg-white">
                        {RETURN_REASONS.map((rs) => <option key={rs} value={rs}>{rs}</option>)}
                      </select>
                    </div>
                    <input type="text" value={r.note} onChange={(e) => updateRow(r.rowId, { note: e.target.value })} placeholder="Note (optional)..."
                      className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm outline-none focus:border-blue-400 bg-white" />
                    {r.product && (
                      <p className="text-[11px] text-emerald-600 bg-emerald-50 rounded-lg px-2.5 py-1.5">
                        ✓ Save karne par is product ka stock wapis <b>{r.qty || 0}</b> unit se badh jayega.
                        {Number(r.price) > 0 && Number(r.qty) > 0 && (
                          <> Return Amount: <b>Rs {(Number(r.price) * Number(r.qty)).toLocaleString("en-PK")}</b></>
                        )}
                      </p>
                    )}
                  </div>
                </div>
              ))}

              <button onClick={addRow} type="button"
                className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl border-2 border-dashed border-slate-200 hover:border-blue-300 hover:bg-blue-50/30 text-sm font-bold text-slate-500 hover:text-blue-600 transition-colors">
                <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M12 5v14M5 12h14" /></svg>
                Ek Aur Product Add Karein
              </button>
            </>
          ) : (
            <>
              {/* Step 1: Customer select */}
              <div>
                <label className="block text-[11px] font-semibold text-slate-500 mb-1">Customer</label>
                <input
                  type="text"
                  value={customerQuery}
                  onChange={(e) => { setCustomerQuery(e.target.value); setSelectedCustomer(null); setSelectedInvoice(null); setSelectedItems({}); }}
                  placeholder="Customer ka naam ya phone search karein..."
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm outline-none focus:border-blue-400 bg-white"
                />
                {!selectedCustomer && matchingCustomers.length > 0 && (
                  <div className="mt-1.5 bg-white border border-slate-200 rounded-lg shadow-sm max-h-40 overflow-y-auto">
                    {matchingCustomers.map((c) => (
                      <button key={c.id} onClick={() => pickCustomer(c)}
                        className="w-full text-left px-3 py-2 text-sm hover:bg-blue-50 flex items-center justify-between">
                        <span className="font-semibold text-slate-700">{c.name}</span>
                        <span className="text-xs text-slate-400">{c.phone}</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Step 2: Invoice select */}
              {selectedCustomer && (
                <div>
                  <label className="block text-[11px] font-semibold text-slate-500 mb-1">Invoice</label>
                  {customerInvoices.length === 0 ? (
                    <p className="text-xs text-slate-400 bg-slate-50 rounded-lg px-3 py-2.5">Is customer ki koi invoice nahi mili.</p>
                  ) : (
                    <div className="bg-slate-50 rounded-xl border border-slate-100 max-h-40 overflow-y-auto divide-y divide-slate-100">
                      {customerInvoices.map((inv) => {
                        const due = getInvoiceDue(inv);
                        const isSelected = selectedInvoice?.id === inv.id;
                        return (
                          <button key={inv.id} onClick={() => pickInvoice(inv)}
                            className={`w-full text-left px-3 py-2.5 flex items-center justify-between text-sm hover:bg-blue-50/60 ${isSelected ? "bg-blue-50" : ""}`}>
                            <span className="font-semibold text-slate-700">#{inv.invoiceNumber} · {formatDate(inv.createdAt)}</span>
                            <span className="flex items-center gap-2">
                              <span className="text-xs text-slate-500">{formatCurrency(inv.total)}</span>
                              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${due <= 0.01 ? "bg-emerald-50 text-emerald-600" : "bg-amber-50 text-amber-600"}`}>
                                {due <= 0.01 ? "Paid" : "Udhaar"}
                              </span>
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  )}
                </div>
              )}

              {/* Step 3: Item select */}
              {selectedInvoice && (
                <>
                  <div className="rounded-lg px-3 py-2 text-xs font-semibold bg-emerald-50 text-emerald-700">
                    ✓ Return save karne par is invoice ka total, item aur (agar udhaar hai to) udhaar bhi khud kam ho jayega. Advance/cash refund alag se track nahi hota.
                    {invoiceDue > 0.01 && <span className="block mt-0.5 text-amber-600">Is invoice par abhi {formatCurrency(invoiceDue)} udhaar baaqi hai — return ke baad ye kam ho jayega.</span>}
                  </div>

                  <div className="space-y-2">
                    {selectedInvoice.items.map((item, idx) => {
                      const alreadyReturned = alreadyReturnedByIndex[idx] || 0;
                      const available = Number(item.qty || 0) - alreadyReturned;
                      const picked = selectedItems[idx];
                      if (available <= 0) {
                        return (
                          <div key={idx} className="flex items-center justify-between px-3 py-2 bg-slate-50 rounded-lg opacity-60">
                            <span className="text-sm text-slate-500">{item.name}</span>
                            <span className="text-[11px] text-slate-400 font-semibold">Pura return ho chuka</span>
                          </div>
                        );
                      }
                      return (
                        <div key={idx} className={`flex items-center gap-3 px-3 py-2.5 rounded-lg border ${picked?.checked ? "border-blue-300 bg-blue-50/40" : "border-slate-200 bg-white"}`}>
                          <input type="checkbox" checked={!!picked?.checked} onChange={() => toggleItem(idx, available)}
                            className="w-4 h-4 accent-blue-600 flex-shrink-0" />
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-semibold text-slate-700 truncate">{item.name}</p>
                            <p className="text-[11px] text-slate-400">Kul: {item.qty} · Return ke liye bachi: {available} · {formatCurrency(item.unitPrice)}/unit</p>
                          </div>
                          {picked?.checked && (
                            <input type="number" min="1" max={available} value={picked.qty}
                              onChange={(e) => updateItemQty(idx, e.target.value)}
                              className="w-16 px-2 py-1.5 rounded-lg border border-slate-200 text-sm text-center outline-none focus:border-blue-400 flex-shrink-0" />
                          )}
                        </div>
                      );
                    })}
                  </div>

                  <div className="grid grid-cols-2 gap-2.5">
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-500 mb-1">Reason</label>
                      <select value={invoiceReason} onChange={(e) => setInvoiceReason(e.target.value)}
                        className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm outline-none focus:border-blue-400 bg-white">
                        {RETURN_REASONS.map((rs) => <option key={rs} value={rs}>{rs}</option>)}
                      </select>
                    </div>
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-500 mb-1">Note (optional)</label>
                      <input type="text" value={invoiceNote} onChange={(e) => setInvoiceNote(e.target.value)}
                        className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm outline-none focus:border-blue-400 bg-white" />
                    </div>
                  </div>
                </>
              )}
            </>
          )}

          {mode === "invoice" && excessInfo && (excessInfo.realExcess > 0.009 || excessInfo.advanceBack > 0.009) && (
            <div className="rounded-xl border border-amber-200 bg-amber-50 p-3 space-y-2">
              {excessInfo.advanceBack > 0.009 && (
                <p className="text-xs text-amber-800">
                  Is bill mein customer ke advance se <b>{formatCurrency(excessInfo.advanceBack)}</b> kata tha — woh wapis customer ke advance balance mein chala jayega.
                </p>
              )}
              {excessInfo.realExcess > 0.009 && (
                <>
                  <p className="text-xs text-amber-800">
                    Is bill ke paise pehle hi wasool ho chuke hain. Return ke baad <b>{formatCurrency(excessInfo.realExcess)}</b> zyada ho gaye — in ka kya karna hai?
                  </p>
                  <label className="flex items-start gap-2 text-xs text-slate-700 cursor-pointer">
                    <input type="radio" name="refundMode" checked={excessInfo.mode === "cash"} onChange={() => setRefundChoice("cash")} className="mt-0.5" />
                    <span><b>Cash wapis diya</b> — customer ko paise de diye, hisaab barabar.</span>
                  </label>
                  <label className={`flex items-start gap-2 text-xs cursor-pointer ${excessInfo.canAdvance ? "text-slate-700" : "text-slate-300 cursor-not-allowed"}`}>
                    <input type="radio" name="refundMode" disabled={!excessInfo.canAdvance} checked={excessInfo.mode === "advance"} onChange={() => setRefundChoice("advance")} className="mt-0.5" />
                    <span><b>Customer ke Advance mein jama</b> — agle udaar bill mein khud kat jayega (ya baad mein Refund kar sakte hain).{!excessInfo.canAdvance && " (Is bill par customer nahi hai)"}</span>
                  </label>
                </>
              )}
            </div>
          )}

          {error && <p className="text-xs text-red-500">{error}</p>}
        </div>
        <div className="px-6 py-4 flex gap-3 border-t border-slate-100 flex-shrink-0">
          <button onClick={onClose} className="flex-1 py-2.5 rounded-xl border border-slate-200 text-sm font-semibold text-slate-600 hover:bg-slate-50">Cancel</button>
          <button onClick={mode === "general" ? handleGeneralSubmit : handleInvoiceSubmit} disabled={saving}
            className="flex-1 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-sm font-bold transition-colors">
            {saving ? "Saving..." : "Return Save Karein"}
          </button>
        </div>
      </div>
    </div>
  );
}

export default function OrderReturnsView({ products = [], customers = [], allInvoices = [], returns = [], addReturn, deleteReturn }) {
  const [dateRange, setDateRange] = useState({ from: null, to: null });
  const [search, setSearch] = useState("");
  const [showAdd, setShowAdd] = useState(false);

  const filtered = useMemo(() => {
    return returns
      .filter((r) => !search || r.productName.toLowerCase().includes(search.toLowerCase()))
      .filter((r) => {
        if (!dateRange.from || !dateRange.to) return true;
        const d = r.date.slice(0, 10);
        return d >= dateRange.from && d <= dateRange.to;
      })
      .sort((a, b) => new Date(b.date) - new Date(a.date));
  }, [returns, search, dateRange]);

  const stats = useMemo(() => {
    const now = new Date();
    const todayStr = now.toISOString().slice(0, 10);
    const monthReturns = returns.filter((r) => { const d = new Date(r.date); return d.getFullYear() === now.getFullYear() && d.getMonth() === now.getMonth(); });
    const todayReturns = returns.filter((r) => (r.date || "").slice(0, 10) === todayStr);
    const qtyReturned = returns.reduce((s, r) => s + r.qty, 0);
    const todayAmount = todayReturns.reduce((s, r) => s + (r.amount || 0), 0);
    const monthAmount = monthReturns.reduce((s, r) => s + (r.amount || 0), 0);
    return { totalReturns: returns.length, monthReturns: monthReturns.length, qtyReturned, todayAmount, monthAmount };
  }, [returns]);

  const statsCards = [
    { title: "Total Returns", value: stats.totalReturns, icon: "M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8", light: "bg-blue-50", text: "text-blue-600" },
    { title: "This Month Returns", value: stats.monthReturns, icon: "M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z", light: "bg-violet-50", text: "text-violet-600" },
    { title: "Qty Returned", value: stats.qtyReturned, icon: "M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4", light: "bg-emerald-50", text: "text-emerald-600" },
    { title: "Return Amount Today", value: "Rs " + Number(stats.todayAmount || 0).toLocaleString("en-PK"), icon: "M12 1v22M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6", light: "bg-amber-50", text: "text-amber-600" },
    { title: "Return Amount This Month", value: "Rs " + Number(stats.monthAmount || 0).toLocaleString("en-PK"), icon: "M12 1v22M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6", light: "bg-rose-50", text: "text-rose-600" },
  ];

  return (
    <div className="flex-1 overflow-y-auto scrollbar-hide bg-slate-50/80">
      <div className="px-4 sm:px-6 pt-4 pb-2 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h2 className="text-lg font-black text-slate-800">Order Returns</h2>
          <p className="text-sm text-slate-400 mt-0.5">Wapis aaya hua maal record karein — stock khud badh jayega</p>
        </div>
        <button onClick={() => setShowAdd(true)}
          className="flex items-center gap-2 px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-sm font-bold rounded-xl shadow-md shadow-blue-200 transition-colors self-start sm:self-auto">
          <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M12 5v14M5 12h14" /></svg>
          New Return
        </button>
      </div>

      <div className="px-4 sm:px-6 py-2">
        <StatsGrid cards={statsCards} />
      </div>

      <div className="px-4 sm:px-6 py-3">
        <div className="flex flex-col sm:flex-row items-stretch gap-3">
          <div className="flex-1 flex items-center gap-2 bg-white rounded-xl border border-slate-200 px-3.5 py-2.5">
            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#94A3B8" strokeWidth="2" strokeLinecap="round"><circle cx="11" cy="11" r="8" /><path d="m21 21-4.35-4.35" /></svg>
            <input type="text" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Product naam se search karein..."
              className="flex-1 bg-transparent text-sm outline-none placeholder:text-slate-400" />
          </div>
          <DateRangePicker value={dateRange} onChange={setDateRange} />
        </div>
      </div>

      <div className="px-4 sm:px-6 pb-6">
        {filtered.length === 0 ? (
          <div className="bg-white rounded-2xl border border-slate-100 p-16 text-center">
            <p className="text-slate-500 font-medium">Koi return record nahi mila.</p>
          </div>
        ) : (
          <div className="bg-white rounded-2xl border border-slate-100 overflow-hidden shadow-sm divide-y divide-slate-50">
            {filtered.map((r) => (
              <div key={r.id} className="flex items-center justify-between px-5 py-3.5 hover:bg-slate-50/50">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-blue-50 flex items-center justify-center flex-shrink-0">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#2563eb" strokeWidth="2" strokeLinecap="round"><path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8" /><path d="M3 3v5h5" /></svg>
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-slate-700">{r.productName}</p>
                    <p className="text-xs text-slate-400">
                      {r.reason} · {formatDate(r.date)}{r.note ? ` · ${r.note}` : ""}
                      {r.invoiceId && (
                        <> · Invoice #{r.invoiceNumber}{r.customerName ? ` (${r.customerName})` : ""}{r.deductedFromInvoice ? " — total kam hua" : " — sirf record"}</>
                      )}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-xs font-bold px-2.5 py-1 rounded-lg bg-blue-50 text-blue-600">Qty: {r.qty}</span>
                  {Number(r.amount) > 0 && (
                    <span className="text-xs font-bold px-2.5 py-1 rounded-lg bg-amber-50 text-amber-600">Rs {Number(r.amount).toLocaleString("en-PK")}</span>
                  )}
                  <button onClick={() => deleteReturn(r.id)} title="Delete"
                    className="w-7 h-7 flex items-center justify-center bg-red-50 hover:bg-red-100 text-red-500 rounded-lg transition-colors">
                    <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><polyline points="3 6 5 6 21 6" /><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2" /></svg>
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {showAdd && (
        <AddReturnModal
          products={products}
          customers={customers}
          allInvoices={allInvoices}
          returns={returns}
          onClose={() => setShowAdd(false)}
          onSave={addReturn}
        />
      )}
    </div>
  );
}
