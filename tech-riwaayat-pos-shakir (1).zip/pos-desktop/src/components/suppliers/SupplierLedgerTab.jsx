import { useEffect, useState } from "react";
import { api } from "../../api/client";
import LedgerView from "../ui/LedgerView";

// Backend ki /ledger se entries (debit/credit) leta hai. `refreshKey` badalte
// hi (payment, purchase, return, delete) dobara load hota hai.
export default function SupplierLedgerTab({ supplier, refreshKey, shopName }) {
  const [entries, setEntries] = useState([]);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    let live = true;
    setLoading(true);
    api.get(`/api/suppliers/${supplier.id}/ledger`)
      .then((l) => { if (live) setEntries(l.entries || []); })
      .catch(() => { if (live) setEntries([]); })
      .finally(() => { if (live) setLoading(false); });
    return () => { live = false; };
  }, [supplier.id, refreshKey]);

  return <LedgerView entries={entries} side="credit" party={supplier} partyLabel="Supplier" title="Supplier Ledger Statement" shopName={shopName} loading={loading} />;
}
