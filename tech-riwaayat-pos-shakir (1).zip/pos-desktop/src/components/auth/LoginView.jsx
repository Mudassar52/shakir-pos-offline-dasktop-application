import { useState } from "react";

// ── Shared bits ─────────────────────────────────────────────────────────
const inputBase =
  "w-full px-3 py-2.5 rounded-xl text-sm outline-none transition-all bg-slate-50 border font-medium placeholder-slate-300 text-slate-800 focus:bg-white focus:border-blue-500 focus:ring-2 focus:ring-blue-100";
const labelCls = "block text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-1.5";

function Logo() {
  return (
    <div className="flex items-center gap-2.5 mb-7">
      <img src="./logo.png" alt="Tech Riwaayat POS" className="w-9 h-9 rounded-xl shadow-sm" />
      <span className="font-bold text-slate-800 text-base tracking-tight">Tech Riwaayat POS</span>
    </div>
  );
}

function ErrorBanner({ message }) {
  if (!message) return null;
  return (
    <div className="mb-3 px-3.5 py-2.5 rounded-xl bg-red-50 border border-red-200 flex items-center gap-2">
      <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#ef4444" strokeWidth="2.5" strokeLinecap="round"><circle cx="12" cy="12" r="10" /><line x1="12" y1="8" x2="12" y2="12" /><line x1="12" y1="16" x2="12.01" y2="16" /></svg>
      <p className="text-red-600 text-xs font-medium">{message}</p>
    </div>
  );
}

function PasswordField({ label = "Password", value, onChange, error, onEnter, autoComplete = "current-password" }) {
  const [show, setShow] = useState(false);
  return (
    <div>
      <label className={labelCls}>{label}</label>
      <div className="relative">
        <input
          type={show ? "text" : "password"}
          value={value}
          onChange={onChange}
          autoComplete={autoComplete}
          placeholder="••••••••"
          className={`${inputBase} pr-9 ${error ? "border-red-400 bg-red-50" : "border-slate-200"}`}
          onKeyDown={(e) => e.key === "Enter" && onEnter && onEnter()}
        />
        <button type="button" onClick={() => setShow((s) => !s)} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-300 hover:text-slate-500">
          <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
            {show ? <><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24" /><line x1="1" y1="1" x2="23" y2="23" /></> : <><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" /><circle cx="12" cy="12" r="3" /></>}
          </svg>
        </button>
      </div>
      {error && <p className="text-red-500 text-[10px] mt-1 font-medium">{error}</p>}
    </div>
  );
}

function SubmitButton({ loading, label, loadingLabel = "Please wait..." }) {
  return (
    <button
      type="button"
      disabled={loading}
      className="w-full mt-6 py-2.5 rounded-xl text-white text-sm font-bold tracking-tight transition-all disabled:opacity-60 flex items-center justify-center gap-2"
      style={{ background: "#1D6FDB" }}
      onMouseEnter={(e) => !e.currentTarget.disabled && (e.currentTarget.style.background = "#185FA5")}
      onMouseLeave={(e) => (e.currentTarget.style.background = "#1D6FDB")}
    >
      {loading ? (
        <><svg className="animate-spin" xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M21 12a9 9 0 11-6.219-8.56" /></svg>{loadingLabel}</>
      ) : (
        <>{label} <span className="opacity-70">→</span></>
      )}
    </button>
  );
}

const errorMsg = (err, fallback) => {
  if (err?.code === "auth/invalid-credential") return "Incorrect username or password";
  return err?.message || fallback || "Something went wrong. Please try again.";
};

// ── Main component ──────────────────────────────────────────────────────
export default function LoginView({ onEmailLogin, shopName }) {
  return (
    <div
      className="min-h-screen flex items-center justify-center bg-slate-100 p-4"
      style={{ fontFamily: "'Plus Jakarta Sans', 'DM Sans', 'Segoe UI', sans-serif" }}
    >
      <div className="w-full max-w-[440px] rounded-2xl overflow-hidden shadow-2xl shadow-slate-300/60 border border-slate-200/60 bg-white">
        <div className="p-8">
          <Logo />
          <LoginForm onEmailLogin={onEmailLogin} shopName={shopName} />
        </div>
      </div>
    </div>
  );
}

// ── Login ────────────────────────────────────────────────────────────────
function LoginForm({ onEmailLogin, shopName }) {
  const [form, setForm] = useState({ email: "", password: "" });
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);

  const validate = () => {
    const e = {};
    if (!form.email.trim()) e.email = "Enter your username";
    if (form.password.length < 3) e.password = "Enter your password";
    return e;
  };

  const handleSubmit = async () => {
    const e = validate();
    if (Object.keys(e).length) { setErrors(e); return; }
    setLoading(true);
    setErrors({});
    try {
      await onEmailLogin(form.email.trim(), form.password);
    } catch (err) {
      setErrors({ general: errorMsg(err) });
    } finally {
      setLoading(false);
    }
  };

  const set = (key) => (e) => {
    setForm((f) => ({ ...f, [key]: e.target.value }));
    setErrors((er) => ({ ...er, [key]: "", general: "" }));
  };

  return (
    <>
      <div className="mb-6">
        <h1 className="text-[22px] font-extrabold text-slate-800 tracking-tight leading-none">Welcome back</h1>
        <p className="text-slate-400 text-xs mt-1.5">{shopName ? `${shopName} — ` : ""}Sign in to your account</p>
      </div>

      <ErrorBanner message={errors.general} />

      <div className="space-y-3">
        <div>
          <label className={labelCls}>Username</label>
          <input type="text" autoComplete="username" value={form.email} onChange={set("email")} placeholder="admin"
            className={`${inputBase} ${errors.email ? "border-red-400 bg-red-50" : "border-slate-200"}`} />
          {errors.email && <p className="text-red-500 text-[10px] mt-1 font-medium">{errors.email}</p>}
        </div>
        <PasswordField value={form.password} onChange={set("password")} error={errors.password} onEnter={handleSubmit} />
      </div>

      <div onClick={handleSubmit}>
        <SubmitButton loading={loading} label="Sign In" />
      </div>

      <p className="text-center text-[11px] text-slate-400 mt-5">
        Forgot your password? Contact your service provider — they can set a new one for you.
      </p>
    </>
  );
}
