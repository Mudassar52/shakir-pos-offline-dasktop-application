// Advance balance ka hisaab — ledger ke saath match karta hai.
// Agar bill baad mein kam hua (return / edit) to jitni advance raqam bill se zyada
// thi wo "istemal" nahi maani jati, wapis customer ke advance mein aa jati hai.
const num = (v) => Number(v) || 0;

export function effectiveAdvanceUsed(inv) {
  const pays = Array.isArray(inv.payments) ? inv.payments : [];
  let adv = 0, other = 0;
  for (const p of pays) {
    if (p.note === "Advance Balance Used") adv += num(p.amount);
    else other += num(p.amount);
  }
  if (adv <= 0) return 0;
  const legacyAdvance = pays.length === 0 ? num(inv.advance) : 0;
  return Math.min(adv, Math.max(0, num(inv.total) - other - legacyAdvance));
}

export function advanceBalanceOf(customer, invoices) {
  const given = (customer.adjustments || [])
    .filter((a) => a.type === "advance")
    .reduce((s, a) => s + num(a.amount), 0);
  const refunded = (customer.adjustments || [])
    .filter((a) => a.type === "advance_refund")
    .reduce((s, a) => s + num(a.amount), 0);
  const used = (invoices || []).reduce((s, inv) => s + effectiveAdvanceUsed(inv), 0);
  return { given, used, refunded, balance: Math.max(0, Math.round((given - refunded - used) * 100) / 100) };
}

// Invoice se return karne par: bill kam hone ke baad kitni raqam zyada wasool dikhegi.
//  advanceBack = customer ke advance balance se kata hua hissa jo wapis advance mein jayega
//  realExcess  = asli (cash/payment) paise jo ab bill se zyada hain — cash wapis ya advance mein
export function returnExcess(inv, returnAmount) {
  const pays = Array.isArray(inv.payments) ? inv.payments : [];
  const advUsed = pays.filter((p) => p.note === "Advance Balance Used").reduce((s, p) => s + num(p.amount), 0);
  const paid = pays.reduce((s, p) => s + num(p.amount), 0) + (pays.length === 0 ? num(inv.advance) : 0);
  const over = Math.max(0, paid - Math.max(0, num(inv.total) - num(returnAmount)));
  const advanceBack = Math.min(over, advUsed);
  return { advanceBack, realExcess: Math.max(0, Math.round((over - advanceBack) * 100) / 100), isCashSale: pays.length === 0 };
}
