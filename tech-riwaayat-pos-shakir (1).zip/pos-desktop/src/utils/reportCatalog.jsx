// ── Report Catalog: 46 reports, 7 groups ─────────────────────────────────
// Har report: { id, group, title, desc, filters:[...], build(ctx, f) }
// build() → { columns, rows, summary?, initialSort? } — DataTable seedha render karta hai.
// ctx = { invoices, products, customers, expenses, losses, returns, suppliers,
//         supplierTransactions, supplierPurchases, supplierReturns }
// f   = { from, to, customerId, category, status, source, supplierId, days }
import { getInvoiceDue, getExpiryInfo, getStockStatus } from "./productHelpers";
import { advanceBalanceOf } from "./advance";
import { calcProfit } from "./reportCalculations";
import { buildCustomerLedger, computeLedger, matchesCustomer } from "./ledger";
import StatusPill from "../components/ui/StatusPill";

const rs = (v) => `Rs ${Number(v || 0).toLocaleString("en-PK", { maximumFractionDigits: 2 })}`;
const num = (v) => Number(v || 0).toLocaleString("en-PK", { maximumFractionDigits: 2 });
const pct = (v) => `${Number(v || 0).toFixed(1)}%`;
const day = (d) => String(d || "").slice(0, 10);
const shortDate = (d) => (d ? new Date(d).toLocaleDateString("en-PK", { day: "2-digit", month: "short", year: "numeric" }) : "—");
const daysAgo = (d) => Math.floor((Date.now() - new Date(d).getTime()) / 86400000);
const WEEKDAYS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

export const REPORT_GROUPS = [
  { id: "sales", label: "Sales", icon: "📈" },
  { id: "profit", label: "Profit", icon: "💹" },
  { id: "receivables", label: "Customers & Udaar", icon: "👥" },
  { id: "inventory", label: "Inventory & Expiry", icon: "📦" },
  { id: "purchases", label: "Purchases & Suppliers", icon: "🚚" },
  { id: "returns", label: "Returns & Losses", icon: "↩️" },
  { id: "expenses", label: "Expenses & Cash", icon: "🧾" },
];

// ── column helpers ──
const C = (key, label, o = {}) => ({ key, label, ...o });
const money = (key, label, o = {}) => C(key, label, { align: "right", format: rs, total: "sum", ...o });
const count = (key, label, o = {}) => C(key, label, { align: "right", format: num, total: "sum", ...o });
const date = (key, label, o = {}) => C(key, label, { format: shortDate, ...o });
const S = (label, value, tone = "slate") => ({ label, value, tone });

// ── data helpers ──
function inRange(d, f) {
  if (!f.from && !f.to) return true;
  const x = day(d);
  return (!f.from || x >= f.from) && (!f.to || x <= f.to);
}
function mk(ctx) {
  const productById = new Map(ctx.products.map((p) => [String(p.id), p]));
  const productByName = new Map(ctx.products.map((p) => [p.name, p]));
  const custById = new Map(ctx.customers.map((c) => [String(c.id), c]));
  const supById = new Map(ctx.suppliers.map((s) => [String(s.id), s]));
  const custName = (inv) => (inv.customerId && custById.get(String(inv.customerId))?.name) || inv.customerName || "Walk-in";
  const custKey = (inv) => (inv.customerId ? String(inv.customerId) : `n:${inv.customerName || "walkin"}`);
  const itemCat = (it) => (productById.get(String(it.productId)) || productByName.get(it.name))?.category || "Others";
  const itemCost = (it) => {
    let cp = it.costPrice;
    if (!cp) { const p = productById.get(String(it.productId)) || productByName.get(it.name); cp = p?.costPrice || p?.stockPrice || 0; }
    return (cp || 0) * (it.qty || 0);
  };
  const profit = (inv) => calcProfit(inv, productById, productByName);
  const status = (inv) => { const due = getInvoiceDue(inv); return due <= 0 ? "paid" : due >= (inv.total || 0) ? "udaar" : "partial"; };
  return { productById, productByName, custById, supById, custName, custKey, itemCat, itemCost, profit, status };
}
// Filter lagayi hui invoices (date/customer/status/source/category)
function sales(ctx, f, h) {
  return ctx.invoices.filter((inv) => {
    if (!inRange(inv.createdAt, f)) return false;
    if (f.customerId && !(inv.customerId === f.customerId)) return false;
    if (f.source && (inv.source || "pos") !== f.source) return false;
    if (f.status && h.status(inv) !== f.status) return false;
    if (f.category && !(inv.items || []).some((it) => h.itemCat(it) === f.category)) return false;
    return true;
  });
}
const realSales = (list) => list.filter((i) => !i.isOldUdaar);
function group(list, keyFn) { const m = new Map(); list.forEach((x) => { const k = keyFn(x); if (!m.has(k)) m.set(k, []); m.get(k).push(x); }); return m; }
const sum = (a, fn) => a.reduce((s, x) => s + (Number(fn(x)) || 0), 0);

// invoice-level row (many reports re-use)
function invRow(inv, h) {
  const due = getInvoiceDue(inv);
  return {
    id: inv.id, date: inv.createdAt, no: inv.invoiceNumber ? `#${String(inv.invoiceNumber).padStart(3, "0")}` : "—", customer: h.custName(inv),
    source: inv.isOldUdaar ? "Old Udaar" : (inv.source || "pos") === "manual" ? "Manual" : "POS", items: (inv.items || []).length,
    subtotal: inv.subtotal || inv.total || 0, discount: inv.discount || 0, total: inv.total || 0, paid: (inv.total || 0) - due, due, status: h.status(inv), profit: h.profit(inv),
  };
}
const statusCol = C("status", "Status", { render: (r) => <StatusPill s={r.status} /> });

// per-period aggregation for daily / monthly sales
function periodAgg(list, keyFn, labelFn, h) {
  return [...group(realSales(list), keyFn).entries()].map(([k, arr]) => ({
    key: k, label: labelFn(k), invoices: arr.length, revenue: sum(arr, (i) => i.total), discount: sum(arr, (i) => i.discount),
    paid: sum(arr, (i) => i.total - getInvoiceDue(i)), due: sum(arr, getInvoiceDue), profit: sum(arr, h.profit),
  }));
}
const periodCols = (l) => [C("label", l), count("invoices", "Invoices"), money("revenue", "Sales"), money("discount", "Discount"), money("paid", "Collected"), money("due", "Udaar"), money("profit", "Profit")];
const salesSummary = (rows) => [S("Total Sales", rs(sum(rows, (r) => r.revenue)), "blue"), S("Profit", rs(sum(rows, (r) => r.profit)), "green"), S("Udaar", rs(sum(rows, (r) => r.due)), "red"), S("Invoices", num(sum(rows, (r) => r.invoices)))];

// product-level sales aggregation
function productAgg(list, h, f) {
  const m = new Map();
  realSales(list).forEach((inv) => (inv.items || []).forEach((it) => {
    const cat = h.itemCat(it);
    if (f.category && cat !== f.category) return;
    const k = it.productId ? String(it.productId) : it.name;
    if (!m.has(k)) m.set(k, { name: it.name || "Unknown", category: cat, qty: 0, revenue: 0, cost: 0 });
    const r = m.get(k); r.qty += it.qty || 0; r.revenue += it.lineTotal || 0; r.cost += h.itemCost(it);
  }));
  return [...m.values()].map((r) => ({ ...r, profit: r.revenue - r.cost, margin: r.revenue > 0 ? ((r.revenue - r.cost) / r.revenue) * 100 : 0 }));
}
const productCols = [C("name", "Product"), C("category", "Category"), count("qty", "Qty Sold"), money("revenue", "Revenue"), money("cost", "Cost"), money("profit", "Gross Profit"), C("margin", "Margin", { align: "right", format: pct })];

// supplier balance from ledger txns
function supplierBalances(ctx, f) {
  return ctx.suppliers.filter((s) => !f.supplierId || s.id === f.supplierId).map((s) => {
    let bf = 0, debit = 0, credit = 0;
    ctx.supplierTransactions.filter((t) => t.supplierId === s.id).forEach((t) => {
      const isCr = t.type === "purchase" || t.type === "opening";
      const d = day(t.date);
      if (f.from && d < f.from) { bf += isCr ? t.amount : -t.amount; return; }
      if (f.to && d > f.to) return;
      isCr ? (credit += t.amount) : (debit += t.amount);
    });
    return { id: s.id, name: s.name, phone: s.phone || "", bf, debit, credit, closing: bf + credit - debit };
  });
}
const sumBy = (t, types) => types.includes(t.type) ? t.amount : 0;

export const REPORTS = [
  // ═══════════════ SALES ═══════════════
  { id: "daily-sales", group: "sales", title: "Daily Sales Summary", desc: "Har din ki sales, collection, udaar aur profit", filters: ["date", "customer", "source", "status", "category"],
    build: (ctx, f) => { const h = mk(ctx); const rows = periodAgg(sales(ctx, f, h), (i) => day(i.createdAt), (k) => shortDate(k), h); return { columns: periodCols("Date"), rows, summary: salesSummary(rows), initialSort: { key: "label", dir: "desc" } }; } },
  { id: "monthly-sales", group: "sales", title: "Monthly Sales Summary", desc: "Mahine ke hisaab se sales aur profit", filters: ["date", "customer", "source", "status", "category"],
    build: (ctx, f) => { const h = mk(ctx); const rows = periodAgg(sales(ctx, f, h), (i) => day(i.createdAt).slice(0, 7), (k) => new Date(k + "-01").toLocaleDateString("en-PK", { month: "long", year: "numeric" }), h); return { columns: periodCols("Month"), rows, summary: salesSummary(rows), initialSort: { key: "key", dir: "desc" } }; } },
  { id: "sales-register", group: "sales", title: "Sales Register (Invoice-wise)", desc: "Har invoice ki mukammal detail", filters: ["date", "customer", "source", "status", "category"],
    build: (ctx, f) => { const h = mk(ctx); const rows = sales(ctx, f, h).map((i) => invRow(i, h));
      return { columns: [date("date", "Date"), C("no", "Invoice"), C("customer", "Customer"), C("source", "Source"), count("items", "Items"), money("total", "Total"), money("paid", "Paid"), money("due", "Udaar"), statusCol, money("profit", "Profit", { defaultHidden: true })], rows, initialSort: { key: "date", dir: "desc" },
        summary: [S("Invoices", num(rows.length)), S("Sales", rs(sum(rows, (r) => r.total)), "blue"), S("Collected", rs(sum(rows, (r) => r.paid)), "green"), S("Udaar", rs(sum(rows, (r) => r.due)), "red")] }; } },
  { id: "sales-by-product", group: "sales", title: "Sales by Product", desc: "Konsa product kitna bika", filters: ["date", "customer", "source", "category"],
    build: (ctx, f) => { const h = mk(ctx); const rows = productAgg(sales(ctx, f, h), h, f); return { columns: productCols, rows, initialSort: { key: "revenue", dir: "desc" }, summary: [S("Products Sold", num(rows.length)), S("Units", num(sum(rows, (r) => r.qty))), S("Revenue", rs(sum(rows, (r) => r.revenue)), "blue")] }; } },
  { id: "sales-by-category", group: "sales", title: "Sales by Category", desc: "Category-wise revenue aur profit", filters: ["date", "customer", "source"],
    build: (ctx, f) => { const h = mk(ctx); const m = group(productAgg(sales(ctx, f, h), h, {}), (r) => r.category);
      const rows = [...m.entries()].map(([name, a]) => ({ name, products: a.length, qty: sum(a, (r) => r.qty), revenue: sum(a, (r) => r.revenue), cost: sum(a, (r) => r.cost), profit: sum(a, (r) => r.profit) }));
      return { columns: [C("name", "Category"), count("products", "Products"), count("qty", "Qty"), money("revenue", "Revenue"), money("cost", "Cost"), money("profit", "Profit")], rows, initialSort: { key: "revenue", dir: "desc" } }; } },
  { id: "sales-by-customer", group: "sales", title: "Sales by Customer", desc: "Har customer ki kul khareedari", filters: ["date", "source", "status"],
    build: (ctx, f) => { const h = mk(ctx); const m = group(realSales(sales(ctx, f, h)), h.custKey);
      const rows = [...m.values()].map((a) => ({ name: h.custName(a[0]), invoices: a.length, revenue: sum(a, (i) => i.total), paid: sum(a, (i) => i.total - getInvoiceDue(i)), due: sum(a, getInvoiceDue), last: a.map((i) => i.createdAt).sort().pop() }));
      return { columns: [C("name", "Customer"), count("invoices", "Invoices"), money("revenue", "Total Sales"), money("paid", "Paid"), money("due", "Udaar"), date("last", "Last Purchase")], rows, initialSort: { key: "revenue", dir: "desc" } }; } },
  { id: "sales-by-weekday", group: "sales", title: "Sales by Weekday", desc: "Hafte ka konsa din sab se behtar", filters: ["date", "source"],
    build: (ctx, f) => { const h = mk(ctx); const m = group(realSales(sales(ctx, f, h)), (i) => new Date(i.createdAt).getDay());
      const rows = WEEKDAYS.map((n, d) => { const a = m.get(d) || []; return { name: n, d, invoices: a.length, revenue: sum(a, (i) => i.total), profit: sum(a, h.profit) }; });
      return { columns: [C("name", "Day"), count("invoices", "Invoices"), money("revenue", "Sales"), money("profit", "Profit")], rows, initialSort: { key: "d", dir: "asc" } }; } },
  { id: "sales-by-hour", group: "sales", title: "Sales by Hour", desc: "Din ke kis waqt sab se zyada sale", filters: ["date", "source"],
    build: (ctx, f) => { const h = mk(ctx); const m = group(realSales(sales(ctx, f, h)), (i) => new Date(i.createdAt).getHours());
      const rows = Array.from({ length: 24 }, (_, hr) => { const a = m.get(hr) || []; return { name: `${String(hr).padStart(2, "0")}:00 – ${String(hr).padStart(2, "0")}:59`, hr, invoices: a.length, revenue: sum(a, (i) => i.total) }; }).filter((r) => r.invoices > 0);
      return { columns: [C("name", "Hour"), count("invoices", "Invoices"), money("revenue", "Sales")], rows, initialSort: { key: "hr", dir: "asc" } }; } },
  { id: "sales-by-source", group: "sales", title: "POS vs Manual Invoices", desc: "POS aur manual invoices ka mawazna", filters: ["date", "customer"],
    build: (ctx, f) => { const h = mk(ctx); const m = group(realSales(sales(ctx, f, h)), (i) => ((i.source || "pos") === "manual" ? "Manual Invoice" : "POS Sale"));
      const rows = [...m.entries()].map(([name, a]) => ({ name, invoices: a.length, revenue: sum(a, (i) => i.total), due: sum(a, getInvoiceDue), profit: sum(a, h.profit) }));
      return { columns: [C("name", "Source"), count("invoices", "Invoices"), money("revenue", "Sales"), money("due", "Udaar"), money("profit", "Profit")], rows }; } },
  { id: "discounts", group: "sales", title: "Discounts Given", desc: "Jin invoices par discount diya gaya", filters: ["date", "customer", "source"],
    build: (ctx, f) => { const h = mk(ctx); const rows = realSales(sales(ctx, f, h)).filter((i) => (i.discount || 0) > 0).map((i) => invRow(i, h));
      return { columns: [date("date", "Date"), C("no", "Invoice"), C("customer", "Customer"), money("subtotal", "Subtotal"), money("discount", "Discount"), money("total", "Net Total")], rows, initialSort: { key: "discount", dir: "desc" }, summary: [S("Total Discount", rs(sum(rows, (r) => r.discount)), "amber"), S("Invoices", num(rows.length))] }; } },

  // ═══════════════ PROFIT ═══════════════
  { id: "profit-by-invoice", group: "profit", title: "Profit by Invoice", desc: "Har invoice ka munafa (wasool shuda hissa)", filters: ["date", "customer", "source", "status", "category"],
    build: (ctx, f) => { const h = mk(ctx); const rows = realSales(sales(ctx, f, h)).map((i) => invRow(i, h));
      return { columns: [date("date", "Date"), C("no", "Invoice"), C("customer", "Customer"), money("total", "Sales"), money("profit", "Profit"), C("margin", "Margin", { align: "right", accessor: (r) => (r.total > 0 ? (r.profit / r.total) * 100 : 0), format: pct })], rows, initialSort: { key: "profit", dir: "desc" }, summary: [S("Total Profit", rs(sum(rows, (r) => r.profit)), "green")] }; } },
  { id: "profit-by-product", group: "profit", title: "Profit by Product", desc: "Sab se zyada munafa dene wale products", filters: ["date", "customer", "source", "category"],
    build: (ctx, f) => { const h = mk(ctx); const rows = productAgg(sales(ctx, f, h), h, f); return { columns: productCols, rows, initialSort: { key: "profit", dir: "desc" } }; } },
  { id: "profit-by-customer", group: "profit", title: "Profit by Customer", desc: "Kis customer se kitna munafa", filters: ["date", "source"],
    build: (ctx, f) => { const h = mk(ctx); const m = group(realSales(sales(ctx, f, h)), h.custKey);
      const rows = [...m.values()].map((a) => ({ name: h.custName(a[0]), invoices: a.length, revenue: sum(a, (i) => i.total), profit: sum(a, h.profit) }));
      return { columns: [C("name", "Customer"), count("invoices", "Invoices"), money("revenue", "Sales"), money("profit", "Profit")], rows, initialSort: { key: "profit", dir: "desc" } }; } },
  { id: "profit-loss", group: "profit", title: "Profit & Loss Statement", desc: "Sales − Kharche − Nuqsan = Khalis munafa", filters: ["date"],
    build: (ctx, f) => { const h = mk(ctx); const inv = realSales(sales(ctx, { from: f.from, to: f.to }, h));
      const revenue = sum(inv, (i) => i.total); const gross = sum(inv, h.profit);
      const exp = sum(ctx.expenses.filter((e) => inRange(e.date, f)), (e) => e.amount); const loss = sum(ctx.losses.filter((l) => inRange(l.date, f)), (l) => l.value);
      const net = gross - exp - loss;
      const rows = [{ line: "Total Sales (Revenue)", amount: revenue, kind: "in" }, { line: "Gross Profit (wasool shuda hissa)", amount: gross, kind: "in" }, { line: "Less: Operating Expenses", amount: -exp, kind: "out" }, { line: "Less: Losses (damage / expiry / chori)", amount: -loss, kind: "out" }, { line: "NET PROFIT", amount: net, kind: "net" }];
      return { columns: [C("line", "Particulars", { sortable: false, render: (r) => <span className={r.kind === "net" ? "font-black" : ""}>{r.line}</span> }), C("amount", "Amount", { align: "right", sortable: false, render: (r) => <span className={`font-bold ${r.amount < 0 ? "text-red-600" : r.kind === "net" ? "text-emerald-700 font-black" : ""}`}>{rs(r.amount)}</span>, format: rs })], rows, summary: [S("Net Profit", rs(net), net >= 0 ? "green" : "red"), S("Margin", pct(revenue ? (net / revenue) * 100 : 0))] }; } },
  { id: "low-margin", group: "profit", title: "Low-Margin Products", desc: "Jin ka margin kam hai (threshold: days filter = margin %)", filters: ["category", "days"], daysLabel: "Margin below %", daysDefault: 10,
    build: (ctx, f) => { const th = Number(f.days) || 10; const rows = ctx.products.filter((p) => (!f.category || p.category === f.category) && p.salePrice > 0).map((p) => ({ name: p.name, category: p.category, cost: p.costPrice || p.stockPrice, sale: p.salePrice, margin: p.salePrice ? ((p.salePrice - (p.costPrice || p.stockPrice)) / p.salePrice) * 100 : 0, stock: p.currentStock })).filter((r) => r.margin < th);
      return { columns: [C("name", "Product"), C("category", "Category"), money("cost", "Cost", { total: undefined }), money("sale", "Sale Price", { total: undefined }), C("margin", "Margin", { align: "right", format: pct }), count("stock", "Stock", { total: undefined })], rows, initialSort: { key: "margin", dir: "asc" } }; } },

  // ═══════════════ CUSTOMERS & UDAAR ═══════════════
  { id: "udaar-outstanding", group: "receivables", title: "Outstanding Udaar (Customer-wise)", desc: "Kis se kitna lena hai", filters: ["customer"],
    build: (ctx, f) => { const h = mk(ctx); const open = ctx.invoices.filter((i) => getInvoiceDue(i) > 0 && (!f.customerId || i.customerId === f.customerId));
      const rows = [...group(open, h.custKey).values()].map((a) => { const oldest = a.map((i) => i.createdAt).sort()[0]; return { name: h.custName(a[0]), phone: h.custById.get(String(a[0].customerId))?.phone || "", invoices: a.length, due: sum(a, getInvoiceDue), oldest, age: daysAgo(oldest) }; });
      return { columns: [C("name", "Customer"), C("phone", "Phone"), count("invoices", "Open Invoices"), money("due", "Udaar Due"), date("oldest", "Oldest Since"), C("age", "Age (days)", { align: "right" })], rows, initialSort: { key: "due", dir: "desc" }, summary: [S("Total Receivable", rs(sum(rows, (r) => r.due)), "red"), S("Customers", num(rows.length))] }; } },
  { id: "udaar-aging", group: "receivables", title: "Udaar Aging (0-30 / 31-60 / 61-90 / 90+)", desc: "Purane udhaar ki umar ke hisaab se", filters: ["customer"],
    build: (ctx, f) => { const h = mk(ctx); const open = ctx.invoices.filter((i) => getInvoiceDue(i) > 0 && (!f.customerId || i.customerId === f.customerId));
      const rows = [...group(open, h.custKey).values()].map((a) => { const b = [0, 0, 0, 0]; a.forEach((i) => { const ag = daysAgo(i.createdAt); b[ag <= 30 ? 0 : ag <= 60 ? 1 : ag <= 90 ? 2 : 3] += getInvoiceDue(i); }); return { name: h.custName(a[0]), b0: b[0], b1: b[1], b2: b[2], b3: b[3], total: sum(b, (x) => x) }; });
      return { columns: [C("name", "Customer"), money("b0", "0-30 days"), money("b1", "31-60"), money("b2", "61-90"), money("b3", "90+ days"), money("total", "Total")], rows, initialSort: { key: "total", dir: "desc" } }; } },
  { id: "udaar-invoices", group: "receivables", title: "Open Udaar Invoices", desc: "Jin invoices ka paisa baqi hai", filters: ["date", "customer", "source"],
    build: (ctx, f) => { const h = mk(ctx); const rows = sales(ctx, f, h).filter((i) => getInvoiceDue(i) > 0).map((i) => ({ ...invRow(i, h), age: daysAgo(i.createdAt) }));
      return { columns: [date("date", "Date"), C("no", "Invoice"), C("customer", "Customer"), money("total", "Total"), money("paid", "Paid"), money("due", "Due"), C("age", "Age (days)", { align: "right" }), statusCol], rows, initialSort: { key: "due", dir: "desc" }, summary: [S("Total Due", rs(sum(rows, (r) => r.due)), "red")] }; } },
  { id: "collections", group: "receivables", title: "Payments Received (Collections)", desc: "Udhaar ki wasooli — kab, kis se, kitni", filters: ["date", "customer"],
    build: (ctx, f) => { const h = mk(ctx); const rows = [];
      ctx.invoices.forEach((inv) => { if (f.customerId && inv.customerId !== f.customerId) return; (inv.payments || []).forEach((p, i) => { if (p.note === "Advance Balance Used" || !p.date || !inRange(p.date, f)) return; rows.push({ id: `${inv.id}-${i}`, date: p.date, customer: h.custName(inv), inv: inv.invoiceNumber ? `#${inv.invoiceNumber}` : "Old", amount: p.amount || 0, note: p.note || "Payment" }); }); });
      return { columns: [date("date", "Date"), C("customer", "Customer"), C("inv", "Invoice"), money("amount", "Amount"), C("note", "Note")], rows, initialSort: { key: "date", dir: "desc" }, summary: [S("Total Received", rs(sum(rows, (r) => r.amount)), "green")] }; } },
  { id: "customer-advances", group: "receivables", title: "Customer Advance Balances", desc: "Jin customers ne pehle se paise diye hue hain", filters: ["customer"],
    build: (ctx, f) => { const h = mk(ctx); const rows = ctx.customers.filter((c) => !f.customerId || c.id === f.customerId).map((c) => { const { given, used, refunded, balance } = advanceBalanceOf(c, ctx.invoices.filter((i) => i.customerId === c.id)); return { name: c.name, phone: c.phone || "", given, refunded, used, balance }; }).filter((r) => r.given > 0);
      return { columns: [C("name", "Customer"), C("phone", "Phone"), money("given", "Advance Liya"), money("refunded", "Wapis Kiya"), money("used", "Istemal Hua"), money("balance", "Balance")], rows, initialSort: { key: "balance", dir: "desc" } }; } },
  { id: "old-udaar", group: "receivables", title: "Purana Udhaar Entries", desc: "Software se pehle ka udhaar jo daakhil kiya gaya", filters: ["date", "customer"],
    build: (ctx, f) => { const h = mk(ctx); const rows = ctx.invoices.filter((i) => i.isOldUdaar && inRange(i.createdAt, f) && (!f.customerId || i.customerId === f.customerId)).map((i) => ({ id: i.id, date: i.createdAt, customer: h.custName(i), note: i.note || "Purana Udhaar", total: i.total, due: getInvoiceDue(i) }));
      return { columns: [date("date", "Date"), C("customer", "Customer"), C("note", "Note"), money("total", "Amount"), money("due", "Still Due")], rows, initialSort: { key: "date", dir: "desc" } }; } },
  { id: "customer-ledger-summary", group: "receivables", title: "Customer Ledger Summary", desc: "Har customer: Opening / Billed / Received / Balance", filters: ["date", "customer"],
    build: (ctx, f) => { const rows = ctx.customers.filter((c) => !f.customerId || c.id === f.customerId).map((c) => { const l = computeLedger(buildCustomerLedger(c, ctx.invoices), { from: f.from, to: f.to, side: "debit" }); return { id: c.id, name: c.name, phone: c.phone || "", bf: l.broughtForward, debit: l.totalDebit, credit: l.totalCredit, closing: l.closing }; }).filter((r) => r.bf || r.debit || r.credit);
      return { columns: [C("name", "Customer"), C("phone", "Phone"), money("bf", "Opening (B/F)"), money("debit", "Billed"), money("credit", "Received"), money("closing", "Running Balance")], rows, initialSort: { key: "closing", dir: "desc" }, summary: [S("Total Baaqi (lena hai)", rs(sum(rows, (r) => Math.max(0, r.closing))), "red"), S("Customer Advance (jama)", rs(sum(rows, (r) => Math.max(0, -r.closing))), "amber")] }; } },
  { id: "inactive-customers", group: "receivables", title: "Inactive Customers", desc: "Jinhon ne N din se khareedari nahi ki", filters: ["days"], daysLabel: "Inactive for (days)", daysDefault: 30,
    build: (ctx, f) => { const th = Number(f.days) || 30; const rows = ctx.customers.map((c) => { const mine = ctx.invoices.filter((i) => matchesCustomer(i, c) && !i.isOldUdaar); const last = mine.map((i) => i.createdAt).sort().pop(); return { name: c.name, phone: c.phone || "", city: c.city || "", last, since: last ? daysAgo(last) : null, orders: mine.length, lifetime: sum(mine, (i) => i.total) }; }).filter((r) => r.since === null || r.since >= th);
      return { columns: [C("name", "Customer"), C("phone", "Phone"), C("city", "City"), date("last", "Last Purchase"), C("since", "Days Since", { align: "right", format: (v) => (v === null ? "Never" : v) }), count("orders", "Orders"), money("lifetime", "Lifetime Sales")], rows, initialSort: { key: "since", dir: "desc" } }; } },

  // ═══════════════ INVENTORY & EXPIRY ═══════════════
  { id: "stock-valuation", group: "inventory", title: "Stock Valuation", desc: "Maujooda stock ki cost aur sale value", filters: ["category"],
    build: (ctx, f) => { const rows = ctx.products.filter((p) => !f.category || p.category === f.category).map((p) => { const cost = p.costPrice || p.stockPrice || 0; return { name: p.name, category: p.category, stock: p.currentStock, cost, sale: p.salePrice, costValue: cost * p.currentStock, saleValue: p.salePrice * p.currentStock, potential: (p.salePrice - cost) * p.currentStock }; });
      return { columns: [C("name", "Product"), C("category", "Category"), count("stock", "Stock"), money("cost", "Cost", { total: undefined }), money("sale", "Sale", { total: undefined }), money("costValue", "Value @ Cost"), money("saleValue", "Value @ Sale"), money("potential", "Potential Profit")], rows, initialSort: { key: "costValue", dir: "desc" }, summary: [S("Stock @ Cost", rs(sum(rows, (r) => r.costValue)), "blue"), S("Stock @ Sale", rs(sum(rows, (r) => r.saleValue)), "green"), S("Potential Profit", rs(sum(rows, (r) => r.potential)), "green")] }; } },
  { id: "low-stock", group: "inventory", title: "Low Stock", desc: "Jin ka stock alert level se kam hai", filters: ["category"],
    build: (ctx, f) => { const rows = ctx.products.filter((p) => getStockStatus(p) === "low" && (!f.category || p.category === f.category)).map((p) => ({ name: p.name, category: p.category, stock: p.currentStock, alert: p.lowStockAlertQty, need: Math.max(0, p.lowStockAlertQty * 2 - p.currentStock) }));
      return { columns: [C("name", "Product"), C("category", "Category"), count("stock", "Stock", { total: undefined }), count("alert", "Alert Level", { total: undefined }), count("need", "Suggested Reorder", { total: undefined })], rows, initialSort: { key: "stock", dir: "asc" } }; } },
  { id: "out-of-stock", group: "inventory", title: "Out of Stock", desc: "Jin ka stock khatam hai", filters: ["category"],
    build: (ctx, f) => { const rows = ctx.products.filter((p) => getStockStatus(p) === "out" && (!f.category || p.category === f.category)).map((p) => ({ name: p.name, category: p.category, sale: p.salePrice, cost: p.costPrice }));
      return { columns: [C("name", "Product"), C("category", "Category"), money("sale", "Sale Price", { total: undefined }), money("cost", "Cost", { total: undefined })], rows }; } },
  { id: "expired-stock", group: "inventory", title: "Expired Stock", desc: "Expire ho chuka maal jo abhi stock mein hai", filters: ["category"],
    build: (ctx, f) => { const rows = ctx.products.filter((p) => p.currentStock > 0 && getExpiryInfo(p).status === "expired" && (!f.category || p.category === f.category)).map((p) => ({ name: p.name, category: p.category, batch: p.batchNo || "—", expiry: p.expiryDate, ago: -getExpiryInfo(p).daysLeft, stock: p.currentStock, loss: (p.costPrice || p.stockPrice || 0) * p.currentStock }));
      return { columns: [C("name", "Product"), C("category", "Category"), C("batch", "Batch"), date("expiry", "Expired On"), C("ago", "Days Ago", { align: "right" }), count("stock", "Stock"), money("loss", "Cost at Risk")], rows, initialSort: { key: "ago", dir: "desc" }, summary: [S("Cost at Risk", rs(sum(rows, (r) => r.loss)), "red")] }; } },
  { id: "expiring-soon", group: "inventory", title: "Expiring Soon", desc: "Agle N dinon mein expire hone wala maal", filters: ["category", "days"], daysLabel: "Within (days)", daysDefault: 30,
    build: (ctx, f) => { const th = Number(f.days) || 30; const rows = ctx.products.filter((p) => { const e = getExpiryInfo(p, th); return p.currentStock > 0 && e.status === "soon" && (!f.category || p.category === f.category); }).map((p) => ({ name: p.name, category: p.category, batch: p.batchNo || "—", expiry: p.expiryDate, left: getExpiryInfo(p).daysLeft, stock: p.currentStock, value: (p.costPrice || p.stockPrice || 0) * p.currentStock }));
      return { columns: [C("name", "Product"), C("category", "Category"), C("batch", "Batch"), date("expiry", "Expires On"), C("left", "Days Left", { align: "right" }), count("stock", "Stock"), money("value", "Value @ Cost")], rows, initialSort: { key: "left", dir: "asc" } }; } },
  { id: "dead-stock", group: "inventory", title: "Dead Stock (No Sales)", desc: "Jo N din se bika nahi par stock mein hai", filters: ["category", "days"], daysLabel: "No sale for (days)", daysDefault: 60,
    build: (ctx, f) => { const h = mk(ctx); const th = Number(f.days) || 60; const lastSold = new Map();
      ctx.invoices.forEach((inv) => (inv.items || []).forEach((it) => { const p = h.productById.get(String(it.productId)) || h.productByName.get(it.name); if (!p) return; const cur = lastSold.get(p.id); if (!cur || inv.createdAt > cur) lastSold.set(p.id, inv.createdAt); }));
      const rows = ctx.products.filter((p) => p.currentStock > 0 && (!f.category || p.category === f.category)).map((p) => { const l = lastSold.get(p.id); return { name: p.name, category: p.category, stock: p.currentStock, last: l, since: l ? daysAgo(l) : null, value: (p.costPrice || p.stockPrice || 0) * p.currentStock }; }).filter((r) => r.since === null || r.since >= th);
      return { columns: [C("name", "Product"), C("category", "Category"), count("stock", "Stock"), date("last", "Last Sold"), C("since", "Days Since", { align: "right", format: (v) => (v === null ? "Never" : v) }), money("value", "Capital Blocked")], rows, initialSort: { key: "value", dir: "desc" }, summary: [S("Capital Blocked", rs(sum(rows, (r) => r.value)), "amber")] }; } },
  { id: "fast-moving", group: "inventory", title: "Fast-Moving Products", desc: "Sab se tezi se bikne wala maal aur stock cover", filters: ["date", "category"],
    build: (ctx, f) => { const h = mk(ctx); const list = sales(ctx, f, h); const span = Math.max(1, f.from && f.to ? (new Date(f.to) - new Date(f.from)) / 86400000 + 1 : 30);
      const rows = productAgg(list, h, f).map((r) => { const p = h.productByName.get(r.name); const perDay = r.qty / span; return { name: r.name, category: r.category, qty: r.qty, perDay, stock: p?.currentStock ?? 0, cover: perDay > 0 && p ? (p.currentStock || 0) / perDay : null }; });
      return { columns: [C("name", "Product"), C("category", "Category"), count("qty", "Qty Sold"), C("perDay", "Avg / Day", { align: "right", format: (v) => Number(v).toFixed(1) }), count("stock", "Stock Now", { total: undefined }), C("cover", "Days of Cover", { align: "right", format: (v) => (v === null ? "—" : Math.round(v)) })], rows, initialSort: { key: "qty", dir: "desc" } }; } },
  { id: "stock-by-category", group: "inventory", title: "Stock by Category", desc: "Category-wise stock aur value", filters: [],
    build: (ctx) => { const rows = [...group(ctx.products, (p) => p.category || "Others").entries()].map(([name, a]) => ({ name, products: a.length, units: sum(a, (p) => p.currentStock), value: sum(a, (p) => (p.costPrice || p.stockPrice || 0) * p.currentStock), out: a.filter((p) => getStockStatus(p) === "out").length, low: a.filter((p) => getStockStatus(p) === "low").length }));
      return { columns: [C("name", "Category"), count("products", "Products"), count("units", "Units"), money("value", "Value @ Cost"), count("low", "Low"), count("out", "Out")], rows, initialSort: { key: "value", dir: "desc" } }; } },
  { id: "price-list", group: "inventory", title: "Price List & Margins", desc: "Sab products ki prices aur margin", filters: ["category"],
    build: (ctx, f) => { const rows = ctx.products.filter((p) => !f.category || p.category === f.category).map((p) => { const cost = p.costPrice || p.stockPrice || 0; return { name: p.name, category: p.category, cost, sale: p.salePrice, shop: p.saleShopPrice || 0, margin: p.salePrice ? ((p.salePrice - cost) / p.salePrice) * 100 : 0, ctn: p.ctn || 0 }; });
      return { columns: [C("name", "Product"), C("category", "Category"), money("cost", "Cost", { total: undefined }), money("sale", "Sale", { total: undefined }), money("shop", "Saleshop", { total: undefined, defaultHidden: true }), C("margin", "Margin", { align: "right", format: pct }), count("ctn", "CTN", { total: undefined, defaultHidden: true })], rows, initialSort: { key: "name", dir: "asc" } }; } },

  // ═══════════════ PURCHASES & SUPPLIERS ═══════════════
  { id: "purchase-register", group: "purchases", title: "Purchase Register", desc: "Supplier se hui har khareedari", filters: ["date", "supplier", "status"], needsPurchases: true,
    build: (ctx, f) => { const h = mk(ctx); const rows = ctx.supplierPurchases.filter((p) => inRange(p.date, f) && (!f.supplierId || p.supplierId === f.supplierId) && (!f.status || (f.status === "paid" ? p.remaining <= 0 : p.remaining > 0))).map((p) => ({ id: p.id, date: p.date, no: `#${p.invoiceNumber}`, supplier: h.supById.get(p.supplierId)?.name || "—", items: p.items.map((i) => i.productName).join(", "), total: p.total, paid: p.advance, returned: p.returned || 0, remaining: p.remaining }));
      return { columns: [date("date", "Date"), C("no", "Invoice"), C("supplier", "Supplier"), C("items", "Items", { className: "max-w-xs truncate" }), money("total", "Total"), money("paid", "Paid"), money("returned", "Returned"), money("remaining", "Remaining")], rows, initialSort: { key: "date", dir: "desc" }, summary: [S("Purchases", rs(sum(rows, (r) => r.total)), "blue"), S("Remaining", rs(sum(rows, (r) => r.remaining)), "red")] }; } },
  { id: "purchases-by-supplier", group: "purchases", title: "Purchases by Supplier", desc: "Har supplier se kul khareedari", filters: ["date", "supplier"], needsPurchases: true,
    build: (ctx, f) => { const h = mk(ctx); const list = ctx.supplierPurchases.filter((p) => inRange(p.date, f) && (!f.supplierId || p.supplierId === f.supplierId));
      const rows = [...group(list, (p) => p.supplierId).entries()].map(([sid, a]) => ({ name: h.supById.get(sid)?.name || "—", invoices: a.length, total: sum(a, (p) => p.total), returned: sum(a, (p) => p.returned), remaining: sum(a, (p) => p.remaining) }));
      return { columns: [C("name", "Supplier"), count("invoices", "Invoices"), money("total", "Purchased"), money("returned", "Returned"), money("remaining", "Remaining")], rows, initialSort: { key: "total", dir: "desc" } }; } },
  { id: "purchases-by-product", group: "purchases", title: "Purchases by Product", desc: "Konsa maal kitna khareeda", filters: ["date", "supplier"], needsPurchases: true,
    build: (ctx, f) => { const m = new Map(); ctx.supplierPurchases.filter((p) => inRange(p.date, f) && (!f.supplierId || p.supplierId === f.supplierId)).forEach((p) => p.items.forEach((i) => { const r = m.get(i.productName) || { name: i.productName, qty: 0, total: 0 }; r.qty += i.qty; r.total += i.lineTotal; m.set(i.productName, r); }));
      const rows = [...m.values()].map((r) => ({ ...r, avg: r.qty ? r.total / r.qty : 0 }));
      return { columns: [C("name", "Product"), count("qty", "Qty Bought"), money("total", "Amount"), C("avg", "Avg Rate", { align: "right", format: rs })], rows, initialSort: { key: "total", dir: "desc" } }; } },
  { id: "supplier-payables", group: "purchases", title: "Supplier Payables", desc: "Har supplier ko kitna dena hai", filters: ["supplier"],
    build: (ctx, f) => { const rows = supplierBalances(ctx, { supplierId: f.supplierId }).map((b) => ({ name: b.name, phone: b.phone, credit: b.credit + Math.max(0, b.bf), debit: b.debit, balance: b.closing }));
      return { columns: [C("name", "Supplier"), C("phone", "Phone"), money("credit", "Purchases + Opening"), money("debit", "Paid + Returned"), money("balance", "Payable / (Advance)")], rows, initialSort: { key: "balance", dir: "desc" }, summary: [S("Total Payable", rs(sum(rows, (r) => Math.max(0, r.balance))), "red"), S("Advance with Suppliers", rs(sum(rows, (r) => Math.max(0, -r.balance))), "amber")] }; } },
  { id: "unpaid-purchases", group: "purchases", title: "Unpaid Purchase Invoices", desc: "Jin invoices ki payment baqi hai", filters: ["supplier"], needsPurchases: true,
    build: (ctx, f) => { const h = mk(ctx); const rows = ctx.supplierPurchases.filter((p) => p.remaining > 0 && (!f.supplierId || p.supplierId === f.supplierId)).map((p) => ({ id: p.id, date: p.date, no: `#${p.invoiceNumber}`, supplier: h.supById.get(p.supplierId)?.name || "—", total: p.total, paid: p.advance, remaining: p.remaining, age: daysAgo(p.date) }));
      return { columns: [date("date", "Date"), C("no", "Invoice"), C("supplier", "Supplier"), money("total", "Total"), money("paid", "Paid"), money("remaining", "Remaining"), C("age", "Age (days)", { align: "right" })], rows, initialSort: { key: "remaining", dir: "desc" } }; } },
  { id: "supplier-payments", group: "purchases", title: "Supplier Payments Made", desc: "Suppliers ko di gayi payments", filters: ["date", "supplier"],
    build: (ctx, f) => { const h = mk(ctx); const rows = ctx.supplierTransactions.filter((t) => t.type === "payment" && inRange(t.date, f) && (!f.supplierId || t.supplierId === f.supplierId)).map((t) => ({ id: t.id, date: t.date, supplier: h.supById.get(t.supplierId)?.name || "—", amount: t.amount, note: t.description }));
      return { columns: [date("date", "Date"), C("supplier", "Supplier"), money("amount", "Amount"), C("note", "Note")], rows, initialSort: { key: "date", dir: "desc" }, summary: [S("Total Paid", rs(sum(rows, (r) => r.amount)), "green")] }; } },
  { id: "purchase-returns", group: "purchases", title: "Purchase Returns", desc: "Supplier ko wapis kiya hua maal", filters: ["date", "supplier"],
    build: (ctx, f) => { const h = mk(ctx); const rows = ctx.supplierReturns.filter((r) => inRange(r.date, f) && (!f.supplierId || r.supplierId === f.supplierId)).map((r) => ({ id: r.id, date: r.date, no: `PR-${r.returnNumber}`, invoice: r.invoiceNumber ? `#${r.invoiceNumber}` : "—", supplier: h.supById.get(r.supplierId)?.name || "—", items: r.items.map((i) => `${i.productName} ×${i.qty}`).join(", "), reason: r.reason || "—", total: r.total }));
      return { columns: [date("date", "Date"), C("no", "Return #"), C("invoice", "Invoice"), C("supplier", "Supplier"), C("items", "Items", { className: "max-w-xs truncate" }), C("reason", "Reason"), money("total", "Value")], rows, initialSort: { key: "date", dir: "desc" }, summary: [S("Returned Value", rs(sum(rows, (r) => r.total)), "violet")] }; } },
  { id: "supplier-ledger-summary", group: "purchases", title: "Supplier Ledger Summary", desc: "Har supplier: Opening / Purchased / Paid / Balance", filters: ["date", "supplier"],
    build: (ctx, f) => { const rows = supplierBalances(ctx, f).filter((b) => b.bf || b.debit || b.credit);
      return { columns: [C("name", "Supplier"), C("phone", "Phone"), money("bf", "Opening (B/F)"), money("credit", "Purchased"), money("debit", "Paid / Returned"), money("closing", "Running Balance (dena hai)")], rows, initialSort: { key: "closing", dir: "desc" } }; } },

  // ═══════════════ RETURNS & LOSSES ═══════════════
  { id: "customer-returns", group: "returns", title: "Customer Returns (Order Returns)", desc: "Customers ka wapis kiya hua maal", filters: ["date", "customer"],
    build: (ctx, f) => { const rows = ctx.returns.filter((r) => inRange(r.date, f) && (!f.customerId || r.customerId === f.customerId)).map((r) => ({ id: r.id, date: r.date, product: r.productName, customer: r.customerName || "—", invoice: r.invoiceNumber ? `#${r.invoiceNumber}` : "—", qty: r.qty, amount: r.amount, reason: r.reason || "—" }));
      return { columns: [date("date", "Date"), C("product", "Product"), C("customer", "Customer"), C("invoice", "Invoice"), count("qty", "Qty"), money("amount", "Amount"), C("reason", "Reason")], rows, initialSort: { key: "date", dir: "desc" } }; } },
  { id: "returns-by-reason", group: "returns", title: "Returns by Reason", desc: "Wapsi ki wajohat", filters: ["date"],
    build: (ctx, f) => { const rows = [...group(ctx.returns.filter((r) => inRange(r.date, f)), (r) => r.reason || "Unspecified").entries()].map(([name, a]) => ({ name, count: a.length, qty: sum(a, (r) => r.qty), amount: sum(a, (r) => r.amount) }));
      return { columns: [C("name", "Reason"), count("count", "Returns"), count("qty", "Qty"), money("amount", "Amount")], rows, initialSort: { key: "amount", dir: "desc" } }; } },
  { id: "losses", group: "returns", title: "Loss Register", desc: "Damaged / expired / chori ka hisaab", filters: ["date"],
    build: (ctx, f) => { const rows = ctx.losses.filter((l) => inRange(l.date, f)).map((l) => ({ id: l.id, date: l.date, product: l.productName, qty: l.qty, unit: l.unitCost, value: l.value, reason: l.reason || "—", note: l.note }));
      return { columns: [date("date", "Date"), C("product", "Product"), count("qty", "Qty"), money("unit", "Unit Cost", { total: undefined }), money("value", "Loss Value"), C("reason", "Reason"), C("note", "Note", { defaultHidden: true })], rows, initialSort: { key: "date", dir: "desc" }, summary: [S("Total Loss", rs(sum(rows, (r) => r.value)), "red")] }; } },
  { id: "losses-by-reason", group: "returns", title: "Losses by Reason", desc: "Nuqsan ki wajah ke hisaab se", filters: ["date"],
    build: (ctx, f) => { const rows = [...group(ctx.losses.filter((l) => inRange(l.date, f)), (l) => l.reason || "Unspecified").entries()].map(([name, a]) => ({ name, count: a.length, qty: sum(a, (l) => l.qty), value: sum(a, (l) => l.value) }));
      return { columns: [C("name", "Reason"), count("count", "Entries"), count("qty", "Qty"), money("value", "Loss Value")], rows, initialSort: { key: "value", dir: "desc" } }; } },

  // ═══════════════ EXPENSES & CASH ═══════════════
  { id: "expenses-register", group: "expenses", title: "Expense Register", desc: "Dukaan ke tamam kharche", filters: ["date", "expcat"],
    build: (ctx, f) => { const rows = ctx.expenses.filter((e) => inRange(e.date, f) && (!f.expcat || e.category === f.expcat)).map((e) => ({ id: e.id, date: e.date, category: e.category, description: e.description || "—", amount: e.amount }));
      return { columns: [date("date", "Date"), C("category", "Category"), C("description", "Description"), money("amount", "Amount")], rows, initialSort: { key: "date", dir: "desc" }, summary: [S("Total Expenses", rs(sum(rows, (r) => r.amount)), "amber")] }; } },
  { id: "expenses-by-category", group: "expenses", title: "Expenses by Category", desc: "Category-wise kharche", filters: ["date"],
    build: (ctx, f) => { const list = ctx.expenses.filter((e) => inRange(e.date, f)); const tot = sum(list, (e) => e.amount) || 1;
      const rows = [...group(list, (e) => e.category).entries()].map(([name, a]) => ({ name, count: a.length, amount: sum(a, (e) => e.amount), share: (sum(a, (e) => e.amount) / tot) * 100 }));
      return { columns: [C("name", "Category"), count("count", "Entries"), money("amount", "Amount"), C("share", "Share", { align: "right", format: pct })], rows, initialSort: { key: "amount", dir: "desc" } }; } },
  { id: "expenses-by-month", group: "expenses", title: "Expenses by Month", desc: "Mahana kharche ka rujhan", filters: ["date", "expcat"],
    build: (ctx, f) => { const rows = [...group(ctx.expenses.filter((e) => inRange(e.date, f) && (!f.expcat || e.category === f.expcat)), (e) => day(e.date).slice(0, 7)).entries()].map(([k, a]) => ({ k, name: new Date(k + "-01").toLocaleDateString("en-PK", { month: "long", year: "numeric" }), count: a.length, amount: sum(a, (e) => e.amount) }));
      return { columns: [C("name", "Month"), count("count", "Entries"), money("amount", "Amount")], rows, initialSort: { key: "k", dir: "desc" } }; } },
  { id: "cash-flow", group: "expenses", title: "Monthly Cash Flow", desc: "Aamad (sales/wasooli/advance) vs Kharcha (expenses/supplier payments)", filters: ["date"],
    build: (ctx, f) => { const m = new Map(); const add = (d, k, v) => { if (!inRange(d, f) || !v) return; const key = day(d).slice(0, 7); const r = m.get(key) || { k: key, sales: 0, collections: 0, advances: 0, refunds: 0, expenses: 0, supplier: 0 }; r[k] += v; m.set(key, r); };
      ctx.invoices.forEach((inv) => { if (!inv.isOldUdaar && inv.paymentMode !== "udaar" && inv.paymentStatus === "paid") add(inv.createdAt, "sales", inv.total); (inv.payments || []).forEach((p) => { if (p.note !== "Advance Balance Used") add(p.date || inv.createdAt, "collections", p.amount); }); });
      ctx.invoices.forEach((inv) => Object.values(inv.returnTrace || {}).forEach((t) => { if (t && t.mode === "cash" && t.real > 0) add(t.date, "refunds", Number(t.real)); }));
      ctx.customers.forEach((c) => (c.adjustments || []).forEach((a) => { if (a.type === "advance" && !a.returnId) add(a.date, "advances", Number(a.amount)); else if (a.type === "advance_refund") add(a.date, "refunds", Number(a.amount)); }));
      ctx.expenses.forEach((e) => add(e.date, "expenses", e.amount)); ctx.supplierTransactions.forEach((t) => t.type === "payment" && add(t.date, "supplier", t.amount));
      const rows = [...m.values()].map((r) => ({ ...r, name: new Date(r.k + "-01").toLocaleDateString("en-PK", { month: "long", year: "numeric" }), inflow: r.sales + r.collections + r.advances, outflow: r.expenses + r.supplier + r.refunds })).map((r) => ({ ...r, net: r.inflow - r.outflow }));
      return { columns: [C("name", "Month"), money("sales", "Cash Sales"), money("collections", "Udaar Collected"), money("advances", "Advances"), money("inflow", "Total In"), money("expenses", "Expenses"), money("supplier", "Supplier Paid"), money("refunds", "Refunds Paid"), money("outflow", "Total Out"), money("net", "Net Cash")], rows, initialSort: { key: "k", dir: "desc" }, summary: [S("Total In", rs(sum(rows, (r) => r.inflow)), "green"), S("Total Out", rs(sum(rows, (r) => r.outflow)), "red"), S("Net", rs(sum(rows, (r) => r.net)), "blue")] }; } },
];
