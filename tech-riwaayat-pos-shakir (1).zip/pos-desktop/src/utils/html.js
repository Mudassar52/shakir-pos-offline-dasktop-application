// HTML escaping — print/PDF templates mein user ka likha hua text (naam, address,
// notes) seedha HTML mein jata hai; isko escape kiye bina script chal sakti hai.
export function esc(v) {
  return String(v ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

// Object/array ke saare string fields escape karta hai (numbers/booleans jaise hain).
export function escDeep(v) {
  if (typeof v === "string") return esc(v);
  if (Array.isArray(v)) return v.map(escDeep);
  if (v && typeof v === "object") {
    const out = {};
    for (const k of Object.keys(v)) out[k] = escDeep(v[k]);
    return out;
  }
  return v;
}

// Logo sirf data:image/... ya https hi ho sakta hai.
export function safeImgSrc(src) {
  const s = String(src || "");
  return /^data:image\/(png|jpe?g|gif|webp|svg\+xml);base64,[A-Za-z0-9+/=]+$/.test(s) ? s : "";
}
