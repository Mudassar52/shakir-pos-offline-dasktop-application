import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  base: "./", // Electron loads index.html via file://, so paths must be relative
  plugins: [
    react(),
    {
      // Production build mein Content-Security-Policy (dev mein Vite ko inline script chahiye)
      name: "inject-csp",
      apply: "build",
      transformIndexHtml(html) {
        const csp = "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; font-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'self'";
        return html.replace("<head>", `<head>\n    <meta http-equiv="Content-Security-Policy" content="${csp}" />`);
      },
    },
  ],
  server: {
    port: 5173,
    strictPort: true,
  },
});
