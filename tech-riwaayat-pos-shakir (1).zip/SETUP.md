# Tech Riwaayat POS — License / Rent System (Setup Guide)

| Folder | Kya hai |
|---|---|
| `pos-desktop/` | **Tech Riwaayat POS** — client ko dene wali app (license se locked) |
| `super-admin-desktop/` | **Tech Riwaayat POS Super Admin** — licenses, plans, prices aur payments |
| `supabase/schema.sql` | Supabase database setup (dobara run karna safe hai) |

## Naya kya hai
- Dono app ka naam ab **Tech Riwaayat POS** hai (Super Admin ke naam ke saath "Super Admin").
- Super Admin app ka poora text English mein aur simple font/style; stats aur buttons par icons.
- Super Admin mein "Supabase Connect" screen khatam — URL/key app mein pehle se hai, seedha login aata hai.
- **Plans tab:** har plan ki monthly price set karein.
- **Payments tab:** har renewal ki payment record hoti hai; is mahine / pichle mahine / total revenue dikhta hai.
- License banate aur renew karte waqt plan ki price se amount khud bhar jata hai (aap badal sakte hain, 0 likhein to payment record nahi hoti).
- POS mein **My Profile → Change Password khatam**. Password sirf Super Admin se badalta hai.
- POS mein **live countdown timer**: top bar mein aur My Profile → "My Plan" card mein (Days/Hours/Minutes/Seconds).
- **Cloud Backup** (dukaan ka data Supabase mein): neeche alag section mein poori detail.
- Purana data safe hai: POS purane "Shakir POS" data folder ko hi use karti hai, aur database mein naam khud "Tech Riwaayat POS" ho jata hai (agar aap ne custom naam nahi rakha tha).

## Cloud Backup (dukaan wali POS ka data Supabase mein)
**Zaroori:** `supabase/schema.sql` **dobara run karein** (naye tables aur functions add honge, purana data safe rahega).

**Kaise kaam karta hai**
- POS apni database file ko compress (gzip) karke chhote tukron mein Supabase par upload karti hai. Data sirf usi license ka hota hai — server har baar license key aur registered computer check karta hai, koi doosre client ka backup nahi dekh sakta.
- **Automatic:** app khuli ho to har 24 ghante mein khud backup (Settings → Cloud Backup mein on/off). **Manual:** "Back up now".
- Internet toot jaye to har tukra 3 dafa retry hota hai; poora upload verify hone par hi backup "complete" hota hai. Adhoora upload kabhi restore nahi hota.
- Har license ke sirf naye **N backups** rakhe jate hain (default 5, Super Admin se 1–30). Purane khud delete ho jate hain.
- Limit: ek backup compressed **40 MB** tak (aam dukaan ka data is se bohot chhota hota hai). Supabase free plan mein 500 MB database hai — 20 clients × 5 backups × ~2 MB ≈ 200 MB, yani theek; bare data par paid plan lein.

**Client ke liye (POS → Settings → Cloud Backup)**
- Last backup ka time/size, on/off switch, "Back up now", aur cloud mein maujood backups ki list.
- **Restore:** backup ke saamne "Restore" → `RESTORE` type karke confirm. Pehle mojooda data ki safety copy (`pos-data.before-restore-....db`, app ke data folder mein) ban jati hai, phir data replace hota hai aur app restart hoti hai. Download adhoora ya corrupt (checksum) ho to kuch change nahi hota.
- **"Restore from a file..."** — koi bhi `.db` file (lock screen wala backup ya Super Admin se download kiya hua) restore kar sakte hain.
- **Computer kharab ho gaya:** naye PC par POS install → wahi license key se activate (agar computers ki limit 1 hai to Super Admin → Computers → purana PC Remove) → Settings → Cloud Backup → Restore.

**Super Admin (aap ke liye)**
- Plans tab: har plan mein "Include cloud backup" (plan ke hisab se feature + paise).
- License → **Cloud backup** section: is client ke liye on/off, kitne backups rakhne hain, saare backups (size, tareekh, kaunsa PC), **Download** (.db file, checksum verify ke saath) aur **Delete**.
- Licenses table mein "Cloud backup" column: last backup kab hua. Jis client ka backup kai din se nahi hua use aap pehchan sakte hain.
- License blocked/expired ho to us ka backup upload/restore band ho jata hai.

## Setup — ek dafa

### 1. Supabase
1. SQL Editor → `supabase/schema.sql` ka **poora** content paste → Run.
   (Agar pehle run kar chuke hain to bhi dobara run karein — isse Plans/Payments tables add ho jayenge, purana data safe rahega.)
2. Authentication → Users → Add user (apna email + password, Auto Confirm ON).
3. SQL Editor mein (apna email likh kar):
   ```sql
   insert into public.super_admins (user_id)
   select id from auth.users where email = 'YOUR-EMAIL@example.com';
   ```
   (Agar pehle kar chuke hain to dobara karne ki zaroorat nahi.)
4. Authentication → Sign In / Providers → "Allow new users to sign up" OFF.

### 2. Super Admin app
```bash
cd super-admin-desktop
npm install
npm run dev          # test
npm run dist:win     # installer (release/ folder)
```
Login ke baad pehle **Plans** tab mein apne plans ki price set karein (Basic / Standard / Premium pehle se bane hain, price 0 hai).

### 3. POS app
`pos-desktop/electron/licenseConfig.js` mein sirf `SUPPORT_CONTACT` mein apna phone likhein (URL, key, secret bhare hue hain).
```bash
cd pos-desktop
npm install
npm run dist:win
```
Development test (license bypass, sirf `npm run dev` par): `POS_SKIP_LICENSE=1 npm run dev`

## Roz ka kaam
- **Naya client:** Licenses → New License → plan chunein (price khud aayegi) → amount → Create → "Copy message" → client ko bhej dein.
- **Rent aaya:** client kholein → **Renew & record payment** → muddat aur amount → done. Payment "Payments" tab mein chali jati hai.
- **Rent nahi aaya:** expiry guzarne dein ya **Block** karein. Timer zero hone par app khud lock ho jati hai (client backup le sakta hai).
- **Password bhool gaya:** client → "Login & password" → New password → "Set password & copy message".
- **PC change:** client → Computers → purana Remove → naye PC par wahi key.

## Agar Super Admin ka data Supabase mein save na ho (network masla)
Super Admin app ab khud batati hai ke masla kya hai:
- Upar **"Connected to Supabase"** (hara) ya **"No connection"** (laal) dikhta hai. Laal ho to koi bhi naya license/renew/edit **save nahi hoga** — app bhejti hi nahi aur saaf error deti hai, "Saved" jhoot nahi dikhati.
- Har save ke baad app database se **wapis confirm** karti hai ke change sach mein store hua. Confirm na ho to laal error aata hai (8 second tak screen par rehta hai).
- Internet kamzor ho to request 20 second baad khud ruk jati hai (latakti nahi). Parhne wali requests khud 3 dafa retry hoti hain; likhne wali retry **nahi** hoti taake ek license do dafa na ban jaye.
- Load fail ho to pichla data screen par rehta hai (list khaali nahi hoti), aur internet wapis aate hi data khud refresh ho jata hai (waise bhi har 1 minute baad).
- Form (New License / Renew) network error par band nahi hota — data bhara rehta hai, internet theek hone par dobara button dabayein.

Agar phir bhi hamesha "No connection" aaye:
1. Browser mein `https://mymorgvlnkggjnuhtjra.supabase.co/auth/v1/health` kholein. Na khule to ISP/DNS masla hai.
2. Windows mein DNS badlein: **1.1.1.1** aur **8.8.8.8** (Network settings → IPv4 → DNS), ya mobile hotspot / Cloudflare WARP / VPN try karein.
3. Supabase Dashboard mein dekhein ke project **paused** to nahi (free plan par 1 hafte inactive rehne par pause ho jata hai) — "Restore project" dabayein.
4. Login par "database is not set up" aaye to `schema.sql` dobara run karein.

## Icons (aap khud badlenge) — kahan aur kaunsa size
| App | File | Kaam |
|---|---|---|
| POS | `pos-desktop/build/icon.png` | Installer + app icon (**1024×1024 PNG**, square) |
| POS | `pos-desktop/public/logo.png` | App ke andar (login, sidebar) logo (512×512 PNG) |
| Super Admin | `super-admin-desktop/build/icon.png` | Installer + app icon (**1024×1024 PNG**) |
| Super Admin | `super-admin-desktop/public/logo.png` | App ke andar logo (512×512 PNG) |

Bas same naam se file replace karein, phir dobara `npm run dist:win` chalayein. Windows ke liye behtar hai ke `build/` mein `icon.ico` (256×256 multi-size) bhi rakhein aur `package.json` ke `"win": { "icon": ... }` mein `build/icon.ico` likh dein.

## Security ke baare mein
- Desktop app mein 100% protection mumkin nahi; yeh system aam clients ko rokne ke liye kaafi hai, asal control server-side check se aata hai.
- `LICENSE_SECRET` baad mein na badlein. Installer ko sirf clients ko dein, source code nahi.
- Rent ka written agreement alag se likh lein.
