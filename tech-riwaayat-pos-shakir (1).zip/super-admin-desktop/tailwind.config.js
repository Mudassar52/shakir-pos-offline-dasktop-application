/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: { extend: {
      fontFamily: {
        sans: ['"Inter Variable"', "Inter", "system-ui", "-apple-system", '"Segoe UI"', "Roboto", "Arial", '"Noto Nastaliq Urdu"', "sans-serif"],
      },
    } },
  plugins: [],
};
