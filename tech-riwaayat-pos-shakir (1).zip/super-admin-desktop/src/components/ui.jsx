import { Icon } from "./icons";

export const inputCls =
  "w-full px-3 py-2 rounded-lg text-sm bg-white border border-slate-300 text-slate-800 placeholder-slate-400 outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500";

export function Field({ label, hint, children }) {
  return (
    <label className="block">
      <span className="block text-sm text-slate-600 mb-1">{label}</span>
      {children}
      {hint && <span className="block text-xs text-slate-400 mt-1">{hint}</span>}
    </label>
  );
}

const BTN = {
  primary: "bg-blue-600 hover:bg-blue-700 text-white",
  soft: "bg-white hover:bg-slate-50 text-slate-700 border border-slate-300",
  danger: "bg-white hover:bg-red-50 text-red-600 border border-red-200",
  ok: "bg-emerald-600 hover:bg-emerald-700 text-white",
  warn: "bg-white hover:bg-amber-50 text-amber-700 border border-amber-300",
};
export function Btn({ kind = "soft", icon, className = "", children, ...p }) {
  return (
    <button {...p} className={`inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed ${BTN[kind]} ${className}`}>
      {icon && <Icon name={icon} size={15} />}
      {children}
    </button>
  );
}

const BADGE = {
  active: ["Active", "bg-emerald-50 text-emerald-700 border-emerald-200"],
  expiring: ["Expiring soon", "bg-amber-50 text-amber-700 border-amber-200"],
  expired: ["Expired", "bg-red-50 text-red-600 border-red-200"],
  blocked: ["Blocked", "bg-slate-700 text-white border-slate-700"],
};
export function Badge({ status }) {
  const [t, c] = BADGE[status] || BADGE.active;
  return <span className={`inline-block px-2 py-0.5 rounded-full text-xs font-medium border ${c}`}>{t}</span>;
}

export function Spinner() {
  return <div className="w-5 h-5 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />;
}

export function Section({ title, icon, children }) {
  return (
    <section className="py-4 border-b border-slate-100">
      <h3 className="flex items-center gap-2 text-sm font-semibold text-slate-800 mb-3">
        {icon && <Icon name={icon} size={15} className="text-slate-400" />}
        {title}
      </h3>
      {children}
    </section>
  );
}

export function Modal({ title, onClose, children, wide }) {
  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-slate-900/50 p-4" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className={`bg-white rounded-xl shadow-2xl w-full ${wide ? "max-w-2xl" : "max-w-lg"} max-h-[92vh] overflow-y-auto`}>
        <div className="flex items-center justify-between px-6 pt-5 pb-3">
          <h2 className="text-lg font-semibold text-slate-800">{title}</h2>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-700"><Icon name="x" size={20} /></button>
        </div>
        <div className="px-6 pb-6">{children}</div>
      </div>
    </div>
  );
}

export const ErrorBox = ({ message }) =>
  message ? <p className="mb-3 px-3 py-2 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">{message}</p> : null;
