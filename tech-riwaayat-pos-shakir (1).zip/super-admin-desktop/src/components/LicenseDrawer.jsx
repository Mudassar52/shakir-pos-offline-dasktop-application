import { useEffect, useState } from "react";
import { updateRow, deleteRow } from "../lib/db";
import { downloadBackup, fmtSize } from "../lib/backup";
import { statusOf, fmtDate, daysLeft, ago, genPassword, genKey, clientMessage, copy, money } from "../lib/util";
import { getClient } from "../lib/supabase";
import { Badge, Btn, Field, Section, inputCls } from "./ui";
import { Icon } from "./icons";
import RenewModal from "./RenewModal";

export default function LicenseDrawer({ license: l, plans, payments, backups = [], onClose, onChanged, flash }) {
  const [busy, setBusy] = useState(false);
  const [f, setF] = useState({});
  const [newPw, setNewPw] = useState("");
  const [customDate, setCustomDate] = useState("");
  const [renewing, setRenewing] = useState(false);
  const [dl, setDl] = useState(null); // { id, pct }
  const [oldKeys, setOldKeys] = useState([]);
  useEffect(() => {
    let live = true;
    getClient().from("license_key_history").select("old_key, replaced_at").eq("license_id", l.id).order("replaced_at", { ascending: false })
      .then(({ data }) => live && setOldKeys(data || []));
    return () => { live = false; };
  }, [l.id, l.license_key]);

  const changeKey = async () => {
    if (!confirm(`Issue a NEW license key for "${l.shop_name}"?\nThe old key will stop working immediately. You must give the new key to the client.`)) return;
    for (let i = 0; i < 3; i++) {
      const key = genKey();
      setBusy(true);
      try {
        await updateRow("licenses", l.id, { license_key: key });
        await copy(clientMessage({ ...l, license_key: key }).replace(/^Username:.*\n/m, "").replace("is ready for", "has a NEW license key for"));
        flash(`New key ${key} — message copied`);
        onChanged();
        setBusy(false);
        return;
      } catch (e) {
        if (e.code !== "23505" || i === 2) { flash("Error: " + e.message); setBusy(false); return; }
      }
    }
  };
  const status = statusOf(l);

  useEffect(() => {
    setF({
      plan: l.plan, price: l.price, max_devices: l.max_devices, offline_grace_days: l.offline_grace_days,
      backup_enabled: l.backup_enabled, backup_keep: l.backup_keep,
      admin_username: l.admin_username, notice: l.notice || "", notes: l.notes || "",
    });
  }, [l.id, l.plan, l.price, l.max_devices, l.offline_grace_days, l.admin_username, l.notice, l.notes, l.backup_enabled, l.backup_keep]);
  const set = (k) => (e) => setF((s) => ({ ...s, [k]: e.target.value }));

  const patch = async (fields, okMsg) => {
    setBusy(true);
    try {
      await updateRow("licenses", l.id, fields);
      flash(okMsg || "Saved");
      onChanged();
      return true;
    } catch (e) {
      flash("Error: " + e.message);
      return false;
    } finally {
      setBusy(false);
    }
  };

  const setDate = () => {
    if (!customDate) return;
    patch({ expires_at: new Date(customDate + "T23:59:59").toISOString() }, "Expiry date updated");
  };
  const toggleBlock = () =>
    patch({ status: l.status === "blocked" ? "active" : "blocked" }, l.status === "blocked" ? "License unblocked" : "License blocked");

  const pickPlan = (e) => {
    const p = plans.find((x) => x.name === e.target.value);
    setF((s) => ({ ...s, plan: e.target.value, price: p ? p.price : s.price, max_devices: p ? p.max_devices : s.max_devices, backup_enabled: p ? p.backup_enabled : s.backup_enabled }));
  };

  const savePassword = async () => {
    if (newPw.length < 6) return flash("Password must be at least 6 characters");
    const username = f.admin_username.trim() || l.admin_username;
    const ok = await patch({ admin_username: username, pending_password: newPw }, "New password set — it applies the next time the client's app checks in");
    if (!ok) return;
    await copy(clientMessage({ ...l, admin_username: username }, newPw));
    flash("Password set and message copied");
    setNewPw("");
  };

  const saveBackupSettings = () =>
    patch({ backup_enabled: !!f.backup_enabled, backup_keep: Math.min(30, Math.max(1, +f.backup_keep || 5)) }, "Cloud backup settings saved");

  const download = async (b) => {
    setDl({ id: b.id, pct: 0 });
    try {
      const name = await downloadBackup(b, l.shop_name, (pct) => setDl({ id: b.id, pct }));
      flash(`Saved ${name}`);
    } catch (e) {
      flash("Error: " + e.message);
    } finally {
      setDl(null);
    }
  };
  const removeBackup = async (b) => {
    if (!confirm(`Delete the backup from ${fmtDate(b.created_at)}? This cannot be undone.`)) return;
    try {
      await deleteRow("cloud_backups", b.id);
      flash("Backup deleted");
      onChanged();
    } catch (e) {
      flash("Error: " + e.message);
    }
  };

  const removeDevice = async (d) => {
    if (!confirm(`Remove "${d.machine_name || d.machine_id.slice(0, 8)}"? The app on that computer will be locked.`)) return;
    try {
      await deleteRow("license_devices", d.id);
      flash("Computer removed");
      onChanged();
    } catch (e) {
      flash("Error: " + e.message);
    }
  };

  const del = async () => {
    if (!confirm(`Permanently delete the license for "${l.shop_name}"?\nThe client keeps their data on their computer, but the app will be locked. Payment history is kept.`)) return;
    try {
      await deleteRow("licenses", l.id);
      flash("License deleted");
      onChanged();
      onClose();
    } catch (e) {
      flash("Error: " + e.message);
    }
  };

  const d = daysLeft(l.expires_at);
  const planOptions = plans.some((p) => p.name === l.plan) ? plans : [{ id: "cur", name: l.plan, price: l.price }, ...plans];
  const totalPaid = payments.reduce((a, p) => a + Number(p.amount), 0);
  const backupBytes = backups.reduce((a, b) => a + Number(b.size_bytes), 0);

  return (
    <div className="fixed inset-0 z-30 flex justify-end bg-slate-900/40" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <aside className="w-full max-w-[500px] bg-white h-full overflow-y-auto shadow-2xl px-6 pb-8">
        <div className="sticky top-0 bg-white pt-5 pb-3 border-b border-slate-200 z-10">
          <div className="flex items-start justify-between">
            <div>
              <h2 className="text-lg font-semibold text-slate-800">{l.shop_name}</h2>
              <p className="text-sm text-slate-500">{[l.owner_name, l.phone].filter(Boolean).join(" • ") || "No contact details"}</p>
            </div>
            <button onClick={onClose} className="text-slate-400 hover:text-slate-700"><Icon name="x" size={20} /></button>
          </div>
          <div className="flex items-center gap-3 mt-3">
            <Badge status={status} />
            <button onClick={() => copy(l.license_key).then(() => flash("License key copied"))} className="inline-flex items-center gap-1.5 font-mono text-xs text-slate-600 hover:text-blue-600">
              {l.license_key} <Icon name="copy" size={12} />
            </button>
          </div>
        </div>

        <Section title="Subscription" icon="calendar">
          <p className="text-sm text-slate-700 mb-3">
            Expires <b>{fmtDate(l.expires_at)}</b>{" "}
            <span className={d < 0 ? "text-red-500" : d <= 7 ? "text-amber-600" : "text-slate-500"}>
              ({d < 0 ? `expired ${-d} day${d === -1 ? "" : "s"} ago` : `${d} day${d === 1 ? "" : "s"} left`})
            </span>
          </p>
          <Btn kind="ok" icon="wallet" onClick={() => setRenewing(true)}>Renew & record payment</Btn>
          <div className="flex gap-2 mt-3">
            <input type="date" className={inputCls} value={customDate} onChange={(e) => setCustomDate(e.target.value)} />
            <Btn disabled={busy || !customDate} onClick={setDate}>Set date</Btn>
          </div>
          <p className="text-xs text-slate-400 mt-1.5">“Set date” changes the expiry without recording a payment.</p>
        </Section>

        <Section title="License key" icon="key">
          <p className="font-mono text-sm text-slate-700">{l.license_key}</p>
          <div className="flex gap-2 mt-3">
            <Btn icon="copy" onClick={() => copy(l.license_key).then(() => flash("License key copied"))}>Copy key</Btn>
            <Btn kind="warn" icon="key" disabled={busy} onClick={changeKey}>Issue new key</Btn>
          </div>
          <p className="text-xs text-slate-400 mt-2">Issuing a new key stops the old one. The client's app asks for the new key (their data and computers stay registered).</p>
          {oldKeys.length > 0 && (
            <div className="mt-3 space-y-1">
              <p className="text-xs font-semibold text-slate-500">Old keys (no longer work)</p>
              {oldKeys.slice(0, 5).map((k) => (
                <p key={k.old_key} className="text-xs text-slate-400 font-mono line-through">{k.old_key} <span className="no-underline font-sans">· replaced {fmtDate(k.replaced_at)}</span></p>
              ))}
            </div>
          )}
        </Section>

        <Section title="Access" icon="shield">
          <Btn kind={l.status === "blocked" ? "ok" : "danger"} icon={l.status === "blocked" ? "check" : "ban"} disabled={busy} onClick={toggleBlock}>
            {l.status === "blocked" ? "Unblock license" : "Block license"}
          </Btn>
          <p className="text-xs text-slate-400 mt-2">When a license is blocked or expired the client's app locks, but they can still back up their data.</p>
        </Section>

        <Section title="Plan & limits" icon="tag">
          <div className="grid grid-cols-2 gap-3">
            <Field label="Plan">
              <select className={inputCls} value={f.plan || ""} onChange={pickPlan}>{planOptions.map((p) => <option key={p.id} value={p.name}>{p.name}</option>)}</select>
            </Field>
            <Field label="Price / month (Rs)"><input type="number" min="0" className={inputCls} value={f.price ?? ""} onChange={set("price")} /></Field>
            <Field label="Computers"><input type="number" min="1" className={inputCls} value={f.max_devices ?? ""} onChange={set("max_devices")} /></Field>
            <Field label="Offline days"><input type="number" min="0" className={inputCls} value={f.offline_grace_days ?? ""} onChange={set("offline_grace_days")} /></Field>
          </div>
          <Btn className="mt-3" icon="check" disabled={busy} onClick={() => patch({
            plan: f.plan, price: Number(f.price) || 0, max_devices: Math.max(1, +f.max_devices || 1), offline_grace_days: Math.max(0, +f.offline_grace_days || 0), backup_enabled: !!f.backup_enabled,
          })}>Save</Btn>
        </Section>

        <Section title={`Payments (${payments.length}) — total ${money(totalPaid)}`} icon="receipt">
          {payments.length === 0 && <p className="text-sm text-slate-400">No payments recorded yet.</p>}
          <div className="space-y-1.5">
            {payments.slice(0, 8).map((p) => (
              <div key={p.id} className="flex items-center justify-between text-sm bg-slate-50 rounded-lg px-3 py-2">
                <span className="text-slate-600">{fmtDate(p.paid_at)}{p.months ? ` • ${p.months} mo` : ""}{p.note ? ` • ${p.note}` : ""}</span>
                <span className="font-medium text-emerald-700">{money(p.amount)}</span>
              </div>
            ))}
          </div>
        </Section>

        <Section title={`Cloud backup — ${backups.length} stored (${fmtSize(backupBytes)})`} icon="cloud">
          <div className="grid grid-cols-2 gap-3 items-end">
            <label className="flex items-center gap-2.5 text-sm text-slate-700 cursor-pointer pb-2">
              <input type="checkbox" checked={!!f.backup_enabled} onChange={(e) => setF((s) => ({ ...s, backup_enabled: e.target.checked }))} className="w-4 h-4" />
              Enabled for this client
            </label>
            <Field label="Backups to keep"><input type="number" min="1" max="30" className={inputCls} value={f.backup_keep ?? ""} onChange={set("backup_keep")} /></Field>
          </div>
          <Btn className="mt-3" icon="check" disabled={busy} onClick={saveBackupSettings}>Save</Btn>
          <div className="space-y-1.5 mt-4">
            {backups.length === 0 && <p className="text-sm text-slate-400">No backups uploaded yet.</p>}
            {backups.slice(0, 10).map((b) => (
              <div key={b.id} className="flex items-center justify-between gap-2 bg-slate-50 rounded-lg px-3 py-2">
                <div className="min-w-0">
                  <p className="text-sm text-slate-700">{fmtDate(b.created_at)} <span className="text-xs text-slate-400">{new Date(b.created_at).toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" })}</span></p>
                  <p className="text-xs text-slate-500 truncate">{fmtSize(b.size_bytes)}{b.machine_name ? ` • ${b.machine_name}` : ""}</p>
                </div>
                <div className="flex gap-1.5 shrink-0">
                  <Btn icon="download" disabled={!!dl} onClick={() => download(b)}>{dl?.id === b.id ? `${dl.pct}%` : "Download"}</Btn>
                  <Btn kind="danger" icon="trash" disabled={!!dl} onClick={() => removeBackup(b)} aria-label="Delete backup" />
                </div>
              </div>
            ))}
          </div>
          <p className="text-xs text-slate-400 mt-2">The client restores from inside their app (Settings → Cloud Backup). A downloaded .db file can also be restored there with “Restore from a file”.</p>
        </Section>

        <Section title="Login & password" icon="key">
          <Field label="Username"><input className={inputCls} value={f.admin_username || ""} onChange={set("admin_username")} /></Field>
          <div className="mt-3">
            <Field label="New password" hint="Use this when the client forgets their password. The app applies it the next time it checks the license.">
              <div className="flex gap-2">
                <input className={`${inputCls} font-mono`} value={newPw} onChange={(e) => setNewPw(e.target.value)} placeholder="At least 6 characters" />
                <Btn onClick={() => setNewPw(genPassword())}>Generate</Btn>
              </div>
            </Field>
          </div>
          <div className="flex items-center gap-3 mt-3">
            <Btn kind="primary" icon="copy" disabled={busy || newPw.length < 6} onClick={savePassword}>Set password & copy message</Btn>
            {l.pending_password && <span className="text-xs text-amber-600">Pending — not applied by the client yet</span>}
          </div>
          {l.pending_password && (
            <button onClick={() => patch({ pending_password: null }, "Pending password cancelled")} className="mt-2 text-xs text-slate-500 hover:text-red-500">Cancel pending password</button>
          )}
        </Section>

        <Section title="Message to client" icon="bell">
          <input className={inputCls} value={f.notice || ""} onChange={set("notice")} placeholder="e.g. Please pay this month's fee by the 5th" />
          <div className="flex gap-2 mt-3">
            <Btn icon="check" disabled={busy} onClick={() => patch({ notice: f.notice.trim() || null }, "Message saved")}>Save</Btn>
            {l.notice && <Btn kind="warn" disabled={busy} onClick={() => patch({ notice: null }, "Message removed")}>Remove</Btn>}
          </div>
          <p className="text-xs text-slate-400 mt-2">Shown as a banner at the top of the client's app.</p>
        </Section>

        <Section title={`Computers (${(l.license_devices || []).length}/${l.max_devices})`} icon="monitor">
          {(l.license_devices || []).length === 0 && <p className="text-sm text-slate-400">Not activated on any computer yet.</p>}
          <div className="space-y-2">
            {(l.license_devices || []).map((dv) => (
              <div key={dv.id} className="flex items-center justify-between bg-slate-50 rounded-lg px-3 py-2.5">
                <div>
                  <p className="text-sm font-medium text-slate-700">{dv.machine_name || "Unknown PC"}</p>
                  <p className="text-xs text-slate-500 font-mono">ID {dv.machine_id.slice(0, 8).toUpperCase()} • v{dv.app_version || "?"} • {ago(dv.last_seen)}</p>
                </div>
                <Btn kind="danger" icon="trash" onClick={() => removeDevice(dv)}>Remove</Btn>
              </div>
            ))}
          </div>
        </Section>

        <Section title="Private notes" icon="note">
          <textarea rows={3} className={inputCls} value={f.notes || ""} onChange={set("notes")} placeholder="Only you can see this" />
          <Btn className="mt-3" icon="check" disabled={busy} onClick={() => patch({ notes: f.notes.trim() || null }, "Notes saved")}>Save</Btn>
        </Section>

        <div className="pt-5 flex items-center justify-between">
          <Btn icon="copy" onClick={async () => { await copy(clientMessage(l)); flash("Message copied"); }}>Copy client message</Btn>
          <Btn kind="danger" icon="trash" onClick={del}>Delete license</Btn>
        </div>
        <p className="text-xs text-slate-300 mt-4">Created {fmtDate(l.created_at)}</p>
      </aside>
      {renewing && <RenewModal license={l} onClose={() => setRenewing(false)} onDone={(m) => { flash(m); onChanged(); }} />}
    </div>
  );
}
