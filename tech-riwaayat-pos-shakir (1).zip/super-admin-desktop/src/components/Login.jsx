import { useState } from "react";
import { getClient } from "../lib/supabase";
import { Field, ErrorBox, inputCls } from "./ui";
import { Icon } from "./icons";

export default function Login({ onLoggedIn }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  const go = async () => {
    if (!email.trim() || !password) return setErr("Enter your email and password.");
    setBusy(true); setErr("");
    try {
      const sb = getClient();
      const { error } = await sb.auth.signInWithPassword({ email: email.trim(), password });
      if (error) throw new Error(error.message === "Invalid login credentials" ? "Incorrect email or password." : error.message);
      const { data: ok, error: e2 } = await sb.rpc("is_super_admin");
      if (e2) throw new Error("The database is not set up yet. Run schema.sql in Supabase first. (" + e2.message + ")");
      if (!ok) {
        await sb.auth.signOut();
        throw new Error("This account is not a Super Admin. Run the insert line at the end of schema.sql for your email.");
      }
      onLoggedIn();
    } catch (e) {
      setErr(e.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="min-h-full flex items-center justify-center p-4">
      <div className="w-full max-w-[400px] bg-white rounded-xl shadow-lg border border-slate-200 p-8">
        <div className="flex items-center gap-3 mb-6">
          <img src="./logo.png" alt="" className="w-10 h-10 rounded-lg" />
          <div>
            <p className="font-semibold text-slate-800 leading-tight">Tech Riwaayat POS</p>
            <p className="text-xs text-slate-500 leading-tight">Super Admin</p>
          </div>
        </div>
        <h1 className="text-xl font-semibold text-slate-800">Sign in</h1>
        <p className="text-sm text-slate-500 mt-1 mb-5">Use your Super Admin email and password.</p>
        <ErrorBox message={err} />
        <div className="space-y-3">
          <Field label="Email"><input className={inputCls} type="email" value={email} onChange={(e) => setEmail(e.target.value)} autoFocus /></Field>
          <Field label="Password"><input className={inputCls} type="password" value={password} onChange={(e) => setPassword(e.target.value)} onKeyDown={(e) => e.key === "Enter" && go()} /></Field>
        </div>
        <button onClick={go} disabled={busy} className="w-full mt-5 py-2.5 rounded-lg text-white text-sm font-medium bg-blue-600 hover:bg-blue-700 disabled:opacity-60 inline-flex items-center justify-center gap-2">
          <Icon name="lock" size={15} /> {busy ? "Signing in..." : "Sign in"}
        </button>
      </div>
    </div>
  );
}
