import { useState } from "react";
import { insertRow } from "../lib/db";
import { genKey, genPassword, addMonths, clientMessage, copy, money } from "../lib/util";
import { Btn, Field, Modal, ErrorBox, inputCls } from "./ui";

export default function CreateModal({ plans, onClose, onCreated }) {
  const first = plans[0];
  const [f, setF] = useState({
    shop_name: "", owner_name: "", phone: "", plan: first?.name || "", price: first?.price ?? 0, months: 1,
    max_devices: first?.max_devices ?? 1, backup_enabled: first?.backup_enabled ?? true, offline_grace_days: 7, admin_username: "", password: genPassword(), notes: "",
  });
  const [amount, setAmount] = useState(String((first?.price ?? 0) * 1));
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [done, setDone] = useState(null);
  const [copied, setCopied] = useState(false);
  const set = (k) => (e) => setF((s) => ({ ...s, [k]: e.target.value }));

  const pickPlan = (e) => {
    const p = plans.find((x) => x.name === e.target.value);
    setF((s) => ({ ...s, plan: e.target.value, price: p?.price ?? s.price, max_devices: p?.max_devices ?? s.max_devices, backup_enabled: p?.backup_enabled ?? s.backup_enabled }));
    setAmount(String((p?.price ?? 0) * f.months));
  };
  const pickMonths = (e) => {
    setF((s) => ({ ...s, months: e.target.value }));
    setAmount(String(Number(f.price || 0) * Number(e.target.value)));
  };
  const changePrice = (e) => {
    setF((s) => ({ ...s, price: e.target.value }));
    setAmount(String(Number(e.target.value || 0) * Number(f.months)));
  };

  const submit = async () => {
    if (!f.shop_name.trim()) return setErr("Shop name is required.");
    if (!f.plan) return setErr("Create a plan first (Plans tab), then pick it here.");
    if (!f.admin_username.trim()) return setErr("Login username is required.");
    if (f.password.length < 6) return setErr("Password must be at least 6 characters.");
    setBusy(true); setErr("");
    const row = {
      shop_name: f.shop_name.trim(), owner_name: f.owner_name.trim() || null, phone: f.phone.trim() || null,
      plan: f.plan, price: Number(f.price) || 0, max_devices: Math.max(1, +f.max_devices || 1), backup_enabled: !!f.backup_enabled,
      offline_grace_days: Math.max(0, +f.offline_grace_days || 0),
      expires_at: addMonths(new Date().toISOString(), +f.months || 1).toISOString(),
      admin_username: f.admin_username.trim(), pending_password: f.password, notes: f.notes.trim() || null,
    };
    try {
      let lic;
      for (let i = 0; i < 3; i++) { // retry only on the (very unlikely) key collision
        try {
          lic = await insertRow("licenses", { ...row, license_key: genKey() });
          break;
        } catch (e) {
          if (e.code !== "23505" || i === 2) throw e;
        }
      }
      const paid = Number(amount) || 0;
      if (paid > 0) {
        try {
          await insertRow("payments", { license_id: lic.id, shop_name: lic.shop_name, plan: lic.plan, amount: paid, months: +f.months || 1, note: "First period" });
        } catch (e) {
          setErr("The license was created, but the payment was NOT saved (" + e.message + "). Add it with Renew later if needed.");
        }
      }
      setDone(lic);
      onCreated();
    } catch (e) {
      setErr(e.message);
    } finally {
      setBusy(false);
    }
  };

  if (done) {
    const msg = clientMessage(done, f.password);
    return (
      <Modal title="License created" onClose={onClose}>
        <pre className="bg-slate-50 border border-slate-200 rounded-lg p-4 text-xs text-slate-700 whitespace-pre-wrap font-mono">{msg}</pre>
        <p className="text-xs text-amber-600 mt-2">The password is only shown now. Once the client activates, it is removed from the server.</p>
        <ErrorBox message={err} />
        <div className="flex gap-2 mt-4">
          <Btn kind="primary" icon="copy" onClick={async () => { await copy(msg); setCopied(true); }}>{copied ? "Copied" : "Copy message"}</Btn>
          <Btn onClick={onClose}>Close</Btn>
        </div>
      </Modal>
    );
  }

  return (
    <Modal title="New license" onClose={onClose} wide>
      <ErrorBox message={err} />
      <div className="grid grid-cols-2 gap-3">
        <Field label="Shop name *"><input className={inputCls} value={f.shop_name} onChange={set("shop_name")} autoFocus /></Field>
        <Field label="Owner name"><input className={inputCls} value={f.owner_name} onChange={set("owner_name")} /></Field>
        <Field label="Phone"><input className={inputCls} value={f.phone} onChange={set("phone")} /></Field>
        <Field label="Plan *">
          <select className={inputCls} value={f.plan} onChange={pickPlan}>
            {plans.length === 0 && <option value="">No plans — create one first</option>}
            {plans.map((p) => <option key={p.id} value={p.name}>{p.name} — {money(p.price)}/month</option>)}
          </select>
        </Field>
        <Field label="Price per month (Rs)" hint="Change it for a discount or custom deal.">
          <input type="number" min="0" className={inputCls} value={f.price} onChange={changePrice} />
        </Field>
        <Field label="First period">
          <select className={inputCls} value={f.months} onChange={pickMonths}>{[1, 2, 3, 6, 12, 24].map((m) => <option key={m} value={m}>{m} month{m > 1 ? "s" : ""}</option>)}</select>
        </Field>
        <Field label="Amount received now (Rs)" hint="Saved in Payments. Use 0 if nothing was paid yet.">
          <input type="number" min="0" className={inputCls} value={amount} onChange={(e) => setAmount(e.target.value)} />
        </Field>
        <Field label="Computers allowed"><input type="number" min="1" className={inputCls} value={f.max_devices} onChange={set("max_devices")} /></Field>
        <Field label="Offline days allowed" hint="How long the app works without internet.">
          <input type="number" min="0" className={inputCls} value={f.offline_grace_days} onChange={set("offline_grace_days")} />
        </Field>
        <label className="flex items-center gap-2.5 text-sm text-slate-700 cursor-pointer self-end pb-2">
          <input type="checkbox" checked={f.backup_enabled} onChange={(e) => setF((s) => ({ ...s, backup_enabled: e.target.checked }))} className="w-4 h-4" />
          Cloud backup enabled
        </label>
        <Field label="Client login username *"><input className={inputCls} value={f.admin_username} onChange={set("admin_username")} placeholder="e.g. ali" /></Field>
        <Field label="Client login password *">
          <div className="flex gap-2">
            <input className={`${inputCls} font-mono`} value={f.password} onChange={set("password")} />
            <Btn onClick={() => setF((s) => ({ ...s, password: genPassword() }))}>Generate</Btn>
          </div>
        </Field>
      </div>
      <div className="mt-3"><Field label="Private notes (only you can see these)"><input className={inputCls} value={f.notes} onChange={set("notes")} /></Field></div>
      <div className="flex justify-end gap-2 mt-5">
        <Btn onClick={onClose}>Cancel</Btn>
        <Btn kind="primary" icon="check" disabled={busy} onClick={submit}>{busy ? "Creating..." : "Create license"}</Btn>
      </div>
    </Modal>
  );
}
