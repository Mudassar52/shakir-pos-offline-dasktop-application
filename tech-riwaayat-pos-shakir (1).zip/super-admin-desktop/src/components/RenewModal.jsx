import { useState } from "react";
import { updateRow, insertRow } from "../lib/db";
import { renewedExpiry, fmtDate, money, genKey, isExpired, clientMessage, copy } from "../lib/util";
import { Btn, Field, Modal, ErrorBox, inputCls } from "./ui";

export default function RenewModal({ license: l, onClose, onDone }) {
  const [months, setMonths] = useState(1);
  const [amount, setAmount] = useState(String(Number(l.price || 0)));
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  // Renew par nayi license key: purani key band ho jati hai, client ko nayi key deni hoti hai.
  const [rotate, setRotate] = useState(true);
  const [done, setDone] = useState(null); // { key, license } renew ke baad nayi key dikhane ke liye

  const newExpiry = renewedExpiry(l.expires_at, +months);
  const changeMonths = (e) => { setMonths(e.target.value); setAmount(String(Number(l.price || 0) * Number(e.target.value))); };

  const submit = async () => {
    setBusy(true); setErr("");
    let newKey = null;
    try {
      // expiry + nayi key ek hi write mein (ya dono hon ya koi nahi). Key collision (23505) par dobara try.
      for (let i = 0; i < 3; i++) {
        try {
          newKey = rotate ? genKey() : null;
          await updateRow("licenses", l.id, rotate ? { expires_at: newExpiry, license_key: newKey } : { expires_at: newExpiry });
          break;
        } catch (e) {
          if (!(rotate && e.code === "23505" && i < 2)) throw e;
        }
      }
    } catch (e) {
      setBusy(false);
      return setErr(e.message);
    }
    const paid = Number(amount) || 0;
    if (paid > 0) {
      try {
        await insertRow("payments", { license_id: l.id, shop_name: l.shop_name, plan: l.plan, amount: paid, months: +months, note: note.trim() || null });
      } catch (e) {
        setBusy(false);
        onDone("License renewed, but the payment was NOT saved");
        return setErr("The license was renewed (new expiry saved), but the payment was NOT saved: " + e.message + " Close this window and add it again only if it is missing in Payments.");
      }
    }
    setBusy(false);
    onDone(`Renewed for ${months} month${months > 1 ? "s" : ""}${paid > 0 ? ` • ${money(paid)} recorded` : ""}${newKey ? " • new key issued" : ""}`);
    if (newKey) { setDone({ key: newKey, license: { ...l, license_key: newKey, expires_at: newExpiry } }); return; }
    onClose();
  };

  if (done) {
    const msg = clientMessage(done.license).replace("Your Tech Riwaayat POS is ready for", "Your Tech Riwaayat POS license has been renewed for").replace("Install the software and enter the license key when it first opens (internet is required). Then sign in with the username and password above.", "Open the software, enter this NEW license key when asked (internet is required) and continue. Your old key no longer works. Your data and login stay the same.").replace(/^Username:.*\n/m, "");
    return (
      <Modal title="Renewed — send the NEW key to the client" onClose={onClose}>
        <div className="rounded-lg bg-emerald-50 border border-emerald-200 px-4 py-3 text-center">
          <p className="text-xs text-emerald-700">New license key</p>
          <p className="font-mono text-xl font-bold text-emerald-800 tracking-wider mt-1">{done.key}</p>
        </div>
        <p className="text-xs text-slate-500 mt-3">The old key stopped working. The client's app will ask for the new key the next time it connects to the internet. Their data and login are not affected.</p>
        <div className="flex justify-end gap-2 mt-5">
          <Btn icon="copy" onClick={async () => { await copy(msg); }}>Copy message for client</Btn>
          <Btn kind="ok" icon="check" onClick={onClose}>Done</Btn>
        </div>
      </Modal>
    );
  }

  return (
    <Modal title={`Renew — ${l.shop_name}`} onClose={onClose}>
      <ErrorBox message={err} />
      <div className="space-y-3">
        <Field label="Renew for">
          <select className={inputCls} value={months} onChange={changeMonths}>{[1, 2, 3, 6, 12, 24].map((m) => <option key={m} value={m}>{m} month{m > 1 ? "s" : ""}</option>)}</select>
        </Field>
        <Field label="Amount received (Rs)" hint={`${l.plan} plan at ${money(l.price)} per month. Enter 0 for a free extension (no payment recorded).`}>
          <input type="number" min="0" className={inputCls} value={amount} onChange={(e) => setAmount(e.target.value)} />
        </Field>
        <Field label="Note (optional)"><input className={inputCls} value={note} onChange={(e) => setNote(e.target.value)} placeholder="e.g. Paid by bank transfer" /></Field>
      </div>
      <label className="mt-4 flex items-start gap-2.5 text-sm text-slate-700 cursor-pointer">
        <input type="checkbox" checked={rotate} onChange={(e) => setRotate(e.target.checked)} className="w-4 h-4 mt-0.5" />
        <span><b>Issue a NEW license key</b>{isExpired(l.expires_at) ? " (recommended — license had expired)" : ""}<br />
          <span className="text-xs text-slate-400">The old key stops working. Client enters the new key once; their data stays.</span></span>
      </label>
      <div className="mt-3 px-3 py-2.5 rounded-lg bg-slate-50 border border-slate-200 text-sm text-slate-600">
        Current expiry: <b>{fmtDate(l.expires_at)}</b> → New expiry: <b className="text-emerald-700">{fmtDate(newExpiry)}</b>
      </div>
      <div className="flex justify-end gap-2 mt-5">
        <Btn onClick={onClose}>Cancel</Btn>
        <Btn kind="ok" icon="check" disabled={busy} onClick={submit}>{busy ? "Saving..." : "Renew & record payment"}</Btn>
      </div>
    </Modal>
  );
}
