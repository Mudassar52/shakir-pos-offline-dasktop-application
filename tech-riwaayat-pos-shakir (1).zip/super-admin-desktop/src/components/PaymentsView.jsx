import { useMemo, useState } from "react";
import { deleteRow } from "../lib/db";
import { money, fmtDate, isThisMonth } from "../lib/util";
import { Btn, Spinner, inputCls } from "./ui";
import { Icon } from "./icons";

function Stat({ label, value, icon, tone }) {
  return (
    <div className="bg-white rounded-xl border border-slate-200 px-4 py-4 flex items-center gap-3">
      <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${tone}`}><Icon name={icon} size={20} /></div>
      <div><p className="text-xs text-slate-500">{label}</p><p className="text-xl font-semibold text-slate-800">{value}</p></div>
    </div>
  );
}

export default function PaymentsView({ payments, loading, onChanged, flash }) {
  const [q, setQ] = useState("");
  const [range, setRange] = useState("all"); // all | month

  const now = new Date();
  const last = new Date(now.getFullYear(), now.getMonth() - 1, 1);
  const sum = (arr) => arr.reduce((a, p) => a + Number(p.amount), 0);
  const thisMonth = useMemo(() => sum(payments.filter((p) => isThisMonth(p.paid_at))), [payments]);
  const lastMonth = useMemo(() => sum(payments.filter((p) => { const d = new Date(p.paid_at); return d.getFullYear() === last.getFullYear() && d.getMonth() === last.getMonth(); })), [payments]);
  const total = useMemo(() => sum(payments), [payments]);

  const shown = useMemo(() => {
    const t = q.trim().toLowerCase();
    return payments.filter((p) => (range === "all" || isThisMonth(p.paid_at)) && (!t || [p.shop_name, p.plan, p.note].some((x) => (x || "").toLowerCase().includes(t))));
  }, [payments, q, range]);

  const remove = async (p) => {
    if (!confirm(`Delete this payment of ${money(p.amount)} from ${p.shop_name}? This only removes the record; it does not change the license expiry.`)) return;
    try {
      await deleteRow("payments", p.id);
      flash("Payment deleted");
      onChanged();
    } catch (e) {
      flash("Error: " + e.message);
    }
  };

  return (
    <>
      <div className="mb-4">
        <h2 className="text-lg font-semibold text-slate-800">Payments</h2>
        <p className="text-sm text-slate-500">Every renewal you record is listed here.</p>
      </div>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-6">
        <Stat label="This month" value={money(thisMonth)} icon="trend" tone="bg-blue-50 text-blue-600" />
        <Stat label="Last month" value={money(lastMonth)} icon="calendar" tone="bg-slate-100 text-slate-600" />
        <Stat label="All time" value={money(total)} icon="wallet" tone="bg-emerald-50 text-emerald-600" />
        <Stat label="Payments recorded" value={payments.length} icon="receipt" tone="bg-amber-50 text-amber-600" />
      </div>

      <div className="flex flex-wrap items-center gap-3 mb-4">
        <div className="relative">
          <Icon name="search" size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input className={`${inputCls} pl-9 w-72`} placeholder="Search shop, plan or note" value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
        {[["all", "All time"], ["month", "This month"]].map(([k, l]) => (
          <button key={k} onClick={() => setRange(k)} className={`px-3 py-1.5 rounded-full text-sm border ${range === k ? "bg-slate-800 text-white border-slate-800" : "bg-white text-slate-600 border-slate-300 hover:bg-slate-50"}`}>{l}</button>
        ))}
        <span className="text-sm text-slate-500 ml-auto">Showing total: <b className="text-slate-800">{money(shown.reduce((a, p) => a + Number(p.amount), 0))}</b></span>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-xs font-medium text-slate-500 bg-slate-50 border-b border-slate-200">
              <th className="px-4 py-3">Date</th><th className="px-3 py-3">Shop</th><th className="px-3 py-3">Plan</th><th className="px-3 py-3">Months</th><th className="px-3 py-3">Amount</th><th className="px-3 py-3">Note</th><th className="px-3 py-3 w-12" />
            </tr>
          </thead>
          <tbody>
            {loading && <tr><td colSpan={7} className="py-12"><div className="flex justify-center"><Spinner /></div></td></tr>}
            {!loading && shown.length === 0 && <tr><td colSpan={7} className="py-12 text-center text-slate-400">No payments found.</td></tr>}
            {!loading && shown.map((p) => (
              <tr key={p.id} className="border-b border-slate-100">
                <td className="px-4 py-3 text-slate-600">{fmtDate(p.paid_at)}</td>
                <td className="px-3 py-3 font-medium text-slate-800">{p.shop_name}</td>
                <td className="px-3 py-3 text-slate-600">{p.plan || "—"}</td>
                <td className="px-3 py-3 text-slate-600">{p.months ?? "—"}</td>
                <td className="px-3 py-3 font-medium text-emerald-700">{money(p.amount)}</td>
                <td className="px-3 py-3 text-slate-500">{p.note || "—"}</td>
                <td className="px-3 py-3"><Btn kind="danger" icon="trash" onClick={() => remove(p)} aria-label="Delete payment" /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}
