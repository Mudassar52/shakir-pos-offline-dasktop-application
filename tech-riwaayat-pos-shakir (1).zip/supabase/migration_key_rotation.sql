-- ════════════════════════════════════════════════════════════════════════
--  License KEY ROTATION  (Supabase → SQL Editor → New query → paste → Run)
--  Jab bhi licenses.license_key badli jati hai, purani key history mein chali
--  jati hai. Purani key se POS app ko "key_replaced" milta hai (invalid nahi),
--  taake client ko saaf message dikhe: "Nayi key enter karein".
--  Computers ki registration (license_devices) wahi rehti hai — client sirf
--  nayi key enter karta hai, dobara device slot nahi lagta.
-- ════════════════════════════════════════════════════════════════════════
create table if not exists public.license_key_history (
  id          uuid primary key default gen_random_uuid(),
  license_id  uuid not null references public.licenses(id) on delete cascade,
  old_key     text not null unique,
  replaced_at timestamptz not null default now()
);
alter table public.license_key_history enable row level security;
drop policy if exists sa_key_history on public.license_key_history;
create policy sa_key_history on public.license_key_history for all to authenticated
  using (public.is_super_admin()) with check (public.is_super_admin());
revoke all on public.license_key_history from anon;

create or replace function public._log_key_change() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.license_key is distinct from old.license_key then
    insert into public.license_key_history (license_id, old_key) values (old.id, old.license_key)
    on conflict (old_key) do nothing;
  end if;
  return new;
end $$;
drop trigger if exists trg_log_key_change on public.licenses;
create trigger trg_log_key_change before update of license_key on public.licenses
  for each row execute function public._log_key_change();

-- activate_license / check_license: purani key → 'key_replaced'
create or replace function public.activate_license(
  p_key text, p_machine_id text, p_machine_name text default null, p_app_version text default null
) returns jsonb language plpgsql security definer set search_path = public as $$
declare l public.licenses; dev_id uuid; dev_count int;
begin
  if p_key is null or p_machine_id is null or length(p_machine_id) < 8 then
    return jsonb_build_object('ok', false, 'error', 'invalid_request');
  end if;
  select * into l from public.licenses where license_key = upper(trim(p_key));
  if not found then
    if exists (select 1 from public.license_key_history where old_key = upper(trim(p_key))) then
      return jsonb_build_object('ok', false, 'error', 'key_replaced');
    end if;
    return jsonb_build_object('ok', false, 'error', 'invalid_key');
  end if;
  if l.status = 'blocked' then return jsonb_build_object('ok', false, 'error', 'blocked'); end if;

  select id into dev_id from public.license_devices where license_id = l.id and machine_id = p_machine_id;
  if dev_id is null then
    select count(*) into dev_count from public.license_devices where license_id = l.id;
    if dev_count >= l.max_devices then
      return jsonb_build_object('ok', false, 'error', 'device_limit', 'max_devices', l.max_devices);
    end if;
    insert into public.license_devices (license_id, machine_id, machine_name, app_version)
    values (l.id, p_machine_id, p_machine_name, p_app_version);
  else
    update public.license_devices
       set last_seen = now(), machine_name = coalesce(p_machine_name, machine_name),
           app_version = coalesce(p_app_version, app_version)
     where id = dev_id;
  end if;
  return jsonb_build_object('ok', true) || public._license_payload(l);
end $$;

create or replace function public.check_license(
  p_key text, p_machine_id text, p_app_version text default null
) returns jsonb language plpgsql security definer set search_path = public as $$
declare l public.licenses; dev_id uuid;
begin
  select * into l from public.licenses where license_key = upper(trim(coalesce(p_key, '')));
  if not found then
    if exists (select 1 from public.license_key_history where old_key = upper(trim(coalesce(p_key, '')))) then
      return jsonb_build_object('ok', false, 'error', 'key_replaced');
    end if;
    return jsonb_build_object('ok', false, 'error', 'invalid_key');
  end if;
  select id into dev_id from public.license_devices where license_id = l.id and machine_id = p_machine_id;
  if dev_id is null then return jsonb_build_object('ok', false, 'error', 'not_activated'); end if;
  update public.license_devices set last_seen = now(), app_version = coalesce(p_app_version, app_version) where id = dev_id;
  return jsonb_build_object('ok', true) || public._license_payload(l);
end $$;
