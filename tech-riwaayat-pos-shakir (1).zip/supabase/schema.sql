-- ════════════════════════════════════════════════════════════════════════
--  Tech Riwaayat POS — License System (Supabase)
--  Supabase Dashboard → SQL Editor → New query → yeh poori file paste → Run
-- ════════════════════════════════════════════════════════════════════════
--  Security design:
--   • Tables par RLS ON hai. Sirf "super admin" (super_admins table wala
--     login) licenses dekh/badal sakta hai.
--   • POS app sirf 3 chhote functions (RPC) call kar sakti hai: activate /
--     check / ack. Woh table ko seedha kabhi nahi padh sakti, isliye ek
--     client doosre clients ka data nahi dekh sakta.
-- ════════════════════════════════════════════════════════════════════════

-- ── Tables ───────────────────────────────────────────────────────────────
create table if not exists public.licenses (
  id                 uuid primary key default gen_random_uuid(),
  license_key        text not null unique,
  shop_name          text not null,
  owner_name         text,
  phone              text,
  plan               text not null default 'Standard',
  max_devices        int  not null default 1 check (max_devices >= 1),
  offline_grace_days int  not null default 7 check (offline_grace_days >= 0),
  expires_at         timestamptz not null,
  status             text not null default 'active' check (status in ('active','blocked')),
  admin_username     text not null,          -- shop ka login username
  pending_password   text,                   -- ek-martaba password (apply hote hi NULL ho jata hai)
  notice             text,                   -- client ko dikhne wala message
  notes              text,                   -- sirf aapke liye private notes
  created_at         timestamptz not null default now(),
  updated_at         timestamptz not null default now()
);

create table if not exists public.license_devices (
  id           uuid primary key default gen_random_uuid(),
  license_id   uuid not null references public.licenses(id) on delete cascade,
  machine_id   text not null,
  machine_name text,
  app_version  text,
  first_seen   timestamptz not null default now(),
  last_seen    timestamptz not null default now(),
  unique (license_id, machine_id)
);

create table if not exists public.super_admins (
  user_id uuid primary key references auth.users(id) on delete cascade
);

create or replace function public.touch_updated_at() returns trigger
language plpgsql as $$ begin new.updated_at = now(); return new; end $$;
drop trigger if exists licenses_touch on public.licenses;
create trigger licenses_touch before update on public.licenses
  for each row execute function public.touch_updated_at();

-- ── Row Level Security ───────────────────────────────────────────────────
alter table public.licenses        enable row level security;
alter table public.license_devices enable row level security;
alter table public.super_admins    enable row level security;

create or replace function public.is_super_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.super_admins where user_id = auth.uid());
$$;
revoke all on function public.is_super_admin() from public, anon;
grant execute on function public.is_super_admin() to authenticated;

drop policy if exists sa_licenses on public.licenses;
create policy sa_licenses on public.licenses for all to authenticated
  using (public.is_super_admin()) with check (public.is_super_admin());

drop policy if exists sa_devices on public.license_devices;
create policy sa_devices on public.license_devices for all to authenticated
  using (public.is_super_admin()) with check (public.is_super_admin());

drop policy if exists sa_self on public.super_admins;
create policy sa_self on public.super_admins for select to authenticated
  using (user_id = auth.uid());

revoke all on public.licenses, public.license_devices, public.super_admins from anon;

-- ── Plans, prices and payments ───────────────────────────────────────────
-- Safe to run again on an existing project: everything is "if not exists".
alter table public.licenses add column if not exists price numeric(12,2) not null default 0;  -- monthly price for this client

create table if not exists public.plans (
  id          uuid primary key default gen_random_uuid(),
  name        text not null unique,
  price       numeric(12,2) not null default 0 check (price >= 0),   -- price per month
  max_devices int not null default 1 check (max_devices >= 1),
  created_at  timestamptz not null default now()
);

create table if not exists public.payments (
  id         uuid primary key default gen_random_uuid(),
  license_id uuid references public.licenses(id) on delete set null,
  shop_name  text not null,          -- kept even if the license is deleted later
  plan       text,
  amount     numeric(12,2) not null check (amount >= 0),
  months     int,
  note       text,
  paid_at    timestamptz not null default now()
);
create index if not exists payments_paid_at_idx on public.payments (paid_at desc);

-- Cloud backup is a per-plan / per-license feature you can switch on or off
alter table public.plans    add column if not exists backup_enabled boolean not null default true;
alter table public.licenses add column if not exists backup_enabled boolean not null default true;
alter table public.licenses add column if not exists backup_keep int not null default 5 check (backup_keep between 1 and 30);

alter table public.plans    enable row level security;
alter table public.payments enable row level security;

drop policy if exists sa_plans on public.plans;
create policy sa_plans on public.plans for all to authenticated
  using (public.is_super_admin()) with check (public.is_super_admin());
drop policy if exists sa_payments on public.payments;
create policy sa_payments on public.payments for all to authenticated
  using (public.is_super_admin()) with check (public.is_super_admin());
revoke all on public.plans, public.payments from anon;

insert into public.plans (name, price, max_devices) values
  ('Basic', 0, 1), ('Standard', 0, 1), ('Premium', 0, 3)
on conflict (name) do nothing;

-- ── Internal helper (public ko access nahi) ──────────────────────────────
create or replace function public._license_payload(l public.licenses) returns jsonb
language sql stable set search_path = public as $$
  select jsonb_build_object(
    'status', case when l.status = 'blocked' then 'blocked'
                   when l.expires_at < now() then 'expired' else 'active' end,
    'shop_name', l.shop_name, 'owner_name', l.owner_name, 'plan', l.plan,
    'expires_at', l.expires_at, 'offline_grace_days', l.offline_grace_days,
    'notice', l.notice, 'admin_username', l.admin_username,
    'pending_password', l.pending_password, 'server_time', now(),
    'backup_enabled', l.backup_enabled, 'backup_keep', l.backup_keep);
$$;
revoke all on function public._license_payload(public.licenses) from public, anon, authenticated;

-- ── RPC 1: pehli dafa activate (computer register hota hai) ──────────────
create or replace function public.activate_license(
  p_key text, p_machine_id text, p_machine_name text default null, p_app_version text default null
) returns jsonb language plpgsql security definer set search_path = public as $$
declare l public.licenses; dev_id uuid; dev_count int;
begin
  if p_key is null or p_machine_id is null or length(p_machine_id) < 8 then
    return jsonb_build_object('ok', false, 'error', 'invalid_request');
  end if;
  select * into l from public.licenses where license_key = upper(trim(p_key));
  if not found then return jsonb_build_object('ok', false, 'error', 'invalid_key'); end if;
  if l.status = 'blocked' then return jsonb_build_object('ok', false, 'error', 'blocked'); end if;

  select id into dev_id from public.license_devices where license_id = l.id and machine_id = p_machine_id;
  if dev_id is null then
    select count(*) into dev_count from public.license_devices where license_id = l.id;
    if dev_count >= l.max_devices then
      return jsonb_build_object('ok', false, 'error', 'device_limit', 'max_devices', l.max_devices);
    end if;
    insert into public.license_devices (license_id, machine_id, machine_name, app_version)
    values (l.id, p_machine_id, p_machine_name, p_app_version);
  else
    update public.license_devices
       set last_seen = now(), machine_name = coalesce(p_machine_name, machine_name),
           app_version = coalesce(p_app_version, app_version)
     where id = dev_id;
  end if;
  return jsonb_build_object('ok', true) || public._license_payload(l);
end $$;

-- ── RPC 2: regular check (har app start + har 30 min) ────────────────────
create or replace function public.check_license(
  p_key text, p_machine_id text, p_app_version text default null
) returns jsonb language plpgsql security definer set search_path = public as $$
declare l public.licenses; dev_id uuid;
begin
  select * into l from public.licenses where license_key = upper(trim(coalesce(p_key, '')));
  if not found then return jsonb_build_object('ok', false, 'error', 'invalid_key'); end if;
  select id into dev_id from public.license_devices where license_id = l.id and machine_id = p_machine_id;
  if dev_id is null then return jsonb_build_object('ok', false, 'error', 'not_activated'); end if;
  update public.license_devices set last_seen = now(), app_version = coalesce(p_app_version, app_version) where id = dev_id;
  return jsonb_build_object('ok', true) || public._license_payload(l);
end $$;

-- ── RPC 3: password apply ho gaya — ek-martaba password server se hata do ─
create or replace function public.ack_credentials(p_key text, p_machine_id text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare l public.licenses;
begin
  select * into l from public.licenses where license_key = upper(trim(coalesce(p_key, '')));
  if not found then return jsonb_build_object('ok', false); end if;
  if not exists (select 1 from public.license_devices where license_id = l.id and machine_id = p_machine_id) then
    return jsonb_build_object('ok', false);
  end if;
  update public.licenses set pending_password = null where id = l.id;
  return jsonb_build_object('ok', true);
end $$;

revoke all on function public.activate_license(text, text, text, text) from public;
revoke all on function public.check_license(text, text, text)          from public;
revoke all on function public.ack_credentials(text, text)              from public;
grant execute on function public.activate_license(text, text, text, text) to anon, authenticated;
grant execute on function public.check_license(text, text, text)          to anon, authenticated;
grant execute on function public.ack_credentials(text, text)              to anon, authenticated;

-- ════════════════════════════════════════════════════════════════════════
--  CLOUD BACKUP (shop POS database -> Supabase)
--  The POS compresses its database, cuts it into small chunks and uploads
--  them through the functions below. A client can only reach its OWN
--  license's backups (license key + registered computer are checked on every
--  call). Only you (Super Admin) can see the list or download a backup.
-- ════════════════════════════════════════════════════════════════════════
create table if not exists public.cloud_backups (
  id              uuid primary key default gen_random_uuid(),
  license_id      uuid not null references public.licenses(id) on delete cascade,
  machine_id      text,
  machine_name    text,
  app_version     text,
  size_bytes      bigint not null,          -- compressed size stored in Supabase
  raw_bytes       bigint,                   -- original database size
  sha256          text,                     -- of the compressed data (integrity check)
  chunks_expected int not null,
  chunks          int not null default 0,
  status          text not null default 'uploading' check (status in ('uploading','complete')),
  created_at      timestamptz not null default now(),
  completed_at    timestamptz
);
create index if not exists cloud_backups_lic_idx on public.cloud_backups (license_id, created_at desc);

create table if not exists public.cloud_backup_chunks (
  backup_id uuid not null references public.cloud_backups(id) on delete cascade,
  idx       int  not null,
  data      bytea not null,
  primary key (backup_id, idx)
);

alter table public.cloud_backups       enable row level security;
alter table public.cloud_backup_chunks enable row level security;
drop policy if exists sa_backups on public.cloud_backups;
create policy sa_backups on public.cloud_backups for all to authenticated
  using (public.is_super_admin()) with check (public.is_super_admin());
-- chunks: no direct policy at all -> reachable only through the functions below
revoke all on public.cloud_backups, public.cloud_backup_chunks from anon;
revoke all on public.cloud_backup_chunks from authenticated;

-- Every backup call must pass this check (valid key, registered computer,
-- license running, cloud backup switched on for this license).
create or replace function public._backup_check(p_key text, p_machine_id text)
returns table (license_id uuid, keep int, err text)
language plpgsql security definer set search_path = public as $$
declare l public.licenses;
begin
  select * into l from public.licenses where license_key = upper(trim(coalesce(p_key, '')));
  if not found then return query select null::uuid, 0, 'invalid_key'; return; end if;
  if not exists (select 1 from public.license_devices d where d.license_id = l.id and d.machine_id = p_machine_id) then
    return query select null::uuid, 0, 'not_activated'; return;
  end if;
  if l.status = 'blocked' then return query select null::uuid, 0, 'blocked'; return; end if;
  if l.expires_at < now() then return query select null::uuid, 0, 'expired'; return; end if;
  if not l.backup_enabled then return query select null::uuid, 0, 'backup_disabled'; return; end if;
  return query select l.id, l.backup_keep, null::text;
end $$;
revoke all on function public._backup_check(text, text) from public, anon, authenticated;

create or replace function public.backup_begin(
  p_key text, p_machine_id text, p_chunks int, p_size bigint,
  p_raw bigint default null, p_sha text default null, p_machine_name text default null, p_app_version text default null
) returns jsonb language plpgsql security definer set search_path = public as $$
declare c record; new_id uuid;
begin
  select * into c from public._backup_check(p_key, p_machine_id);
  if c.err is not null then return jsonb_build_object('ok', false, 'error', c.err); end if;
  if p_chunks is null or p_chunks < 1 or p_chunks > 200 or p_size is null or p_size < 1 or p_size > 41943040 then
    return jsonb_build_object('ok', false, 'error', 'too_large');
  end if;
  -- throw away half-finished uploads from earlier failed attempts
  delete from public.cloud_backups
   where license_id = c.license_id and status = 'uploading' and created_at < now() - interval '2 hours';
  insert into public.cloud_backups (license_id, machine_id, machine_name, app_version, size_bytes, raw_bytes, sha256, chunks_expected)
  values (c.license_id, p_machine_id, p_machine_name, p_app_version, p_size, p_raw, p_sha, p_chunks)
  returning id into new_id;
  return jsonb_build_object('ok', true, 'backup_id', new_id);
end $$;

create or replace function public.backup_put_chunk(
  p_key text, p_machine_id text, p_backup_id uuid, p_idx int, p_data text
) returns jsonb language plpgsql security definer set search_path = public as $$
declare c record; b public.cloud_backups;
begin
  select * into c from public._backup_check(p_key, p_machine_id);
  if c.err is not null then return jsonb_build_object('ok', false, 'error', c.err); end if;
  select * into b from public.cloud_backups where id = p_backup_id and license_id = c.license_id and status = 'uploading';
  if not found then return jsonb_build_object('ok', false, 'error', 'no_such_backup'); end if;
  if p_idx is null or p_idx < 0 or p_idx >= b.chunks_expected then return jsonb_build_object('ok', false, 'error', 'bad_index'); end if;
  if p_data is null or length(p_data) > 1000000 then return jsonb_build_object('ok', false, 'error', 'chunk_too_large'); end if;
  insert into public.cloud_backup_chunks (backup_id, idx, data) values (p_backup_id, p_idx, decode(p_data, 'base64'))
  on conflict (backup_id, idx) do update set data = excluded.data;
  return jsonb_build_object('ok', true);
end $$;

create or replace function public.backup_finish(p_key text, p_machine_id text, p_backup_id uuid)
returns jsonb language plpgsql security definer set search_path = public as $$
declare c record; b public.cloud_backups; n int; total bigint;
begin
  select * into c from public._backup_check(p_key, p_machine_id);
  if c.err is not null then return jsonb_build_object('ok', false, 'error', c.err); end if;
  select * into b from public.cloud_backups where id = p_backup_id and license_id = c.license_id and status = 'uploading';
  if not found then return jsonb_build_object('ok', false, 'error', 'no_such_backup'); end if;
  select count(*), coalesce(sum(length(data)), 0) into n, total from public.cloud_backup_chunks where backup_id = p_backup_id;
  if n <> b.chunks_expected or total <> b.size_bytes then
    return jsonb_build_object('ok', false, 'error', 'incomplete', 'chunks', n, 'bytes', total);
  end if;
  update public.cloud_backups set status = 'complete', chunks = n, completed_at = now() where id = p_backup_id;
  -- keep only the newest N backups for this license
  delete from public.cloud_backups
   where license_id = c.license_id and status = 'complete'
     and id not in (select id from public.cloud_backups where license_id = c.license_id and status = 'complete' order by created_at desc limit c.keep);
  return jsonb_build_object('ok', true);
end $$;

create or replace function public.backup_list(p_key text, p_machine_id text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare c record;
begin
  select * into c from public._backup_check(p_key, p_machine_id);
  if c.err is not null then return jsonb_build_object('ok', false, 'error', c.err); end if;
  return jsonb_build_object('ok', true, 'backups', coalesce((
    select jsonb_agg(jsonb_build_object('id', id, 'created_at', created_at, 'size_bytes', size_bytes, 'raw_bytes', raw_bytes,
                                        'chunks', chunks, 'sha256', sha256, 'machine_name', machine_name, 'app_version', app_version)
                     order by created_at desc)
      from (select * from public.cloud_backups where license_id = c.license_id and status = 'complete' order by created_at desc limit 30) x
  ), '[]'::jsonb));
end $$;

create or replace function public.backup_get_chunk(p_key text, p_machine_id text, p_backup_id uuid, p_idx int)
returns jsonb language plpgsql security definer set search_path = public as $$
declare c record; d bytea;
begin
  select * into c from public._backup_check(p_key, p_machine_id);
  if c.err is not null then return jsonb_build_object('ok', false, 'error', c.err); end if;
  select k.data into d from public.cloud_backup_chunks k
    join public.cloud_backups b on b.id = k.backup_id
   where k.backup_id = p_backup_id and k.idx = p_idx and b.license_id = c.license_id and b.status = 'complete';
  if d is null then return jsonb_build_object('ok', false, 'error', 'no_such_backup'); end if;
  return jsonb_build_object('ok', true, 'data', replace(encode(d, 'base64'), E'\n', ''));
end $$;

-- Super Admin only: download a client's backup chunk (for restoring it for them)
create or replace function public.admin_backup_chunk(p_backup_id uuid, p_idx int)
returns text language plpgsql security definer set search_path = public as $$
declare d bytea;
begin
  if not public.is_super_admin() then raise exception 'forbidden'; end if;
  select data into d from public.cloud_backup_chunks where backup_id = p_backup_id and idx = p_idx;
  if d is null then raise exception 'chunk not found'; end if;
  return replace(encode(d, 'base64'), E'\n', '');
end $$;

revoke all on function public.backup_begin(text, text, int, bigint, bigint, text, text, text) from public;
revoke all on function public.backup_put_chunk(text, text, uuid, int, text) from public;
revoke all on function public.backup_finish(text, text, uuid) from public;
revoke all on function public.backup_list(text, text) from public;
revoke all on function public.backup_get_chunk(text, text, uuid, int) from public;
revoke all on function public.admin_backup_chunk(uuid, int) from public, anon;
grant execute on function public.backup_begin(text, text, int, bigint, bigint, text, text, text) to anon, authenticated;
grant execute on function public.backup_put_chunk(text, text, uuid, int, text) to anon, authenticated;
grant execute on function public.backup_finish(text, text, uuid) to anon, authenticated;
grant execute on function public.backup_list(text, text) to anon, authenticated;
grant execute on function public.backup_get_chunk(text, text, uuid, int) to anon, authenticated;
grant execute on function public.admin_backup_chunk(uuid, int) to authenticated;

-- ════════════════════════════════════════════════════════════════════════
--  AAKHRI STEP (sirf ek dafa):
--  1) Dashboard → Authentication → Users → "Add user" → apna email + password
--     (Auto Confirm User ON rakhein). Yehi Super Admin app ka login hoga.
--  2) Neeche ki line mein apna email likh kar alag se Run karein:
--
--  insert into public.super_admins (user_id)
--  select id from auth.users where email = 'YOUR-EMAIL@example.com';
--
--  3) Authentication → Sign In / Providers → "Allow new users to sign up" OFF
--     karein, taake koi aur khud account bana kar admin na ban sake.
-- ════════════════════════════════════════════════════════════════════════


-- ═══ License key rotation (see migration_key_rotation.sql) ═══
create table if not exists public.license_key_history (
  id          uuid primary key default gen_random_uuid(),
  license_id  uuid not null references public.licenses(id) on delete cascade,
  old_key     text not null unique,
  replaced_at timestamptz not null default now()
);
alter table public.license_key_history enable row level security;
drop policy if exists sa_key_history on public.license_key_history;
create policy sa_key_history on public.license_key_history for all to authenticated
  using (public.is_super_admin()) with check (public.is_super_admin());
revoke all on public.license_key_history from anon;

create or replace function public._log_key_change() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.license_key is distinct from old.license_key then
    insert into public.license_key_history (license_id, old_key) values (old.id, old.license_key)
    on conflict (old_key) do nothing;
  end if;
  return new;
end $$;
drop trigger if exists trg_log_key_change on public.licenses;
create trigger trg_log_key_change before update of license_key on public.licenses
  for each row execute function public._log_key_change();

-- activate_license / check_license: purani key → 'key_replaced'
create or replace function public.activate_license(
  p_key text, p_machine_id text, p_machine_name text default null, p_app_version text default null
) returns jsonb language plpgsql security definer set search_path = public as $$
declare l public.licenses; dev_id uuid; dev_count int;
begin
  if p_key is null or p_machine_id is null or length(p_machine_id) < 8 then
    return jsonb_build_object('ok', false, 'error', 'invalid_request');
  end if;
  select * into l from public.licenses where license_key = upper(trim(p_key));
  if not found then
    if exists (select 1 from public.license_key_history where old_key = upper(trim(p_key))) then
      return jsonb_build_object('ok', false, 'error', 'key_replaced');
    end if;
    return jsonb_build_object('ok', false, 'error', 'invalid_key');
  end if;
  if l.status = 'blocked' then return jsonb_build_object('ok', false, 'error', 'blocked'); end if;

  select id into dev_id from public.license_devices where license_id = l.id and machine_id = p_machine_id;
  if dev_id is null then
    select count(*) into dev_count from public.license_devices where license_id = l.id;
    if dev_count >= l.max_devices then
      return jsonb_build_object('ok', false, 'error', 'device_limit', 'max_devices', l.max_devices);
    end if;
    insert into public.license_devices (license_id, machine_id, machine_name, app_version)
    values (l.id, p_machine_id, p_machine_name, p_app_version);
  else
    update public.license_devices
       set last_seen = now(), machine_name = coalesce(p_machine_name, machine_name),
           app_version = coalesce(p_app_version, app_version)
     where id = dev_id;
  end if;
  return jsonb_build_object('ok', true) || public._license_payload(l);
end $$;

create or replace function public.check_license(
  p_key text, p_machine_id text, p_app_version text default null
) returns jsonb language plpgsql security definer set search_path = public as $$
declare l public.licenses; dev_id uuid;
begin
  select * into l from public.licenses where license_key = upper(trim(coalesce(p_key, '')));
  if not found then
    if exists (select 1 from public.license_key_history where old_key = upper(trim(coalesce(p_key, '')))) then
      return jsonb_build_object('ok', false, 'error', 'key_replaced');
    end if;
    return jsonb_build_object('ok', false, 'error', 'invalid_key');
  end if;
  select id into dev_id from public.license_devices where license_id = l.id and machine_id = p_machine_id;
  if dev_id is null then return jsonb_build_object('ok', false, 'error', 'not_activated'); end if;
  update public.license_devices set last_seen = now(), app_version = coalesce(p_app_version, app_version) where id = dev_id;
  return jsonb_build_object('ok', true) || public._license_payload(l);
end $$;
